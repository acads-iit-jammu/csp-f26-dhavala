int f(int x) { x++; return x; }
