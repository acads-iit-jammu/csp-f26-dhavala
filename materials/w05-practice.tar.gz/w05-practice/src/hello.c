#include <stdio.h>
#define GREETING "Hello, world!"
int main(void) { printf("%s\n", GREETING); return 0; }
