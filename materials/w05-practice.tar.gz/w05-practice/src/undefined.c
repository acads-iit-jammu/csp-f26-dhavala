#include <stdio.h>
void foo(void);                 /* declared... */
int main(void) { foo(); return 0; }   /* ...called. But defined WHERE? */
