#include <stdio.h>
#define PI 3.14159
int main(void) {
    double r = 3.0;
    double area = 2 * PI * r;        /* the compiler has no opinion about this */
    printf("area=%.3f\n", area);
    return 0;
}
