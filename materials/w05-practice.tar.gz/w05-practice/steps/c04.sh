# You spent this hour on precedence. Here it is, in the machine.
# Two functions, same three variables, same two operators.
# Predict: will the two produce the SAME instructions? If not, what differs?
order(){ gcc -O0 -S "$1" -o - 2>/dev/null \
  | grep -oE '^[[:space:]]+(imul|mul|madd|add)[a-z]*' \
  | tr -d ' \t' | sed 's/^imul/mul/' | paste -sd' ' - ; }
echo "  a + b * c    ->  $(order src/prec1.c)"
echo "  (a + b) * c  ->  $(order src/prec2.c)"
