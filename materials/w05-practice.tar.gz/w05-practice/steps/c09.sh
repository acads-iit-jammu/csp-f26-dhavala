# Now read what the linker actually SAYS. Predict which word appears.
gcc ${WORK:-/tmp/w05walk}/u.o -o ${WORK:-/tmp/w05walk}/u 2>&1 | head -4
