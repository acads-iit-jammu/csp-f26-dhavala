# The file says:   #define GREETING "Hello, world!"
# Predict the LAST line of the preprocessed output.
# Is the word GREETING still anywhere in it?
gcc -E src/hello.c | tail -1
echo "--- occurrences of the word GREETING that survive: ---"
gcc -E src/hello.c | grep -c GREETING
