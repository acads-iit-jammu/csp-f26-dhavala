# Stage 3 (the assembler) turns that text into real machine code: hello.o
# Predict: does ./hello.o print Hello, world!  -- or something else?
gcc -c src/hello.c -o ${WORK:-/tmp/w05walk}/hello.o
chmod +x ${WORK:-/tmp/w05walk}/hello.o 2>/dev/null
${WORK:-/tmp/w05walk}/hello.o 2>/dev/null
echo "exit code: $?"
