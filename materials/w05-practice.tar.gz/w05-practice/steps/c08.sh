# src/undefined.c calls foo(), which is declared but defined NOWHERE.
# Predict TWO exit codes: does stage 3 (-c) succeed? Does the full build?
gcc -c src/undefined.c -o ${WORK:-/tmp/w05walk}/u.o >/dev/null 2>&1; echo "gcc -c  (stages 1-3) exit: $?"
gcc ${WORK:-/tmp/w05walk}/u.o -o ${WORK:-/tmp/w05walk}/u          >/dev/null 2>&1; echo "linking (stage 4)   exit: $?"
