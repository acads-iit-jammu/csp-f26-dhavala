# Stage 4: hand the object file to the LINKER and let it finish.
# Predict THREE things: does it run now? Is printf still U? And if it is...
#                       where is printf actually coming from?
gcc ${WORK:-/tmp/w05walk}/hello.o -o ${WORK:-/tmp/w05walk}/hello
echo "--- it runs: ---"
${WORK:-/tmp/w05walk}/hello
echo "--- nm on the finished executable: ---"
nm ${WORK:-/tmp/w05walk}/hello | grep -Ei ' t _?main| u _?printf'
echo "--- and the libraries it now depends on: ---"
if command -v ldd >/dev/null 2>&1; then ldd ${WORK:-/tmp/w05walk}/hello | head -3
else otool -L ${WORK:-/tmp/w05walk}/hello | head -3; fi
