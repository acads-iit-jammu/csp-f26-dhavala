# Stage 2 turns C into ASSEMBLY - text, but one line per machine instruction.
# Predict: is there a line that names printf? What does the verb look like?
gcc -S src/hello.c -o ${WORK:-/tmp/w05walk}/hello.s
grep -nE 'call|bl[[:space:]]' ${WORK:-/tmp/w05walk}/hello.s | head -3
echo "--- total instructions in your 3-line program: ---"
grep -cE '^[[:space:]]+[a-z]' ${WORK:-/tmp/w05walk}/hello.s
