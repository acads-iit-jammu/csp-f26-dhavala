# So what IS in hello.o? nm lists the names inside an object file.
#   T = defined right here, at this address
#   U = UNDEFINED - used, but its code is somewhere else
# Predict: which of main and printf gets an address, and which gets U?
nm ${WORK:-/tmp/w05walk}/hello.o | grep -Ei 'main|printf'
