# How big is a 3-line program after stage 1 alone?
# -E stops after the preprocessor. Predict the OUT number: 3? 30? 300? 3000?
mkdir -p ${WORK:-/tmp/w05walk}
echo "lines IN :  $(wc -l < src/hello.c)"
gcc -E src/hello.c > ${WORK:-/tmp/w05walk}/hello.i
echo "lines OUT:  $(wc -l < ${WORK:-/tmp/w05walk}/hello.i)"
