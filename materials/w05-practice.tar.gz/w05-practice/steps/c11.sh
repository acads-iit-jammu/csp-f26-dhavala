# Two kinds of error. Predict which of these two the compiler catches.
# (1) a missing semicolon      (2) area = 2*PI*r  when you meant PI*r*r
sed 's/return 0;/return 0/' src/area.c > ${WORK:-/tmp/w05walk}/broken.c
echo "--- (1) syntax error: ---"
gcc ${WORK:-/tmp/w05walk}/broken.c -o ${WORK:-/tmp/w05walk}/broken 2>&1 | head -2
echo "--- (2) wrong formula, compiled and run: ---"
gcc src/area.c -o ${WORK:-/tmp/w05walk}/area && ${WORK:-/tmp/w05walk}/area
echo "    (r = 3, so the right answer is 28.274)"
