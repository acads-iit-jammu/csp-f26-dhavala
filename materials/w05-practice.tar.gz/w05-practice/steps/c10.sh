# THE AUDIT. Your lab manual, Section 2.9, states in print:
#   "x++ is faster than x = x + 1"
# You now own the instrument to check that instead of believing it.
gcc -S src/plusplus.c -o ${WORK:-/tmp/w05walk}/a.s
gcc -S src/longhand.c -o ${WORK:-/tmp/w05walk}/b.s
if diff -q ${WORK:-/tmp/w05walk}/a.s ${WORK:-/tmp/w05walk}/b.s >/dev/null; then echo "diff: (nothing) - IDENTICAL instructions"
else echo "diff found a difference:"; diff ${WORK:-/tmp/w05walk}/a.s ${WORK:-/tmp/w05walk}/b.s | head; fi
