#!/usr/bin/env bash
# W05 practice — predict first, then run. See README.txt.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; cd "$HERE"
L="$HERE/lessons.txt"; LOG="$HERE/notes/practice.log"
mkdir -p "$HERE/notes"; [ -f "$LOG" ] || : > "$LOG"
export WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
GCCFLAGS="-std=c11 -Wno-error=parentheses"

PREC="p01 p02 p03 p04 p05 p06 p07 p08 p09 p10 p11 p12 p13 p14"
PIPE="c01 c02 c03 c04 c05 c06 c07 c08 c09 c10 c11"
ALL="$PREC $PIPE"

lesson_of(){ grep "^$1|" "$L" | head -1 | cut -d'|' -f3; }
status_of(){ grep -h " $1 " "$LOG" 2>/dev/null | tail -1 | awk '{print $3}'; }

# any pipeline step must work on its own, so build what earlier ones would have
prep(){
  [ -f "$WORK/hello.o" ] || gcc -c src/hello.c     -o "$WORK/hello.o" 2>/dev/null
  [ -f "$WORK/u.o"     ] || gcc -c src/undefined.c -o "$WORK/u.o"     2>/dev/null
  [ -f "$WORK/hello"   ] || gcc "$WORK/hello.o"    -o "$WORK/hello"   2>/dev/null
}

list(){
  echo "=================================================================="
  echo "  W05 practice — predict first, then run."
  local n=0 h=0 s mark
  for grp in PREC PIPE; do
    eval "items=\$$grp"
    [ "$grp" = PREC ] && echo && echo "  PRECEDENCE (predict what it prints)" \
                      || { echo; echo "  THE COMPILER PIPELINE (predict what it does)"; }
    for d in $items; do
      s="$(status_of "$d")"
      case "$s" in HIT) mark="[HIT ]"; n=$((n+1)); h=$((h+1));;
                   MISS) mark="[miss]"; n=$((n+1));;
                   *) mark="[    ]";; esac
      printf "    %s %-4s %s\n" "$mark" "$d" "$(head -1 "$(src_of "$d")" | sed 's|^/\* ||; s|^# ||; s| \*/$||' | cut -c1-52)"
    done
  done
  echo; echo "  done: $n/25   predicted correctly: $h"
  echo "  next: ./practice.sh --all"
  echo "=================================================================="
}

src_of(){ case "$1" in p*) echo "drills/$1.c";; c*) echo "steps/$1.sh";; esac; }

one(){
  local d="$1" src kind out pred verdict rc=0
  src="$(src_of "$d")"
  [ -f "$src" ] || { echo "no such item '$d' (try ./practice.sh)"; return 2; }
  case "$d" in p*) kind=c;; c*) kind=sh;; esac

  echo; echo "=============== $d ==============================================="
  cat "$src"
  echo "-----------------------------------------------------------------"
  [ "$kind" = c ] && printf 'YOUR PREDICTION (what will it print?): ' \
                  || printf 'YOUR PREDICTION (what will it do?): '
  IFS= read -r pred || return 1
  [ -n "$pred" ] || pred="(none)"

  echo; echo "--- what actually happens ---"
  if [ "$kind" = c ]; then
    if gcc $GCCFLAGS "$src" -o "$WORK/x" 2>"$WORK/e"; then out="$("$WORK/x")"; printf '%s\n' "$out"
    else out="(did not compile)"; rc=1; sed 's/^/  /' "$WORK/e" | head -4; fi
  else
    prep; out="$(bash "$src" 2>&1)"; printf '%s\n' "$out" | sed 's/^/  /'
  fi
  echo "-----------------------------"

  local sp sa
  sp="$(printf '%s' "$pred" | tr -d '[:space:]')"; sa="$(printf '%s' "$out" | tr -d '[:space:]')"
  if [ "$kind" = c ] && [ "$rc" = 0 ] && [ -n "$sp" ] && [ "$sp" = "$sa" ]; then
    verdict=HIT; echo "  ** correct **"
  else
    echo "  you said : $pred"
    echo "  it said  : $(printf '%s' "$out" | tr '\n' '~' | sed 's/~$//; s/~/ | /g')"
    printf '  Were you right (wording aside)? [y/N] '
    IFS= read -r yn || yn=n
    case "$yn" in y|Y) verdict=HIT;; *) verdict=MISS;; esac
  fi
  printf '\n'; lesson_of "$d" | fold -s -w 70 | sed -e '1s/^/  >> /' -e '2,$s/^/     /'
  printf '\n'
  printf '%s %s %s pred="%s"\n' "$(date +%FT%T)" "$d" "$verdict" "$pred" >> "$LOG"
}

run_seq(){ for d in $1; do [ -n "$(status_of "$d")" ] || one "$d" || break; done; echo; list; }

case "${1:-}" in
  "")          list;;
  --all)       run_seq "$ALL";;
  --prec)      run_seq "$PREC";;
  --pipeline)  run_seq "$PIPE";;
  --help|-h)   sed -n '2,12p' README.txt;;
  p[0-9][0-9]|c[0-9][0-9]) one "$1";;
  *) echo "unknown option '$1' — try ./practice.sh --help";;
esac
