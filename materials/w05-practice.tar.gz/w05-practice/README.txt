W05 practice — precedence, and the compiler pipeline
====================================================

Everything we did in the Week 5 lecture, so you can do it again yourself.
Nothing here needs a network. Nothing here writes outside this folder.

  ./practice.sh            what is left to do
  ./practice.sh --all      work through everything you have not done
  ./practice.sh p06        just one item
  ./practice.sh --pipeline only the compiler/linker half (c01-c11)
  ./practice.sh --prec     only the precedence half (p01-p14)

Twenty-five items, in two halves:

  p01-p14   PRECEDENCE. Small C programs. Predict what each PRINTS, then it
            compiles and runs, and marks you.

  c01-c11   THE COMPILER PIPELINE. Small command sequences. Predict what the
            PIPELINE does, then they run. You mark yourself on these, because
            the exact text depends on the machine — the lesson does not.

The rule is the same as in the lab: predicting is the exercise, running is
only the marking. A wrong prediction is worth as much as a right one — but
only if you write it down FIRST. Your answers are logged to
notes/practice.log so you can see what to revise.

Everything you need to know is in the comment at the top of each item, plus
the lesson printed after it runs. If you want more: the shared lab manual
(Labs -> Lab Manual on the course site) has the compilation model in Section
2.5 and the precedence table in Section 2.10.
