/* P10 — ! binds tighter than ==.
   a is 5, b is 1. */
#include <stdio.h>
int main(void) {
    int a = 5, b = 1;
    printf("%d %d\n", !a == b, !(a == b));
    return 0;
}
