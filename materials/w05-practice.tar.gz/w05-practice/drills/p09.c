/* P09 — Mathematics lies to you here.
   x is 5. Is 5 between 1 and 3? What will C say? */
#include <stdio.h>
int main(void) {
    int x = 5;
    printf("%d\n", 1 < x < 3);
    return 0;}
