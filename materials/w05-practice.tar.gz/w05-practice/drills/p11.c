/* P11 — [needs & ] The most famous precedence bug in C.
   We wanted to ask "is x even?".  x is 6, so the answer should be YES.
   ( & is bitwise AND — we meet it properly later. x & 1 is x's last bit. ) */
#include <stdio.h>
int main(void) {
    int x = 6;
    printf("%d %d\n", x & 1 == 0, (x & 1) == 0);
    return 0;
}
