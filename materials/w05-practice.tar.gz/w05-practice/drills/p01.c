/* P01 — Precedence just inserts invisible parentheses.
   Three expressions. Two of them are the SAME expression. Which two? */
#include <stdio.h>
int main(void) {
    printf("%d %d %d\n", 2 + 3 * 4, (2 + 3) * 4, 2 + (3 * 4));
    return 0;
}
