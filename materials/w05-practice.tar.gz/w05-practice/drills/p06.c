/* P06 — EQUAL precedence. So what decides?
   * and / sit on the SAME rung of the table. Only associativity breaks the tie. */
#include <stdio.h>
int main(void) {
    printf("%d\n", 100 / 5 * 2);
    return 0;
}
