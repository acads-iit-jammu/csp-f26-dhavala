/* P12 — [needs << ] Shift sits BELOW addition.
   ( << shifts bits left; 1 << n is 2 to the power n. ) */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", 1 << 2 + 3, (1 << 2) + 3);
    return 0;
}
