/* P04 — Associativity: subtraction leans LEFT. */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", 20 - 5 - 3, 20 - (5 - 3));
    return 0;
}
