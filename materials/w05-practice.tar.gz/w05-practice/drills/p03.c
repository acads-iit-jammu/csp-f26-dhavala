/* P03 — Unary minus binds tighter than +.
   How much does the minus sign actually grab? */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", -2 + 3, -(2 + 3));
    return 0;
}
