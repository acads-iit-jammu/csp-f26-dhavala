/* P13 — Precedence says how to GROUP. It does not say what RUNS.
   Watch i. The assignment i = 99 is sitting right there in the expression. */
#include <stdio.h>
int main(void) {
    int i = 0, j = 0;
    int r = (0 && (i = 99));
    int s = (1 && (j = 99));
    printf("r=%d i=%d   s=%d j=%d\n", r, i, s, j);
    return 0;
}
