/* P02 — Reading order is not grouping order.
   You read left to right. Does C evaluate left to right? */
#include <stdio.h>
int main(void) {
    printf("%d\n", 10 - 2 * 3);
    return 0;
}
