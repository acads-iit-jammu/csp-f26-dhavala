/* P14 — The only skill that matters.
   Do not memorise the table. Be able to ADD THE PARENTHESES.
   Write this expression fully parenthesised before you run it. */
#include <stdio.h>
int main(void) {
    int a = 2, b = 3, c = 4, d = 5;
    printf("%d\n", a + b * c - d / 2);
    return 0;
}
