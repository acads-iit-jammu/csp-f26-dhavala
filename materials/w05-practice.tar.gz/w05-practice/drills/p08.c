/* P08 — Comparison sits BELOW arithmetic, and it produces a number. */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", 2 + 3 > 4, 2 + (3 > 4));
    return 0;
}
