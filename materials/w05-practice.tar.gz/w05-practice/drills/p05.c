/* P05 — Assignment leans RIGHT.
   If it leaned left this would be (a = b) = c — which is not even legal. */
#include <stdio.h>
int main(void) {
    int a = 1, b = 2, c = 3;
    a = b = c;
    printf("%d %d %d\n", a, b, c);
    return 0;
}
