/* P07 — The right-hand side is grouped FIRST, whole.
   Is this  x = x - 3 - 1,  or  x = x - (3 - 1) ? */
#include <stdio.h>
int main(void) {
    int x = 10;
    x -= 3 - 1;
    printf("%d\n", x);
    return 0;
}
