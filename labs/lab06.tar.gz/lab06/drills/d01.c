/* D01 - where does an array start?
   The array has 5 elements. What does this print? */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 40, 50 };
    printf("%d %d\n", a[0], a[4]);
    return 0;
}
