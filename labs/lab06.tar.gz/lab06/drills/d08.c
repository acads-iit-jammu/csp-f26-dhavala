/* D08 - the inner limit depends on the outer counter.
   How many stars are on the LAST row? */
#include <stdio.h>
int main(void) {
    int n = 5, last = 0;
    for (int i = 1; i <= n; i++) {
        int c = 0;
        for (int j = 0; j < n - i; j++) c++;
        last = c;
    }
    printf("last row = %d\n", last);
    return 0;
}
