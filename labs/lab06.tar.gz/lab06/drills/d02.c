/* D02 - the loop bound.
   Count the lines before you run it. How many numbers appear? */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 40, 50 };
    for (int i = 0; i < 5; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}
