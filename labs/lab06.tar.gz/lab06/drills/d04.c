/* D04 - a search that finds nothing.
   The value 7 is not in the array. What does this print? */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 40, 50 };
    for (int i = 0; i < 5; i++)
        if (a[i] == 7) printf("found at %d\n", i);
    printf("done\n");
    return 0;
}
