/* D07 - nested loops: how many stars in total?
   Count them before you run it. */
#include <stdio.h>
int main(void) {
    int total = 0;
    for (int i = 1; i <= 4; i++)
        for (int j = 0; j < i; j++)
            total++;
    printf("stars = %d\n", total);
    return 0;
}
