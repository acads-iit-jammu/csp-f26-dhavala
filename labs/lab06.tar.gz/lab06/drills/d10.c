/* D10 - strictly greater, or greater-or-equal?
   The largest value is 30. How many are "above 30"? */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 25, 5 };
    int gt = 0, ge = 0;
    for (int i = 0; i < 5; i++) { if (a[i] > 30) gt++; if (a[i] >= 30) ge++; }
    printf("%d %d\n", gt, ge);
    return 0;
}
