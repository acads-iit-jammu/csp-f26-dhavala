/* D05 - best-so-far, started badly.
   Every value is negative. What does this report as the maximum? */
#include <stdio.h>
int main(void) {
    int a[4] = { -5, -2, -9, -1 };
    int mx = 0;
    for (int i = 0; i < 4; i++) if (a[i] > mx) mx = a[i];
    printf("max = %d\n", mx);
    return 0;
}
