/* D09 - a sliding window near the edge.
   The array has 6 elements and the window is 3 wide.
   How many positions can the window take? */
#include <stdio.h>
int main(void) {
    int a[6] = { 1, 2, 3, 4, 5, 6 }, w = 3, count = 0;
    for (int i = 0; i + w <= 6; i++) count++;
    (void)a;
    printf("positions = %d\n", count);
    return 0;
}
