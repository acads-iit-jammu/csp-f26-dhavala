/* D06 - the counter that never resets.
   How long is the longest run of zeros? What does this say? */
#include <stdio.h>
int main(void) {
    int a[7] = { 0, 0, 5, 0, 0, 0, 9 };
    int run = 0;
    for (int i = 0; i < 7; i++)
        if (a[i] == 0) run++;
    printf("longest run = %d\n", run);
    return 0;
}
