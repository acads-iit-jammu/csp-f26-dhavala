/* D03 - day numbers and index numbers are not the same thing.
   rain[] holds 14 days. What was the rainfall on DAY 6? */
#include <stdio.h>
int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };
    printf("rain[6] = %d\n", rain[6]);
    printf("day 6   = %d\n", rain[6-1]);
    return 0;
}
