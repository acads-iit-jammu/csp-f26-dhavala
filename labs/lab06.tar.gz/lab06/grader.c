/* Lab 03 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e5          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 8      /* headroom: a problem may need extra public vectors to pin its own trap */
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}


/* ---- full-output comparison (for problems that print a grid) ------------
   Compares the WHOLE output, line by line, after normalising whitespace:
   runs of blanks collapse to one, ends are trimmed, blank lines are dropped.
   So printf alignment is the student's business, not the grader's - what is
   checked is the right values in the right order on the right rows.
   Prompts are allowed: a leading prompt on the first line is tolerated by
   letting the expected text match at the END of that line.               */
#define BLANKCH(ch) ((ch)==' ' || (ch)=='\t' || (ch)=='\n' || (ch)=='\r')
static void squeeze(const char *in, char *out, int n) {
    int i = 0, sp = 0; const char *p = in;
    while (BLANKCH(*p)) p++;
    for (; *p && i < n-1; p++) {
        if (BLANKCH(*p)) { sp = 1; continue; }
        if (sp && i > 0) out[i++] = ' ';
        sp = 0;
        if (i < n-1) out[i++] = *p;
    }
    out[i] = 0;
}

static int cmp_full(const char *path, const char *expected, char *why, int wn) {
    char eb[4096]; strncpy(eb, expected, sizeof eb - 1); eb[sizeof eb - 1] = 0;
    FILE *f = fopen(path, "r");
    if (!f) { snprintf(why, wn, "produced no output at all"); return 1; }

    char gl[1024], gs[1024], es[1024];
    char *esave = eb, *eline;
    int row = 0;
    for (;;) {
        /* next non-blank expected line */
        do { eline = strsep(&esave, "\n"); } while (eline && *eline == 0);
        /* next non-blank produced line */
        int have = 0;
        while (fgets(gl, sizeof gl, f)) { squeeze(gl, gs, sizeof gs); if (gs[0]) { have = 1; break; } }
        if (!eline && !have) { fclose(f); return 0; }                 /* both ended together */
        if (!eline) { snprintf(why, wn, "extra output after line %d: \"%s\"", row, gs); fclose(f); return 1; }
        if (!have)  { snprintf(why, wn, "output stopped early - line %d is missing (expected \"%s\")", row+1, eline); fclose(f); return 1; }
        row++;
        squeeze(eline, es, sizeof es);
        size_t glen = strlen(gs), elen = strlen(es);
        int ok = (glen >= elen) && strcmp(gs + glen - elen, es) == 0;   /* allow a prompt in front */
        if (!ok) { snprintf(why, wn, "line %d differs\n             you printed : \"%s\"\n             expected     : \"%s\"", row, gs, es);
                   fclose(f); return 1; }
    }
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label, int full) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    if (full) {
        char why[1024] = "";
        if (cmp_full(".gout", expected, why, sizeof why) == 0) {
            printf("  PASS     [%s] input: %s\n", label, input);
            return 0;
        }
        printf("  WRONG    [%s] input: %s\n           %s\n", label, input, why);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) --- */
/* The month every problem works on. The STARTERS carry the same table;
   only the QUERY on stdin changes from vector to vector.                */
#define NDAYS 14
static const int RAIN[NDAYS] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };

static void gen_b1(char *in, char *exp) {                 /* sum 1..n  (pure loop) */
    int n = rand()%50 + 1;
    sprintf(in, "%d", n);
    sprintf(exp, "total=%d", n*(n+1)/2);
}
static void gen_b2(char *in, char *exp) {                 /* right triangle, n rows */
    int n = rand()%6 + 2, i, j;
    sprintf(in, "%d", n);
    exp[0] = 0;
    for (i = 1; i <= n; i++) {
        for (j = 0; j < i; j++) strcat(exp, "*");
        if (i < n) strcat(exp, "\n");
    }
}
static void gen_b3(char *in, char *exp) {                 /* rainfall over the first k days */
    int k = rand()%NDAYS + 1, i, s = 0;
    for (i = 0; i < k; i++) s += RAIN[i];
    sprintf(in, "%d", k);
    sprintf(exp, "total=%d", s);
}
static void gen_b4(char *in, char *exp) {                 /* wettest of the first k days */
    int k = rand()%NDAYS + 1, i, mx = -1, md = 0;
    for (i = 0; i < k; i++) if (RAIN[i] > mx) { mx = RAIN[i]; md = i+1; }
    sprintf(in, "%d", k);
    sprintf(exp, "max=%d day=%d", mx, md);
}
static void gen_b5(char *in, char *exp) {                 /* dry days among the first k */
    int k = rand()%NDAYS + 1, i, dry = 0;
    for (i = 0; i < k; i++) if (RAIN[i] == 0) dry++;
    sprintf(in, "%d", k);
    sprintf(exp, "dry=%d", dry);
}
static void gen_e1(char *in, char *exp) {                 /* FIRST day with exactly R mm */
    int R, i, d = -1;
    /* half the draws are values that really occur, so "never" is not the usual answer */
    if (rand()%2) R = RAIN[rand()%NDAYS]; else R = rand()%31;
    for (i = 0; i < NDAYS; i++) if (RAIN[i] == R) { d = i+1; break; }
    sprintf(in, "%d", R);
    if (d > 0) sprintf(exp, "day=%d", d); else sprintf(exp, "never");
}
static void gen_e2(char *in, char *exp) {                 /* days with rain strictly above T */
    int T = rand()%31, i, c = 0;
    for (i = 0; i < NDAYS; i++) if (RAIN[i] > T) c++;
    sprintf(in, "%d", T);
    sprintf(exp, "count=%d", c);
}
static void gen_e3(char *in, char *exp) {                 /* longest run of days with rain <= T */
    int T = rand()%31, i, best = 0, end = 0, cur = 0;
    for (i = 0; i < NDAYS; i++) {
        if (RAIN[i] <= T) { cur++; if (cur > best) { best = cur; end = i+1; } }
        else cur = 0;
    }
    sprintf(in, "%d", T);
    sprintf(exp, "longest=%d ending=%d", best, end);
}
static void gen_e4(char *in, char *exp) {                 /* hollow square border, n x n */
    int n = rand()%6 + 3, i, j;
    sprintf(in, "%d", n);
    exp[0] = 0;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            int e = i; if (j < e) e = j; if (n-1-i < e) e = n-1-i; if (n-1-j < e) e = n-1-j;
            strcat(exp, e == 0 ? "*" : " ");
        }
        if (i < n-1) strcat(exp, "\n");
    }
}
static void gen_e5(char *in, char *exp) {                 /* wettest w-day window */
    int w = rand()%12 + 2, i, j, best = -1, bs = 0;
    for (i = 0; i + w <= NDAYS; i++) {
        int s = 0; for (j = 0; j < w; j++) s += RAIN[i+j];
        if (s > best) { best = s; bs = i+1; }
    }
    sprintf(in, "%d", w);
    sprintf(exp, "start=%d total=%d", bs, best);
}

struct problem {
    const char *name;
    const char *src;
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
    int full;                   /* 1 = compare the whole output, not just the last line */
};
static struct problem P[] = {
 {"b1", "b1_sum.c",       4, 2, {"5","1","10","50"},   {"total=15","total=1","total=55","total=1275"}, gen_b1, 0},
 {"b2", "b2_triangle.c",  3, 2, {"3","1","7"},
        {"*\n**\n***","*","*\n**\n***\n****\n*****\n******\n*******"}, gen_b2, 1},
 {"b3", "b3_total.c",     3, 2, {"5","14","1"},        {"total=17","total=79","total=0"}, gen_b3, 0},
 {"b4", "b4_wettest.c",   3, 2, {"5","14","1"},        {"max=12 day=2","max=30 day=6","max=0 day=1"}, gen_b4, 0},
 {"b5", "b5_dry.c",       3, 2, {"5","14","1"},        {"dry=3","dry=7","dry=1"}, gen_b5, 0},
 {"e1", "e1.c",           5, 3, {"12","6","0","18","4"},
        {"day=2","never","day=1","day=13","day=14"}, gen_e1, 0},
 {"e2", "e2.c",           4, 3, {"0","5","15","30"},   {"count=7","count=4","count=2","count=0"}, gen_e2, 0},
 {"e3", "e3.c",           4, 3, {"0","2","7","30"},
        {"longest=3 ending=10","longest=5 ending=12","longest=5 ending=12","longest=14 ending=14"}, gen_e3, 0},
 {"e4", "e4.c",           3, 3, {"3","5","8"},
        {"***\n* *\n***","*****\n*   *\n*   *\n*   *\n*****",
         "********\n*      *\n*      *\n*      *\n*      *\n*      *\n*      *\n********"}, gen_e4, 1},
 {"e5", "e5.c",           6, 3, {"2","3","5","4","7","13"},
        {"start=6 total=38","start=5 total=43","start=2 total=47",
         "start=4 total=43","start=1 total=55","start=2 total=79"}, gen_e5, 0},
};

int main(int argc, char **argv) {
    /* ./grader --count e1   prints how many vectors e1 has, and exits.
       check-ta.sh uses this so partial credit never has to guess a total. */
    if (argc == 3 && strcmp(argv[1], "--count") == 0) {
        for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
            if (strcmp(P[i].name, argv[2]) == 0) { printf("%d\n", P[i].npub + P[i].nrand); return 0; }
        return 2;
    }
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e5   |   ./grader --count PROB\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public", p->full);
    for (int i = 0; i < p->nrand; i++) {
        char in[128], exp[4096];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random", p->full);
    }
    return failed;
}
