#!/usr/bin/env bash
# ./drill.sh          list the drills and your progress
# ./drill.sh p03      do one drill      (also: ./drill.sh t01, ./drill.sh L4)
# ./drill.sh --all    work through every drill you have not done yet
#
# Each drill: you SEE it, you WRITE your prediction, and only THEN does it run.
# Predicting is the exercise. Running is just the marking.
#
# Two kinds this week:
#   t01, p01-p04   C programs  - predict what they PRINT
#   L1-L5          commands    - predict what the COMPILER PIPELINE does
set -u

if [ ! -f TEAM.txt ]; then
  echo "STOP: this is not your workspace (no TEAM.txt here)."
  echo "Run:  ./where.sh    — it will tell you exactly what to type."
  exit 2
fi

LOG=notes/drills.log
mkdir -p notes; [ -f "$LOG" ] || : > "$LOG"
ALL="d01 d02 d03 d04 d05 d06 d07 d08 d09 d10"
GCCFLAGS="-std=c11 -Wno-error=parentheses"

status_of(){ grep -h "^[^ ]* $1 " "$LOG" 2>/dev/null | tail -1 | awk '{print $3}'; }

label_of(){
  case "$1" in
    d0[123]) echo "(indexing)";;
    d0[456]) echo "(searching / accumulating)";;
    d0[789]) echo "(nested loops / windows)";;
    *)       echo "(comparisons)";;
  esac
}

# Some drills here loop forever on purpose. Cap every run so a drill cannot
# hang the machine: timeout(1) on Linux, else gtimeout, else a perl alarm.
if   command -v timeout  >/dev/null 2>&1; then CAP="timeout 5 "
elif command -v gtimeout >/dev/null 2>&1; then CAP="gtimeout 5 "
elif command -v perl     >/dev/null 2>&1; then
  CAP="perl -e 'my \$p=fork; unless(\$p){exec @ARGV; exit 127} \$SIG{ALRM}=sub{kill \"KILL\",\$p; waitpid(\$p,0); exit 124}; alarm(5); waitpid(\$p,0); exit(\$? >> 8)' "
else CAP=""
fi

list(){
  echo "=================================================================="
  echo "  Lab 06 drills — predict first, then run."
  echo
  local done=0 hit=0 s mark
  for d in $ALL; do
    s="$(status_of "$d")"
    case "$s" in
      HIT)  mark="[HIT ]"; done=$((done+1)); hit=$((hit+1));;
      MISS) mark="[miss]"; done=$((done+1));;
      *)    mark="[    ]";;
    esac
    printf "  %s %-4s %s\n" "$mark" "$d" "$(label_of "$d")"
  done
  echo
  echo "  done: $done/10   predicted correctly: $hit"
  echo "  next:  ./drill.sh --all"
  echo "=================================================================="
}

one(){
  local d="$1" csrc="drills/$1.c" ssrc="drills/$1.sh" kind out rc pred verdict
  if   [ -f "$csrc" ]; then kind=c
  elif [ -f "$ssrc" ]; then kind=sh
  else echo "drill.sh: no such drill '$d' (try ./drill.sh)"; return 2; fi

  echo
  echo "=============== DRILL $d $(label_of "$d") ========================="
  [ "$kind" = c ] && cat "$csrc" || cat "$ssrc"
  echo "-------------------------------------------------------------------"
  if [ "$kind" = c ]; then
    printf 'YOUR PREDICTION (what will it print?): '
  else
    printf 'YOUR PREDICTION (what will these commands do?): '
  fi
  IFS= read -r pred || return 1
  [ -n "$pred" ] || pred="(no prediction)"

  echo
  echo "--- what actually happens ---"
  if [ "$kind" = c ]; then
    if out="$(gcc $GCCFLAGS "$csrc" -o ".drill_$d" 2>&1)"; then
      out="$( ( eval "$CAP./.drill_$d" ) 2>&1; printf 'X')"; out="${out%X}"
      rc=0
      case "$out" in *"$(printf '\n')") ;; esac
      printf '%s' "$out"
      case "$out" in *$'\n') ;; *) printf '   <-- (no newline at the end!)\n';; esac
    else
      rc=1
      echo "COMPILE ERROR — the compiler said:"
      printf '%s\n' "$out" | head -4 | sed 's/^/    /'
    fi
    rm -f ".drill_$d"
  else
    out="$(bash "$ssrc" 2>&1)"; rc=0
    printf '%s\n' "$out" | sed 's/^/    /'
  fi
  echo "-----------------------------"

  # C drills auto-mark (whitespace-insensitive). Pipeline drills are self-marked:
  # their exact text depends on the machine, and the LESSON is not the text.
  local squash_p squash_a
  squash_p="$(printf '%s' "$pred" | tr -d '[:space:]')"
  squash_a="$(printf '%s' "$out"  | tr -d '[:space:]')"
  if [ "$kind" = c ] && [ "$rc" = 0 ] && [ -n "$squash_p" ] && [ "$squash_p" = "$squash_a" ]; then
    verdict=HIT
    echo "  ** correct — you predicted it exactly. **"
  else
    echo "  you said : $pred"
    if [ "$kind" = c ] && [ "$rc" != 0 ]; then
      echo "  it said  : (it did not compile)"
    else
      echo "  it said  : $(printf '%s' "$out" | tr '\n' '~' | sed 's/~$//; s/~/ [newline] /g')"
    fi
    printf '  Were you right (wording aside)? [y/N] '
    IFS= read -r yn || yn=n
    case "$yn" in y|Y) verdict=HIT;; *) verdict=MISS;; esac
  fi

  printf '%s %s %s pred="%s"\n' "$(date +%FT%T)" "$d" "$verdict" "$pred" >> "$LOG"
  [ "$verdict" = MISS ] && echo "  logged as a miss — that is the useful kind. Ask why before moving on."
  return 0
}

case "${1:-}" in
  "")     list;;
  --all)  for d in $ALL; do [ -n "$(status_of "$d")" ] || one "$d" || break; done; echo; list;;
  --help|-h) sed -n '2,13p' "$0";;
  *)      arg="$1"
          case "$arg" in
            l[0-9]) arg="L${arg#l}";;
            [0-9])  arg="p0$arg";;
          esac
          one "$arg";;
esac
