Lab 06 — Loops and Arrays
=========================

Everything happens INSIDE your workspace. If your prompt does not say
[lab06 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            d01-d03  indexing, and day-number vs index
                            d04-d06  searching, best-so-far, counters
                            d07-d09  nested loops and sliding windows
                            d10      > versus >=
  4.  fill the blanks:  b1_sum.c   b2_triangle.c   b3_total.c
                        b4_wettest.c   b5_dry.c
  5.  the checked five: e1.c  e2.c  e3.c  e4.c  e5.c
  6.  ./check.sh            self-check, with your marks so far
  7.  ./check.sh --bundle   bundle it, carry it out

Every array problem works on the SAME fourteen days of rainfall, already
written into each starter. What changes is the QUESTION, which arrives on
standard input. Read the GIVEN in each file to see what that input is.

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler has never heard of, so it tells you exactly which line is
still waiting for you.

Drills are NOT marked. They are how you find out what you have wrong before
it costs you anything.
