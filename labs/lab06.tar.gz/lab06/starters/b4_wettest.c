/* B4 (fill the blanks) - the wettest of the first k days.
   GIVEN   : one integer k, 1..14
   ENSURES : final line ends with:  max=<M> day=<D>
             If two days tie for wettest, report the EARLIER one.
   EXAMPLE : input "5"  -> "max=12 day=2"
             input "14" -> "max=30 day=6"
   CHECK   : ./check.sh b4
   Best-so-far, and keep the DAY as well as the value - the number on its
   own does not answer the question that was asked.                       */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int k, i, mx = -1, md = 0;

    printf("Enter k: ");
    TODO_read_k;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2: track both the wettest value and its day */

    printf("max=%d day=%d\n", mx, md);                  /* given - do not change */
    return 0;
}
