/* E2 - how many days were wetter than T?                        [checked]
   GIVEN   : one integer T, 0..30
   ENSURES : final line ends with:  count=<N>
             a day counts when its rainfall is STRICTLY greater than T
   EXAMPLE : "0"  -> "count=7"      "5"  -> "count=4"
             "15" -> "count=2"      "30" -> "count=0"
   CHECK   : ./check.sh e2
   Read that last example again. Thirty is the wettest day there is, and
   nothing is strictly greater than it - so the answer is 0, not 1. The
   difference between > and >= is the whole problem.                       */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int T, i, count = 0;

    printf("Enter T: ");
    TODO_read_T;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2 */

    printf("count=%d\n", count);                     /* given - do not change */
    return 0;
}
