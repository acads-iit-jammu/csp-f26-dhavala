/* E5 - the wettest stretch of w consecutive days.               [checked]
   GIVEN   : one integer w, 2..13
   ENSURES : final line ends with:  start=<S> total=<T>
             S is the first day of the wettest run of w days in a row,
             T is that run's total rainfall.  On a tie, report the EARLIEST.
   EXAMPLE : "2"  -> "start=6 total=38"     (days 6 and 7: 30 + 8)
             "3"  -> "start=5 total=43"
             "5"  -> "start=2 total=47"
             "13" -> "start=2 total=79"     <-- w can be nearly the month
   CHECK   : ./check.sh e5
   A window that slides. The outer loop chooses where the window starts;
   the inner loop adds up the w days from there. Two questions to settle
   BEFORE you write the loop:
     - how far can the window start and still fit inside the month?
     - the array is indexed from 0, but days are numbered from 1.
   Get either wrong and you will read past the end of the array, which C
   will not warn you about.                                                */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int w, i, j, best = -1, beststart = 0;

    printf("Enter w: ");
    TODO_read_w;                 /* TODO 1 */

    TODO_windows;                /* TODO 2: slide the window, keep the best */

    printf("start=%d total=%d\n", beststart, best);  /* given - do not change */
    return 0;
}
