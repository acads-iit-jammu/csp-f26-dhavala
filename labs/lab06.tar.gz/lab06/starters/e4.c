/* E4 - a hollow square border, n by n.                          [checked]
   GIVEN   : one integer n, 3..8
   ENSURES : an n x n grid in which a cell is a star when it lies on the
             OUTER BORDER, and a space otherwise.
   EXAMPLE : input "3"        input "5"
                 ***              *****
                 * *              *   *
                 ***              *   *
                                  *   *
                                  *****
   CHECK   : ./check.sh e4
   Nested loops, no array. A cell (i, j) is on the border when it touches
   an edge - that is, when its distance to the NEAREST edge is zero. There
   are four edges, so there are four distances: i, j, n-1-i and n-1-j.
   Which of them decides?
   The checker does not care how you space the line; it cares which cells
   are stars.                                                              */
#include <stdio.h>

int main(void) {
    int n, i, j;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1 */

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            TODO_cell;           /* TODO 2: star or space? */
        }
        putchar('\n');
    }
    return 0;
}
