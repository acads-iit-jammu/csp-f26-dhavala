/* B2 (fill the blanks) - a right triangle of stars, n rows. [no array here]
   GIVEN   : one integer n, 1..7
   ENSURES : row i carries exactly i stars IN A ROW - no spaces between
             them - for i = 1 .. n
   EXAMPLE : input "3" ->   *
                            **
                            ***
   CHECK   : ./check.sh b2
   NESTED loops: the outer one picks the row, the inner one decides what
   goes on it - and the inner limit DEPENDS on the outer counter.
   The checker ignores spaces at the END of a line, nothing else. */
#include <stdio.h>

int main(void) {
    int n, i, j;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1 */

    for (i = 1; i <= n; i++) {
        TODO_inner;              /* TODO 2: how many stars on row i? */
        putchar('\n');
    }
    return 0;
}
