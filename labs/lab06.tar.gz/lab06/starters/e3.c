/* E3 - the longest dry spell.                                   [checked]
   GIVEN   : one integer T, 0..30.  A day counts as "dry enough" when its
             rainfall is T or less.
   ENSURES : final line ends with:  longest=<L> ending=<D>
             L is the length of the longest UNBROKEN run of dry-enough days
             D is the day that run ended on.  If two runs are equally
             long, report the one that ENDS EARLIER.
   EXAMPLE : "0"  -> "longest=3 ending=10"     (days 8, 9, 10 all had 0)
             "2"  -> "longest=5 ending=12"
             "30" -> "longest=14 ending=14"    (every day qualifies)
   CHECK   : ./check.sh e3
   This one is different from anything you have written. You need TWO
   counters: how long the run you are currently in is, and how long the
   best run so far was. A day that is too wet does not just fail to count -
   it RESETS the current run to zero.
   Work "0" out on paper first, day by day, before writing any code.       */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int T, i, current = 0, longest = 0, ending = 0;

    printf("Enter T: ");
    TODO_read_T;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2: extend the run, or break it */

    printf("longest=%d ending=%d\n", longest, ending);   /* given - do not change */
    return 0;
}
