/* B3 (fill the blanks) - total rainfall over the first k days.
   GIVEN   : one integer k, 1..14
   ENSURES : final line ends with:  total=<T>
   EXAMPLE : input "5" -> "total=17"      (0 + 12 + 0 + 0 + 5)
             input "14" -> "total=79"
   CHECK   : ./check.sh b3
   The month is already in the array. Your job is the loop - and its LIMIT.
   Careful: day k is stored at index k-1.                                 */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int k, i, total = 0;

    printf("Enter k: ");
    TODO_read_k;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2: add up the first k days */

    printf("total=%d\n", total);                  /* given - do not change */
    return 0;
}
