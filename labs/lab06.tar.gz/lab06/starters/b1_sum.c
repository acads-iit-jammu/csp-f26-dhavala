/* B1 (fill the blanks) - add up 1 + 2 + ... + n.            [no array here]
   GIVEN   : one integer n, 1..50
   ENSURES : final line ends with:  total=<T>
   EXAMPLE : input "5" -> "total=15"
   CHECK   : ./check.sh b1
   A warm-up on last week's machinery, before the arrays start.            */
#include <stdio.h>

int main(void) {
    int n, i, total = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2 */

    printf("total=%d\n", total);                     /* given - do not change */
    return 0;
}
