/* E1 - on which day did it first rain exactly R mm?             [checked]
   GIVEN   : one integer R, 0..30
   ENSURES : final line ends with exactly one of:
                 day=<D>     D is the FIRST day whose rainfall is exactly R
                 never       no day in the month recorded exactly R
   EXAMPLE : "12" -> "day=2"      "0"  -> "day=1"
             "18" -> "day=13"     "6"  -> "never"     <-- this one matters
   CHECK   : ./check.sh e1
   A search with a NOT-FOUND case, which is where most searches go wrong.
   A loop that simply prints nothing when it finds nothing has not answered
   the question - "never" IS the answer, and your program must be able to
   tell the difference between "not found yet" and "not there at all".
   Stop at the FIRST match: the spec says first, and there is no reason to
   keep looking once you have it.                                          */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int R, i;

    printf("Enter R: ");
    TODO_read_R;                 /* TODO 1 */

    TODO_search;                 /* TODO 2: the search, and how you remember the outcome */

    TODO_report;                 /* TODO 3: day=<D>, or never */
    return 0;
}
