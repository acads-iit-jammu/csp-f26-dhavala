/* B5 (fill the blanks) - how many of the first k days were dry.
   GIVEN   : one integer k, 1..14
   ENSURES : final line ends with:  dry=<N>          (a dry day has rain 0)
   EXAMPLE : input "5" -> "dry=3"       input "14" -> "dry=7"
   CHECK   : ./check.sh b5
   Counting is the third thing a loop over an array does, after summing
   and searching. Note it is rain == 0 exactly, not rain < something.     */
#include <stdio.h>

int main(void) {
    int rain[14] = { 0, 12, 0, 0, 5, 30, 8, 0, 0, 0, 2, 0, 18, 4 };   /* given - do not change */
    int k, i, dry = 0;

    printf("Enter k: ");
    TODO_read_k;                 /* TODO 1 */

    TODO_loop;                   /* TODO 2 */

    printf("dry=%d\n", dry);                  /* given - do not change */
    return 0;
}
