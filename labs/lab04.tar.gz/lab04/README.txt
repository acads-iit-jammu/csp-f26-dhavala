Lab 04 — Loops
==============

Everything happens INSIDE your workspace. If your prompt does not say
[lab04 OK ...], you are not in it — run ./where.sh and it will tell you
exactly what to type.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            t01        one type conversion
                            p01-p04    precedence, aimed at loop conditions
                            L1-L5      the compiler pipeline, by hand
  4.  fill the blanks:  b1_sum_while.c   b2_sum_for.c   b3_digits.c
                        b4_factorial.c   b5_digits0.c
  5.  the checked three: e1.c  e2.c  e3.c
  6.  ./check.sh            self-check      ./check.sh e2   just one
  7.  ./check.sh --bundle   bundle it, carry it out

New this week: the starters give you the declarations and the final
printf, but NOT the scanf. You write the reading as well as the thinking.

The starters do not compile as shipped — that is deliberate. Each TODO is
a name the compiler will not recognise, so it tells you exactly which line
is still waiting for you.

Reference: the shared lab manual (Labs -> Lab Manual on the course site)
covers the compilation model in Section 2.5 and the precedence table in
Section 2.10. This sheet stands on its own; the manual is there for more.
