#!/usr/bin/env bash
# ./where.sh — "Am I in the right place?"
# Safe to run from ANYWHERE. It never changes anything; it only tells you
# where you are, where your workspace is, and the exact line to type.
set -u
BASE="${CSP_BASE:-/home/student/csp_labs_f26}"
[ -d "$BASE" ] || BASE="$HOME"

echo "=================================================================="
echo "  You are here :  $PWD"

# Case 1 — this IS a workspace.
if [ -f TEAM.txt ]; then
  echo "  Status      :  CORRECT — this is your workspace."
  echo "                 team: $(sed -n 's/^rolls: //p' TEAM.txt)"
  echo
  n_prog=$(ls ./*.c 2>/dev/null | wc -l | tr -d ' ')
  echo "  Programs here: $n_prog"
  if [ -s session.txt ]; then
    echo "  Recorder     : running/recorded (session.txt)"
  else
    echo "  Recorder     : NOT STARTED — type:  script session.txt"
  fi
  case "${PS1:-}" in
    *lab04*) : ;;
    *) echo "  Prompt       : not set — type:  source env.sh";;
  esac
  echo "=================================================================="
  exit 0
fi

# Case 2 — not a workspace. Find the student's.
echo "  Status      :  WRONG PLACE — no TEAM.txt here."
echo

found=""
for d in "$BASE"/w[0-9][0-9]-l[0-9][0-9]-*-sd "$BASE"/w[0-9][0-9]-l[0-9][0-9]-*-sd-*; do
  [ -d "$d" ] && [ -f "$d/TEAM.txt" ] && found="$found $d"
done

if [ -z "$found" ]; then
  echo "  No workspace exists yet under:  $BASE"
  echo
  echo "  You have not installed the lab. Type:"
  echo
  echo "      cd ~ && tar xzf lab04.tar.gz && cd lab04 && ./install.sh"
else
  best=""
  for d in $found; do best="$d"; done      # last = highest week/lab
  echo "  Your workspace is:"
  echo
  echo "      $best"
  echo
  echo "  COPY THIS LINE AND PRESS ENTER:"
  echo
  echo "      cd $best && source env.sh"
  n=$(echo $found | wc -w | tr -d ' ')
  [ "$n" -gt 1 ] && { echo; echo "  (You have $n workspaces; the newest is shown. All of them:"; for d in $found; do echo "     $d"; done; echo "  )"; }
fi
echo "=================================================================="
exit 1
