/* Lab 03 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e3          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 3
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) --- */
static int digits_of(int n){ int d=0; if(n==0) return 1; while(n>0){d++;n/=10;} return d; }
static int rev_of(int n){ int r=0; while(n>0){ r=r*10+n%10; n/=10; } return r; }
static int gcd_of(int a,int b){ while(b){ int t=a%b; a=b; b=t; } return a; }

static void gen_b1(char *in, char *exp) {                 /* sum 1..n, while */
    int n = rand()%100 + 1;
    sprintf(in, "%d", n);
    sprintf(exp, "sum=%d", n*(n+1)/2);
}
static void gen_b2(char *in, char *exp) { gen_b1(in, exp); }   /* same contract, for-loop */
static void gen_b3(char *in, char *exp) {                 /* digit count, n >= 1 */
    int n = rand()%1000000 + 1;
    sprintf(in, "%d", n);
    sprintf(exp, "digits=%d", digits_of(n));
}
static void gen_b4(char *in, char *exp) {                 /* factorial, n <= 12 */
    int n = rand()%12 + 1, i; long f = 1;
    for (i = 2; i <= n; i++) f *= i;
    sprintf(in, "%d", n);
    sprintf(exp, "fact=%ld", f);
}
static void gen_b5(char *in, char *exp) {                 /* digit count, n may be 0 */
    int n = (rand()%5 == 0) ? 0 : rand()%1000000;         /* 0 shows up often on purpose */
    sprintf(in, "%d", n);
    sprintf(exp, "digits=%d", digits_of(n));
}
static void gen_e1(char *in, char *exp) {                 /* evens in 1..n */
    int n = rand()%1000 + 1, k = n/2;                     /* k evens: 2..2k */
    sprintf(in, "%d", n);
    sprintf(exp, "sum=%d count=%d", k*(k+1), k);
}
static void gen_e2(char *in, char *exp) {                 /* reverse the digits */
    int n = rand()%1000000 + 1;
    sprintf(in, "%d", n);
    sprintf(exp, "rev=%d", rev_of(n));
}
static void gen_e3(char *in, char *exp) {                 /* gcd */
    int a = rand()%1000 + 1, b = rand()%1000 + 1;
    sprintf(in, "%d %d", a, b);
    sprintf(exp, "gcd=%d", gcd_of(a,b));
}

struct problem {
    const char *name;
    const char *src;            /* source file to compile */
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
};
static struct problem P[] = {
 {"b1", "b1_sum_while.c", 2, 2, {"5","1"},
        {"sum=15","sum=1"}, gen_b1},
 {"b2", "b2_sum_for.c",   2, 2, {"5","100"},
        {"sum=15","sum=5050"}, gen_b2},
 {"b3", "b3_digits.c",    2, 2, {"1204","7"},
        {"digits=4","digits=1"}, gen_b3},
 {"b4", "b4_factorial.c", 2, 2, {"5","1"},
        {"fact=120","fact=1"}, gen_b4},
 {"b5", "b5_digits0.c",   2, 2, {"0","1204"},
        {"digits=1","digits=4"}, gen_b5},
 {"e1", "e1.c",           3, 3, {"10","47","1"},
        {"sum=30 count=5","sum=552 count=23","sum=0 count=0"}, gen_e1},
 {"e2", "e2.c",           3, 3, {"1204","900","7"},
        {"rev=4021","rev=9","rev=7"}, gen_e2},
 {"e3", "e3.c",           3, 3, {"48 18","17 5","1000 1000"},
        {"gcd=6","gcd=1","gcd=1000"}, gen_e3},
};

int main(int argc, char **argv) {
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e3\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public");
    for (int i = 0; i < p->nrand; i++) {
        char in[128], exp[256];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random");
    }
    return failed;
}
