/* P01 — a comparison is a VALUE, not a question.
   This is what a loop condition really is. What number is it? */
#include <stdio.h>
int main(void) {
    int i = 0, n = 5;
    printf("%d\n", i < n);
    return 0;
}
