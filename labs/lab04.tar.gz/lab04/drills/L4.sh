# L4 - which stage complains?
# drills/undefined.c calls foo(), which is declared but never defined anywhere.
# Predict TWO things: does -c (stop after the assembler) succeed?
# Does a full build (all four stages) succeed?
gcc -c drills/undefined.c -o /tmp/l4.o 2>/dev/null; echo "gcc -c  exit: $?"
gcc /tmp/l4.o -o /tmp/l4 2>/dev/null;              echo "linking exit: $?"
rm -f /tmp/l4.o /tmp/l4
