/* P04 — assignment has a value too.
   Note: ONE equals sign, not two. This compiles, and it is why
   while (i = 0) and while (i == 0) are different programs. */
#include <stdio.h>
int main(void) {
    int i = 0;
    printf("%d\n", i = 3);
    return 0;
}
