/* The subject of the pipeline drills L1-L5. Five lines. Remember that. */
#include <stdio.h>
#define GREETING "Hello, world!"
int main(void) { printf("%s\n", GREETING); return 0; }
