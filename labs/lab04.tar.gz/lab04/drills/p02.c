/* P02 — mathematics lies to you here.
   n is 5. Is 5 between 0 and 3? Read it the way C must read it:
   left to right, one comparison at a time. */
#include <stdio.h>
int main(void) {
    int n = 5;
    printf("%d\n", 0 < n < 3);
    return 0;
}
