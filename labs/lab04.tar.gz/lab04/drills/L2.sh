# L2 - object code is real machine code. Can you run it?
# -c stops after stage 3 (the assembler) and writes hello.o.
# Predict: does ./hello.o print Hello, world!, or something else?
gcc -c drills/hello.c -o /tmp/l2_hello.o
/tmp/l2_hello.o 2>/dev/null
echo "exit code: $?"
rm -f /tmp/l2_hello.o
