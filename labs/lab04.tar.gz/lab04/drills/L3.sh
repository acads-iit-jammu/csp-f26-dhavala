# L3 - what does hello.o actually contain?
# nm lists the names in an object file. T means "defined here, at this address".
# U means "undefined - used, but its code is somewhere else".
# Predict: which of main and printf gets an address, and which gets U?
gcc -c drills/hello.c -o /tmp/l3_hello.o
nm /tmp/l3_hello.o | grep -Ei 'main|printf'
rm -f /tmp/l3_hello.o
