/* Used by drill L4. Note what is missing: foo() is DECLARED but never defined. */
#include <stdio.h>
void foo(void);
int main(void) { foo(); return 0; }
