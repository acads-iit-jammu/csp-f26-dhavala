# L5 - and then the linker finishes the job.
# Same file as L3, but built all the way through to an executable.
# Predict THREE things: does it run? is printf still U? if so, where does
# printf actually come from?
gcc drills/hello.c -o /tmp/l5_hello
/tmp/l5_hello
nm /tmp/l5_hello | grep -Ei ' t _?main| u _?printf'
if command -v ldd >/dev/null 2>&1; then ldd /tmp/l5_hello | head -2
else otool -L /tmp/l5_hello | head -2; fi
rm -f /tmp/l5_hello
