# L5 - and then the linker resolves it.
# Same file as L3, but built all the way through to an executable.
# Predict: is printf still U? And does the program run now?
gcc drills/hello.c -o /tmp/l5_hello
nm /tmp/l5_hello | grep -Ei ' t main| t _main' | head -1
/tmp/l5_hello
rm -f /tmp/l5_hello
