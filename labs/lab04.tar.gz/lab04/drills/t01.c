/* T01 — one type conversion, to keep it warm.
   Both sum and count are int. The variable it lands in is a float.
   Does that rescue the division? */
#include <stdio.h>
int main(void) {
    int sum = 7, count = 2;
    float avg = sum / count;
    printf("avg=%.2f\n", avg);
    return 0;
}
