/* P03 — the off-by-one, at the boundary.
   i and n are both 7. This is the difference between a loop that runs
   n times and one that runs n+1 times. */
#include <stdio.h>
int main(void) {
    int i = 7, n = 7;
    printf("%d %d\n", i < n, i <= n);
    return 0;
}
