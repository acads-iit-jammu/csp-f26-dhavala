# L1 - the preprocessor is a very literal clerk.
# drills/hello.c is 5 lines long and says:   #define GREETING "Hello, world!"
# Stage 1 runs alone with -E. Predict the LAST line of what comes out.
# (Is the word GREETING still in it?)
gcc -E drills/hello.c | tail -1
