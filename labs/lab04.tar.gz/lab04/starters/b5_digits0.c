/* B5 (fill the blanks) - digits again, but now n may be ZERO.
   GIVEN   : one integer n, 0..1000000        <-- note the 0
   ENSURES : final line ends with:  digits=<D>
   EXAMPLE : input "0"  ->  "digits=1"        (zero is one digit long)
   CHECK   : ./check.sh b5
   Take your B3 answer and feed it 0. It says 0 digits - wrong, because a
   while loop checks BEFORE it runs, so the body never runs at all.
   do-while checks AFTER, so the body always runs at least once. That is
   the entire reason the language has three loops instead of one.         */
#include <stdio.h>

int main(void) {
    int n, digits = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n with scanf */

    do {
        TODO_body;               /* TODO 2: same body as B3 */
    } while (TODO_condition);    /* TODO 3 */

    printf("digits=%d\n", digits);                   /* given - do not change */
    return 0;
}
