/* B3 (fill the blanks) - how many digits does n have?
   GIVEN   : one integer n, 1..1000000
   ENSURES : final line ends with:  digits=<D>
   EXAMPLE : input "1204"  ->  "digits=4"
   CHECK   : ./check.sh b3
   No string tricks - arithmetic only. Dividing an int by 10 throws away
   the last digit (Lab 03, drill 01). How many times can you do that?    */
#include <stdio.h>

int main(void) {
    int n, digits = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n with scanf */

    while (TODO_condition) {     /* TODO 2 */
        TODO_body;               /* TODO 3: count one digit, then shorten n */
    }

    printf("digits=%d\n", digits);                   /* given - do not change */
    return 0;
}
