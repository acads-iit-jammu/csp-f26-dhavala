/* E3 - the greatest common divisor of two numbers.                [checked]
   GIVEN   : two integers a and b on one line, each 1..1000
   ENSURES : final line ends with:  gcd=<G>
   EXAMPLE : input "48 18"  ->  "gcd=6"
             input "17 5"   ->  "gcd=1"
   CHECK   : ./check.sh e3
   Euclid, 300 BC, and still the fastest thing you will write today.
   The whole algorithm rests on one fact worth checking by hand:
       gcd(a, b)  is the same number as  gcd(b, a % b)
   Try it with 48 and 18. The pair keeps changing; the answer never does.
   That is a LOOP INVARIANT - the thing your loop is careful not to break -
   and it is the reason you may stop the moment b reaches 0.             */
#include <stdio.h>

int main(void) {
    int a, b;

    printf("Enter a and b: ");
    TODO_read_a_and_b;           /* TODO 1: read both */

    TODO_the_loop;               /* TODO 2: replace the pair until b is 0 */

    printf("gcd=%d\n", a);                           /* given - do not change */
    return 0;
}
