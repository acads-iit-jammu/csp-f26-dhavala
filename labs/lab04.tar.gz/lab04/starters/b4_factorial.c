/* B4 (fill the blanks) - n factorial.
   GIVEN   : one integer n, 1..12   (12! is the largest that fits an int)
   ENSURES : final line ends with:  fact=<F>
   EXAMPLE : input "5"  ->  "fact=120"
   CHECK   : ./check.sh b4
   Why does the GIVEN stop at 12? Work out 13! and compare it with the
   edge of int's world (Deck 07). The spec is protecting you from Week 3. */
#include <stdio.h>

int main(void) {
    int n, i, fact;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n with scanf */

    fact = TODO_start_value;     /* TODO 2: what must it start at, and why not 0? */

    for (i = 2; i <= n; i++) {
        TODO_body;               /* TODO 3 */
    }

    printf("fact=%d\n", fact);                       /* given - do not change */
    return 0;
}
