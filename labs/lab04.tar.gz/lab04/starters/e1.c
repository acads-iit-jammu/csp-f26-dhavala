/* E1 - the even numbers up to n: their sum, and how many there are. [checked]
   GIVEN   : one integer n, 1..1000
   ENSURES : final line ends with:  sum=<S> count=<C>
   EXAMPLE : input "10"  ->  "sum=30 count=5"      (2+4+6+8+10)
             input "1"   ->  "sum=0 count=0"       (there are none)
   CHECK   : ./check.sh e1
   One loop, two things counted at once. Two ways in: walk every number
   and test it, or step two at a time and never test anything. Both are
   correct - pick one deliberately, and be able to say why.             */
#include <stdio.h>

int main(void) {
    int n, i, sum = 0, count = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n */

    TODO_the_loop;               /* TODO 2: the loop */

    printf("sum=%d count=%d\n", sum, count);         /* given - do not change */
    return 0;
}
