/* B2 (fill the blanks) - THE SAME SUM, written as a FOR loop.
   GIVEN   : one integer n, 1..100
   ENSURES : final line ends with:  sum=<S>
   EXAMPLE : input "5"  ->  "sum=15"
   CHECK   : ./check.sh b2
   Identical contract to B1 on purpose. A for loop is a while loop with
   its three parts collected in one place: start ; keep going while ; step.
   Copy nothing - convert it, and notice where each of B1's lines went.  */
#include <stdio.h>

int main(void) {
    int n, i, sum = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n with scanf */

    for (TODO_start ; TODO_condition ; TODO_step) {   /* TODO 2,3,4 */
        TODO_body;               /* TODO 5: what is left to do? */
    }

    printf("sum=%d\n", sum);                         /* given - do not change */
    return 0;
}
