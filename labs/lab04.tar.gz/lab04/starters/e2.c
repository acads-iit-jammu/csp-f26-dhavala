/* E2 - reverse the digits of a number.                            [checked]
   GIVEN   : one integer n, 1..1000000
   ENSURES : final line ends with:  rev=<R>
   EXAMPLE : input "1204"  ->  "rev=4021"
             input "900"   ->  "rev=9"
   CHECK   : ./check.sh e2
   Read that second example again - it is not a bug. Reversed, 900 is
   009, and a number has no leading zeros, so it is 9. The checker will
   draw numbers ending in zero; make sure you agree with it first.
   Two moves, both from Lab 03: %10 takes the last digit off, /10 throws
   it away. The question is where each digit goes when you catch it.     */
#include <stdio.h>

int main(void) {
    int n, rev = 0;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n */

    TODO_the_loop;               /* TODO 2: the loop */

    printf("rev=%d\n", rev);                         /* given - do not change */
    return 0;
}
