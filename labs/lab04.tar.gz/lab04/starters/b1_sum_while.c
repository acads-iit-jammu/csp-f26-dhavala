/* B1 (fill the blanks) - add up 1 + 2 + ... + n, with a WHILE loop.
   GIVEN   : one integer n, 1..100
   ENSURES : final line ends with:  sum=<S>
   EXAMPLE : input "5"  ->  "sum=15"
   CHECK   : ./check.sh b1
   New this week: you write the scanf yourself. The declarations and the
   final printf are still given. Three blanks: read n, then the two lines
   that make the loop move. Ask of the loop: what must be true each time
   round? (sum holds 1+...+(i-1), and i is the next number to add.)      */
#include <stdio.h>

int main(void) {
    int n, i, sum;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n with scanf (mind the &) */

    sum = 0;
    i   = 1;
    while (TODO_condition) {     /* TODO 2: while what? */
        TODO_body;               /* TODO 3: add i to sum, then move i on */
    }

    printf("sum=%d\n", sum);                         /* given - do not change */
    return 0;
}
