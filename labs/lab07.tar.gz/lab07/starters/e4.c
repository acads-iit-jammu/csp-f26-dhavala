/* E4 - one generation of the Game of Life.                      [checked]
   GIVEN   : 64 integers, each 0 or 1, read row by row into an 8 x 8 world
   ENSURES : the WHOLE output is checked. Print the NEXT generation as 8 rows
             of 8 characters: '#' for a live cell, '.' for a dead one.
             Nothing else - do not print the starting world.
   THE RULE: a live cell with 2 or 3 live neighbours stays alive, otherwise it
             dies. A dead cell with exactly 3 live neighbours comes alive.
             Everything else stays dead.
   EXAMPLE : three live cells in a row across the middle become three live
             cells in a column - the blinker. Try it:   ./e4 < blinker.txt
   CHECK   : ./check.sh e4
   Tuesday's lecture used "##" and "  " to make the world visible on screen.
   Here it is '#' and '.', because a checker cannot see blank space.
   You will want countNeighbours from E3 - copy it in. That is the point of
   functions: write it once, use it again.
   The trap: every cell in a generation must see the SAME old world. Decide
   the whole next generation into a second grid before copying it back.      */
#include <stdio.h>
#define ROWS 8
#define COLS 8

int main(void) {
    TODO_write_this_program;
}
