/* B1 (fill the blanks) - your first function.
   GIVEN   : one integer n, 1..50
   ENSURES : final line ends with:  total=<S>     S = 1 + 2 + ... + n
   EXAMPLE : input "5" -> "total=15"
   CHECK   : ./check.sh b1
   You have written this loop before. The only new thing is WHERE it lives:
   inside a function that is handed an n and must hand back a number.
   A function with a return type of int must RETURN an int on every path.   */
#include <stdio.h>

int sumTo(int n)                     /* the promise - do not change this line */
{
    TODO_body;                       /* TODO 1: add up 1..n and return the total */
}

int main(void) {
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("total=%d\n", sumTo(n));           /* given - do not change */
    return 0;
}
