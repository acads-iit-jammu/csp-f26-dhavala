/* B4 (fill the blanks) - handing a grid to a function.
   GIVEN   : 16 integers, each 0..99, read row by row into a 4 x 4 grid,
             then one integer r, 0..3
   ENSURES : final line ends with:  sum=<S>     S = the total of row r
   EXAMPLE : input "1 2 3 4  5 6 7 8  9 10 11 12  13 14 15 16   2"
             -> "sum=42"                        (9 + 10 + 11 + 12)
   CHECK   : ./check.sh b4
   Note the parameter: int m[][COLS]. The row count may be left out; the
   COLUMN count may not, because reaching m[r][j] means computing r*COLS + j.
   Rows are numbered from 0, so row 2 is the THIRD one.                      */
#include <stdio.h>
#define ROWS 4
#define COLS 4

int rowSum(int m[][COLS], int r)     /* the promise - do not change this line */
{
    TODO_body;                       /* TODO 1: total row r and return it */
}

int main(void) {
    int m[ROWS][COLS], i, j, r;
    printf("Enter 16 integers (each 0..99), row by row into a 4 x 4 grid:\n");
    for (i = 0; i < ROWS; i++)
        for (j = 0; j < COLS; j++) scanf("%d", &m[i][j]);
    printf("Now the row number r (0..3): ");
    scanf("%d", &r);
    printf("sum=%d\n", rowSum(m, r));         /* given - no & on the grid */
    return 0;
}
