/* E1 - solve an equation you cannot rearrange.                  [checked]
   GIVEN   : one integer a, 1..50
   ENSURES : final line ends with:  root=<R>      R printed with %.4f
             R is the value x >= 0 for which   x*x*x + x  equals  a.
   EXAMPLE : input "2"  -> "root=1.0000"       (1 + 1 = 2)
             input "10" -> "root=2.0000"       (8 + 2 = 10)
             input "5"  -> "root=1.5160"
   CHECK   : ./check.sh e1
   There is no formula to rearrange here. Halve instead, exactly as Monday did:
   the answer is somewhere in [0, a] - at x = 0 the left side is too small, at
   x = a it is too big - so look at the midpoint and throw away the half that
   cannot contain the crossing. Keep halving until the bracket is narrower
   than 1e-12.
   Write TWO functions: one for the left-hand side, one that does the halving
   and calls it. Deciding which half to keep is the whole problem: ask which
   half the SIGN CHANGE is in, not whether the guess is too big.
   You are NOT allowed math.h.                                               */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
