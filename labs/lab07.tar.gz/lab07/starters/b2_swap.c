/* B2 (fill the blanks) - the swap that actually swaps.
   GIVEN   : two integers a and b, each -99..99
   ENSURES : final line ends with:  a=<B> b=<A>      (they come back exchanged)
   EXAMPLE : input "3 8"  -> "a=8 b=3"
             input "-5 0" -> "a=0 b=-5"
   CHECK   : ./check.sh b2
   Drill d05 showed you the version that does nothing. This one is handed
   WHERE the two values live, not copies of them. Inside the function, *a is
   the caller's a. You will need one extra variable to hold a value while you
   move the other - the two-glasses problem.                                 */
#include <stdio.h>

void swap(int *a, int *b)            /* the promise - do not change this line */
{
    TODO_body;                       /* TODO 1: exchange the two values */
}

int main(void) {
    int a, b;
    printf("Enter two integers a and b (each -99..99), separated by a space: ");
    scanf("%d %d", &a, &b);
    swap(&a, &b);                             /* given - note the two & signs */
    printf("a=%d b=%d\n", a, b);              /* given - do not change */
    return 0;
}
