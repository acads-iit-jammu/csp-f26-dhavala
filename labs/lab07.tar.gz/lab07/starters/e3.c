/* E3 - one cell's neighbours.                                   [checked]
   GIVEN   : 64 integers, each 0 or 1, read row by row into an 8 x 8 world,
             then two integers r and c, each 0..7
   ENSURES : final line ends with:  neighbours=<N>
             N is how many of the EIGHT cells touching (r, c) are alive.
             The cell itself is never counted.
   EXAMPLE : a world whose only live cells are (0,1), (1,0) and (1,1),
             asked about (0,0)  ->  "neighbours=3"
   CHECK   : ./check.sh e3
   Write it as       int countNeighbours(int world[8][8], int r, int c)
   and call it once from main.
   Two things can go wrong and only one of them is obvious. Skipping the cell
   itself is the obvious one. The other is the edge: a corner cell HAS only
   three neighbours, and reaching for the other five means reading outside
   the array. C will not stop you, and it will often appear to work.         */
#include <stdio.h>
#define ROWS 8
#define COLS 8

int main(void) {
    TODO_write_this_program;
}
