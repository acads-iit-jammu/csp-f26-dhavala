/* E5 - how many are left?                                       [checked]
   GIVEN   : 64 integers, each 0 or 1, read row by row into an 8 x 8 world,
             then one integer g, 0..12
   ENSURES : final line ends with:  alive=<N>
             N is how many cells are alive after g generations have passed.
             g = 0 means no generation passes: count the world as given.
   EXAMPLE : the blinker, g = 1 -> "alive=3"    (it flips, it does not grow)
             the glider,  g = 4 -> "alive=5"    (it has moved, not changed)
   CHECK   : ./check.sh e5
   If E4 works, almost all of this is already written: the only new thing is
   doing it g times and then counting. If you find yourself copying the whole
   rule into a new loop, stop - put the generation in a function and call it
   g times instead.
   Watch g = 0. A loop written "do it, then check" runs once even when it was
   asked for none.                                                           */
#include <stdio.h>
#define ROWS 8
#define COLS 8

int main(void) {
    TODO_write_this_program;
}
