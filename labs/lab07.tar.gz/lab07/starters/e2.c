/* E2 - flipping a grid about its diagonal.                      [checked]
   GIVEN   : 16 integers, each 0..99, read row by row into a 4 x 4 grid
   ENSURES : the WHOLE output is checked, not just the last line.
             Print 4 rows of 4 numbers - the grid with rows and columns
             exchanged, so what was m[i][j] is now printed at row j, column i.
   EXAMPLE : input  1 2 3 4        output  1 5 9 13
                    5 6 7 8                2 6 10 14
                    9 10 11 12             3 7 11 15
                    13 14 15 16            4 8 12 16
   PRINT   : the four rows and NOTHING else. Do not print a prompt. The whole
             output is compared, so a prompt on its own line becomes a wrong
             first row and costs every mark.
   CHECK   : ./check.sh e2
   Spacing is NOT graded - one space or four, the checker does not care. What
   is graded is the right numbers in the right order on the right rows.
   Build the answer in a SECOND grid and print that. Writing the flip back
   into the original as you go will overwrite values you have not read yet -
   the same trap that Tuesday's world has, met here on something small.      */
#include <stdio.h>
#define N 4

int main(void) {
    TODO_write_this_program;
}
