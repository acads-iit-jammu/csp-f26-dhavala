/* B5 (fill the blanks) - cos x, from its series.
   GIVEN   : a real x, 0.0 <= x <= 2.5, then an integer n, 3..12
   ENSURES : final line ends with:  cos=<V>      V printed with %.6f
             V is the sum of the FIRST n terms of
                 cos x = 1 - x^2/2! + x^4/4! - x^6/6! + ...
   EXAMPLE : input "0.0 10" -> "cos=1.000000"
             input "1.0 10" -> "cos=0.540302"
   CHECK   : ./check.sh b5
   DO NOT compute each factorial with its own loop. 13! already overflows an
   int, and the answer goes quietly wrong. Each term is the one before it
   times a small correction:
                 term = term * (-x*x) / ((2k+1) * (2k+2))
   starting from term = 1.0 at k = 0. No factorial is ever formed.
   You are NOT allowed math.h here - the point is that you can build cos
   yourself out of a loop.                                                   */
#include <stdio.h>

double cosSeries(double x, int n)    /* the promise - do not change this line */
{
    TODO_body;                       /* TODO 1: sum n terms, each from the one before */
}

int main(void) {
    double x;
    int n;
    printf("Enter x n: ");
    scanf("%lf %d", &x, &n);
    printf("cos=%.6f\n", cosSeries(x, n));    /* given - do not change */
    return 0;
}
