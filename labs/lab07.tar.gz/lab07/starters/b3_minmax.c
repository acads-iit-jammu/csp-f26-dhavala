/* B3 (fill the blanks) - two answers out of one walk.
   GIVEN   : an integer n, 1..20, then n integers, each -99..99
   ENSURES : final line ends with:  lo=<L> hi=<H>
             L is the smallest of the n values, H is the largest.
   EXAMPLE : input "5  4 -1 9 9 2" -> "lo=-1 hi=9"
             input "1  7"          -> "lo=7 hi=7"
   CHECK   : ./check.sh b3
   A function returns ONE value. Here you owe the caller two, so neither of
   them comes back through return - both are written through pointers the
   caller handed you. Start both at a[0]: starting the largest at 0 is wrong
   the moment every value is negative.                                       */
#include <stdio.h>

void minMax(int a[], int n, int *lo, int *hi)   /* the promise - do not change */
{
    TODO_body;                       /* TODO 1: walk a[0..n-1], writing through lo and hi */
}

int main(void) {
    int a[20], n, i, lo, hi;
    printf("How many values? n (1..20): ");
    scanf("%d", &n);
    printf("Now enter those %d integers (each -99..99), separated by spaces: ", n);
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    minMax(a, n, &lo, &hi);                   /* given - no & on the array */
    printf("lo=%d hi=%d\n", lo, hi);          /* given - do not change */
    return 0;
}
