#!/usr/bin/env bash
# ./drill.sh          list the drills and your progress
# ./drill.sh d03      do one drill      (also: ./drill.sh 3)
# ./drill.sh --all    work through every drill you have not done yet
#
# Each drill: you SEE it, you WRITE your prediction, and only THEN does it run.
# Predicting is the exercise. Running is just the marking.
#
# All ten are C programs this week: predict what they PRINT.
#   d01-d04   what a function does, and does not, change
#   d05-d06   swap, and why an array is different
#   d07-d08   grids, and a counter that lives in the caller
#   d09-d10   a corner cell's neighbours, and return inside a loop
set -u

if [ ! -f TEAM.txt ]; then
  echo "STOP: this is not your workspace (no TEAM.txt here)."
  echo "Run:  ./where.sh    — it will tell you exactly what to type."
  exit 2
fi

LOG=notes/drills.log
mkdir -p notes; [ -f "$LOG" ] || : > "$LOG"
ALL="d01 d02 d03 d04 d05 d06 d07 d08 d09 d10"
GCCFLAGS="-std=c11 -Wno-error=parentheses"

status_of(){ grep -h "^[^ ]* $1 " "$LOG" 2>/dev/null | tail -1 | awk '{print $3}'; }

label_of(){
  case "$1" in
    d01) echo "(a function hands back a value)";;
    d02) echo "(call by value - the function gets a copy)";;
    d03) echo "(call by reference - the address, through a pointer)";;
    d04) echo "(scope)";;
    d05) echo "(a swap that has no effect)";;
    d06) echo "(an array argument is converted to a pointer)";;
    d07) echo "(reading a value from a grid)";;
    d08) echo "(a counter the caller owns)";;
    d09) echo "(a corner cell's neighbours)";;
    *)   echo "(return from inside a loop)";;
  esac
}

# Some drills here loop forever on purpose. Cap every run so a drill cannot
# hang the machine: timeout(1) on Linux, else gtimeout, else a perl alarm.
if   command -v timeout  >/dev/null 2>&1; then CAP="timeout 5 "
elif command -v gtimeout >/dev/null 2>&1; then CAP="gtimeout 5 "
elif command -v perl     >/dev/null 2>&1; then
  CAP="perl -e 'my \$p=fork; unless(\$p){exec @ARGV; exit 127} \$SIG{ALRM}=sub{kill \"KILL\",\$p; waitpid(\$p,0); exit 124}; alarm(5); waitpid(\$p,0); exit(\$? >> 8)' "
else CAP=""
fi

list(){
  echo "=================================================================="
  echo "  Lab 07 drills — predict first, then run."
  echo
  local done=0 hit=0 s mark
  for d in $ALL; do
    s="$(status_of "$d")"
    case "$s" in
      HIT)  mark="[HIT ]"; done=$((done+1)); hit=$((hit+1));;
      MISS) mark="[miss]"; done=$((done+1));;
      *)    mark="[    ]";;
    esac
    printf "  %s %-4s %s\n" "$mark" "$d" "$(label_of "$d")"
  done
  echo
  echo "  done: $done/10   predicted correctly: $hit"
  echo "  next:  ./drill.sh --all"
  echo "=================================================================="
}

one(){
  local d="$1" csrc="drills/$1.c" ssrc="drills/$1.sh" kind out rc pred verdict
  if   [ -f "$csrc" ]; then kind=c
  elif [ -f "$ssrc" ]; then kind=sh
  else echo "drill.sh: no such drill '$d' (try ./drill.sh)"; return 2; fi

  echo
  echo "=============== DRILL $d $(label_of "$d") ========================="
  [ "$kind" = c ] && cat "$csrc" || cat "$ssrc"
  echo "-------------------------------------------------------------------"
  if [ "$kind" = c ]; then
    printf 'YOUR PREDICTION (what will it print?): '
  else
    printf 'YOUR PREDICTION (what will these commands do?): '
  fi
  IFS= read -r pred || return 1
  [ -n "$pred" ] || pred="(no prediction)"

  echo
  echo "--- what actually happens ---"
  if [ "$kind" = c ]; then
    if out="$(gcc $GCCFLAGS "$csrc" -o ".drill_$d" 2>&1)"; then
      out="$( ( eval "$CAP./.drill_$d" ) 2>&1; printf 'X')"; out="${out%X}"
      rc=0
      case "$out" in *"$(printf '\n')") ;; esac
      printf '%s' "$out"
      case "$out" in *$'\n') ;; *) printf '   <-- (no newline at the end!)\n';; esac
    else
      rc=1
      echo "COMPILE ERROR — the compiler said:"
      printf '%s\n' "$out" | head -4 | sed 's/^/    /'
    fi
    rm -f ".drill_$d"
  else
    out="$(bash "$ssrc" 2>&1)"; rc=0
    printf '%s\n' "$out" | sed 's/^/    /'
  fi
  echo "-----------------------------"

  # C drills auto-mark (whitespace-insensitive). Pipeline drills are self-marked:
  # their exact text depends on the machine, and the LESSON is not the text.
  local squash_p squash_a
  squash_p="$(printf '%s' "$pred" | tr -d '[:space:]')"
  squash_a="$(printf '%s' "$out"  | tr -d '[:space:]')"
  if [ "$kind" = c ] && [ "$rc" = 0 ] && [ -n "$squash_p" ] && [ "$squash_p" = "$squash_a" ]; then
    verdict=HIT
    echo "  ** correct — you predicted it exactly. **"
  else
    echo "  you said : $pred"
    if [ "$kind" = c ] && [ "$rc" != 0 ]; then
      echo "  it said  : (it did not compile)"
    else
      echo "  it said  : $(printf '%s' "$out" | tr '\n' '~' | sed 's/~$//; s/~/ [newline] /g')"
    fi
    printf '  Were you right (wording aside)? [y/N] '
    IFS= read -r yn || yn=n
    case "$yn" in y|Y) verdict=HIT;; *) verdict=MISS;; esac
  fi

  printf '%s %s %s pred="%s"\n' "$(date +%FT%T)" "$d" "$verdict" "$pred" >> "$LOG"
  [ "$verdict" = MISS ] && echo "  logged as a miss — that is the useful kind. Ask why before moving on."
  return 0
}

case "${1:-}" in
  "")     list;;
  --all)  for d in $ALL; do [ -n "$(status_of "$d")" ] || one "$d" || break; done; echo; list;;
  --help|-h) sed -n '2,13p' "$0";;
  *)      arg="$1"
          case "$arg" in
            [0-9])   arg="d0$arg";;
            10)      arg="d10";;
          esac
          one "$arg";;
esac
