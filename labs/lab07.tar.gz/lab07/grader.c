/* Lab 07 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e5          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 8      /* headroom: a problem may need extra public vectors to pin its own trap */
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}


/* ---- full-output comparison (for problems that print a grid) ------------
   Compares the WHOLE output, line by line, after normalising whitespace:
   runs of blanks collapse to one, ends are trimmed, blank lines are dropped.
   So printf alignment is the student's business, not the grader's - what is
   checked is the right values in the right order on the right rows.
   Prompts are allowed: a leading prompt on the first line is tolerated by
   letting the expected text match at the END of that line.               */
#define BLANKCH(ch) ((ch)==' ' || (ch)=='\t' || (ch)=='\n' || (ch)=='\r')
static void squeeze(const char *in, char *out, int n) {
    int i = 0, sp = 0; const char *p = in;
    while (BLANKCH(*p)) p++;
    for (; *p && i < n-1; p++) {
        if (BLANKCH(*p)) { sp = 1; continue; }
        if (sp && i > 0) out[i++] = ' ';
        sp = 0;
        if (i < n-1) out[i++] = *p;
    }
    out[i] = 0;
}

static int cmp_full(const char *path, const char *expected, char *why, int wn) {
    char eb[4096]; strncpy(eb, expected, sizeof eb - 1); eb[sizeof eb - 1] = 0;
    FILE *f = fopen(path, "r");
    if (!f) { snprintf(why, wn, "produced no output at all"); return 1; }

    char gl[1024], gs[1024], es[1024];
    char *esave = eb, *eline;
    int row = 0;
    for (;;) {
        /* next non-blank expected line */
        do { eline = strsep(&esave, "\n"); } while (eline && *eline == 0);
        /* next non-blank produced line */
        int have = 0;
        while (fgets(gl, sizeof gl, f)) { squeeze(gl, gs, sizeof gs); if (gs[0]) { have = 1; break; } }
        if (!eline && !have) { fclose(f); return 0; }                 /* both ended together */
        if (!eline) { snprintf(why, wn, "extra output after line %d: \"%s\"", row, gs); fclose(f); return 1; }
        if (!have)  { snprintf(why, wn, "output stopped early - line %d is missing (expected \"%s\")", row+1, eline); fclose(f); return 1; }
        row++;
        squeeze(eline, es, sizeof es);
        size_t glen = strlen(gs), elen = strlen(es);
        int ok = (glen >= elen) && strcmp(gs + glen - elen, es) == 0;   /* allow a prompt in front */
        if (!ok) { snprintf(why, wn, "line %d differs\n             you printed : \"%s\"\n             expected     : \"%s\"", row, gs, es);
                   fclose(f); return 1; }
    }
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label, int full) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    if (full) {
        char why[1024] = "";
        if (cmp_full(".gout", expected, why, sizeof why) == 0) {
            printf("  PASS     [%s] input: %s\n", label, input);
            return 0;
        }
        printf("  WRONG    [%s] input: %s\n           %s\n", label, input, why);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) ---
   What this file cannot give you is tomorrow's random numbers.          */
#define ROWS 8
#define COLS 8

/* ---- Life, once, so several generators can share it ---- */
static int nbrs(int w[ROWS][COLS], int i, int j) {
    int c = 0;
    for (int di = -1; di <= 1; di++)
        for (int dj = -1; dj <= 1; dj++) {
            if (di == 0 && dj == 0) continue;
            int ni = i + di, nj = j + dj;
            if (ni >= 0 && ni < ROWS && nj >= 0 && nj < COLS) c += w[ni][nj];
        }
    return c;
}
static void step(int w[ROWS][COLS]) {
    int nx[ROWS][COLS];
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++) {
            int n = nbrs(w, i, j);
            if (w[i][j] == 1) nx[i][j] = (n == 2 || n == 3);
            else              nx[i][j] = (n == 3);
        }
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++) w[i][j] = nx[i][j];
}
static void rand_world(int w[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++) w[i][j] = (rand() % 100) < 38;
}
static void world_in(int w[ROWS][COLS], char *in) {
    int k = 0;
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++) k += sprintf(in + k, "%d ", w[i][j]);
    in[k ? k - 1 : 0] = 0;
}
static void world_out(int w[ROWS][COLS], char *exp) {
    int k = 0;
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) exp[k++] = w[i][j] ? '#' : '.';
        if (i < ROWS - 1) exp[k++] = '\n';
    }
    exp[k] = 0;
}

static void gen_b1(char *in, char *exp) {                 /* sum 1..n, inside a function */
    int n = rand()%50 + 1;
    sprintf(in, "%d", n);
    sprintf(exp, "total=%d", n*(n+1)/2);
}
static void gen_b2(char *in, char *exp) {                 /* swap through pointers */
    int a = rand()%199 - 99, b = rand()%199 - 99;
    sprintf(in, "%d %d", a, b);
    sprintf(exp, "a=%d b=%d", b, a);
}
static void gen_b3(char *in, char *exp) {                 /* two answers through pointers */
    int n = rand()%20 + 1, i, lo, hi, v[20], k = 0;
    /* a third of the draws are all-negative, so "start the max at 0" fails */
    int allneg = (rand()%3 == 0);
    for (i = 0; i < n; i++) v[i] = allneg ? -(rand()%99 + 1) : rand()%199 - 99;
    lo = hi = v[0];
    for (i = 1; i < n; i++) { if (v[i] < lo) lo = v[i]; if (v[i] > hi) hi = v[i]; }
    k = sprintf(in, "%d", n);
    for (i = 0; i < n; i++) k += sprintf(in + k, " %d", v[i]);
    sprintf(exp, "lo=%d hi=%d", lo, hi);
}
static void gen_b4(char *in, char *exp) {                 /* a grid parameter */
    int m[4][4], i, j, r = rand()%4, s = 0, k = 0;
    for (i = 0; i < 4; i++) for (j = 0; j < 4; j++) m[i][j] = rand()%100;
    for (j = 0; j < 4; j++) s += m[r][j];
    for (i = 0; i < 4; i++) for (j = 0; j < 4; j++) k += sprintf(in + k, "%d ", m[i][j]);
    sprintf(in + k, "%d", r);
    sprintf(exp, "sum=%d", s);
}
static double cos_series(double x, int n) {
    double term = 1.0, sum = 0.0;
    for (int k = 0; k < n; k++) { sum += term; term = term * (-x*x) / ((2*k+1)*(2*k+2)); }
    return sum;
}
static void gen_b5(char *in, char *exp) {                 /* cos by its series */
    int k, n; double x, v, scaled, d;
    /* Reject a draw whose 6th decimal sits ON a rounding boundary: there the
       printed digit depends on the order the terms were added, and a correct
       program that sums differently would be marked wrong. ~0.4% of draws. */
    do {
        k = rand()%2501; n = rand()%10 + 3;
        x = k / 1000.0;
        v = cos_series(x, n);
        scaled = (v < 0 ? -v : v) * 1e6;
        d = scaled - (double)(long)(scaled + 0.5);
        if (d < 0) d = -d;
    } while (d > 0.5 - 1e-3);
    sprintf(in, "%d.%03d %d", k/1000, k%1000, n);
    sprintf(exp, "cos=%.6f", v);
}
static double f_e1(double x, double a) { return x*x*x + x - a; }
static void gen_e1(char *in, char *exp) {                 /* a root, by halving */
    int a = rand()%50 + 1;
    double lo = 0.0, hi = (double)a;
    while (hi - lo > 1e-12) {
        double mid = (lo + hi) / 2.0;
        if (f_e1(lo,a) * f_e1(mid,a) <= 0.0) hi = mid; else lo = mid;
    }
    sprintf(in, "%d", a);
    sprintf(exp, "root=%.4f", (lo + hi) / 2.0);
}
static void gen_e2(char *in, char *exp) {                 /* transpose, whole output */
    int m[4][4], i, j, k = 0;
    for (i = 0; i < 4; i++) for (j = 0; j < 4; j++) m[i][j] = rand()%100;
    for (i = 0; i < 4; i++) for (j = 0; j < 4; j++) k += sprintf(in + k, "%d ", m[i][j]);
    in[k-1] = 0;
    k = 0;
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) k += sprintf(exp + k, "%d ", m[j][i]);
        exp[k-1] = (i < 3) ? '\n' : 0;
    }
}
static void gen_e3(char *in, char *exp) {                 /* one cell's neighbours */
    int w[ROWS][COLS], r, c, k;
    rand_world(w);
    /* half the draws sit on an edge or corner, where the bounds test is the
       difference between a right answer and reading outside the array */
    if (rand()%2) { r = (rand()%2) ? 0 : ROWS-1; c = rand()%COLS; }
    else          { r = rand()%ROWS;             c = rand()%COLS; }
    world_in(w, in);
    k = (int)strlen(in);
    sprintf(in + k, " %d %d", r, c);
    sprintf(exp, "neighbours=%d", nbrs(w, r, c));
}
static void gen_e4(char *in, char *exp) {                 /* one generation, whole grid */
    int w[ROWS][COLS];
    rand_world(w);
    world_in(w, in);
    step(w);
    world_out(w, exp);
}
static void gen_e5(char *in, char *exp) {                 /* population after g generations */
    int w[ROWS][COLS], g, i, j, alive, tries = 0;
    do {
        rand_world(w);
        g = rand()%13;
        world_in(w, in);
        int t[ROWS][COLS];
        for (i = 0; i < ROWS; i++) for (j = 0; j < COLS; j++) t[i][j] = w[i][j];
        for (i = 0; i < g; i++) step(t);
        alive = 0;
        for (i = 0; i < ROWS; i++) for (j = 0; j < COLS; j++) alive += t[i][j];
    } while (alive == 0 && ++tries < 50);   /* "alive=0" must not be a free pass */
    sprintf(in + strlen(in), " %d", g);
    sprintf(exp, "alive=%d", alive);
}

struct problem {
    const char *name;
    const char *src;
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
    int full;                   /* 1 = compare the whole output, not just the last line */
};
static struct problem P[] = {
 {"b1", "b1_sumto.c", 4, 2,
   {"5", "1", "10", "50"},
   {"total=15", "total=1", "total=55", "total=1275"},
   gen_b1, 0},
 {"b2", "b2_swap.c", 4, 2,
   {"3 8", "-5 0", "7 7", "0 -99"},
   {"a=8 b=3", "a=0 b=-5", "a=7 b=7", "a=-99 b=0"},
   gen_b2, 0},
 {"b3", "b3_minmax.c", 4, 3,
   {"5 4 -1 9 9 2", "1 7", "4 -9 -3 -50 -1", "3 0 0 0"},
   {"lo=-1 hi=9", "lo=7 hi=7", "lo=-50 hi=-1", "lo=0 hi=0"},
   gen_b3, 0},
 {"b4", "b4_rowsum.c", 3, 3,
   {"1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 0", "1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 2", "1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 3"},
   {"sum=10", "sum=42", "sum=58"},
   gen_b4, 0},
 {"b5", "b5_cos.c", 7, 3,
   {"0.000 10", "1.000 3", "1.000 4", "2.500 3", "2.500 12", "0.700 5", "2.000 9"},
   {"cos=1.000000", "cos=0.541667", "cos=0.540278", "cos=-0.497396", "cos=-0.801144", "cos=0.764842", "cos=-0.416147"},
   gen_b5, 0},
 {"e1", "e1.c", 6, 3,
   {"2", "10", "5", "1", "26", "50"},
   {"root=1.0000", "root=2.0000", "root=1.5160", "root=0.6823", "root=2.8500", "root=3.5936"},
   gen_e1, 0},
 {"e2", "e2.c", 2, 3,
   {"1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16", "7 7 7 7 0 1 2 3 9 9 9 9 4 5 6 7"},
   {"1 5 9 13\n2 6 10 14\n3 7 11 15\n4 8 12 16", "7 0 9 4\n7 1 9 5\n7 2 9 6\n7 3 9 7"},
   gen_e2, 1},
 {"e3", "e3.c", 6, 3,
   {"0 1 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3 3", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 2", "1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3 3"},
   {"neighbours=3", "neighbours=8", "neighbours=1", "neighbours=3", "neighbours=1", "neighbours=2"},
   gen_e3, 0},
 {"e4", "e4.c", 4, 3,
   {"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0"},
   {"........\n........\n...#....\n...#....\n...#....\n........\n........\n........", "........\n#.#.....\n.##.....\n.#......\n........\n........\n........\n........", "........\n........\n........\n...##...\n...##...\n........\n........\n........", "........\n........\n........\n........\n........\n........\n........\n........"},
   gen_e4, 1},
 {"e5", "e5.c", 6, 3,
   {"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 5", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1", "0 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4", "0 1 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3"},
   {"alive=9", "alive=8", "alive=12", "alive=3", "alive=5", "alive=4"},
   gen_e5, 0},
};

int main(int argc, char **argv) {
    /* ./grader --count e1   prints how many vectors e1 has, and exits.
       check-ta.sh uses this so partial credit never has to guess a total. */
    if (argc == 3 && strcmp(argv[1], "--count") == 0) {
        for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
            if (strcmp(P[i].name, argv[2]) == 0) { printf("%d\n", P[i].npub + P[i].nrand); return 0; }
        return 2;
    }
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e5   |   ./grader --count PROB\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public", p->full);
    for (int i = 0; i < p->nrand; i++) {
        char in[512], exp[4096];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random", p->full);
    }
    return failed;
}
