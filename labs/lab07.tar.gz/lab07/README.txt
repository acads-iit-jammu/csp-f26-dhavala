Lab 07 — Functions, and the Game of Life
========================================

Everything happens INSIDE your workspace. If your prompt does not say
[lab07 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            d01-d04  what a function does, and does not, change
                            d05-d06  swap, and why an array is different
                            d07-d08  grids, and a counter in the caller
                            d09-d10  a corner cell, and return inside a loop
  4.  fill the blanks:  b1_sumto.c   b2_swap.c   b3_minmax.c
                        b4_rowsum.c  b5_cos.c
  5.  the checked five: e1.c  e2.c  e3.c  e4.c  e5.c
  6.  ./check.sh            self-check, with your marks so far
  7.  ./check.sh --bundle   bundle it, carry it out

In the five blanks the function's first line is already written for you.
That line is the PROMISE: what goes in, what comes back. Your job is to keep
it. Do not change it — main is already calling it exactly as written.

The five checked programs give you the specification and nothing else. Two of
them (e4, e5) want a world of cells; two (e3, e4) want the same
countNeighbours function. Write it once and copy it over — that is what
functions are for.

Nobody should type 64 numbers. Ready-made inputs are already in your
workspace -- each one reproduces the EXAMPLE printed in that starter, so you
can check your program against the spec in one command:

    ./e2 < e2_sample.txt      the 4x4 grid from e2's EXAMPLE
    ./e3 < e3_sample.txt      world + the cell to ask about -> neighbours=3
    ./e4 < blinker.txt        three in a row become three in a column
    ./e4 < glider.txt         a shape that walks
    ./e5 < e5_sample.txt      the glider after 4 generations -> alive=5

e3 and e5 need one more number AFTER the 64, which is why they have their own
file: e3 wants the cell, e5 wants the generation count. e4 needs only the
world, so blinker.txt and glider.txt work for it directly.

Make your own: copy any of these, edit the 0s and 1s, and run it again.

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler has never heard of, so it tells you exactly which line is
still waiting for you.

Drills are NOT marked. They are how you find out what you have wrong before
it costs you anything.
