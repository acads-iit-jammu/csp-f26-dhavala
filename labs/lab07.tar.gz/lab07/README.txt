Lab 07 — Functions, and the Game of Life
========================================

Everything happens INSIDE your workspace. If your prompt does not say
[lab07 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            d01-d04  what a function does, and does not, change
                            d05-d06  swap, and why an array is different
                            d07-d08  grids, and a counter in the caller
                            d09-d10  a corner cell, and return inside a loop
  4.  fill the blanks:  b1_sumto.c   b2_swap.c   b3_minmax.c
                        b4_rowsum.c  b5_cos.c
  5.  the checked five: e1.c  e2.c  e3.c  e4.c  e5.c
  6.  ./check.sh            self-check, with your marks so far
  7.  ./check.sh --bundle   bundle it, carry it out

In the five blanks the function's first line is already written for you.
That line is the PROMISE: what goes in, what comes back. Your job is to keep
it. Do not change it — main is already calling it exactly as written.

The five checked programs give you the specification and nothing else. Two of
them (e4, e5) want a world of cells; two (e3, e4) want the same
countNeighbours function. Write it once and copy it over — that is what
functions are for.

Nobody should type sixteen or sixty-four numbers. EVERY problem has a ready-made
input file next to it, named the same way:

        <problem>_sample.txt

so the command is always the same shape:

    ./b1 < b1_sample.txt          ./e1 < e1_sample.txt
    ./b2 < b2_sample.txt          ./e2 < e2_sample.txt
    ./b3 < b3_sample.txt          ./e3 < e3_sample.txt
    ./b4 < b4_sample.txt          ./e4 < e4_sample.txt
    ./b5 < b5_sample.txt          ./e5 < e5_sample.txt

Each file reproduces the EXAMPLE printed at the top of that starter, so if your
program is right you will see exactly the answer the spec promised.

One extra world is provided, glider.txt, a shape that walks:

    ./e4 < glider.txt
    ( cat glider.txt ; echo 6 ) | ./e5

Make your own: copy any sample file, edit it, run it again.

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler has never heard of, so it tells you exactly which line is
still waiting for you.

Drills are NOT marked. They are how you find out what you have wrong before
it costs you anything.
