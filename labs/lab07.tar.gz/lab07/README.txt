Lab 07 — Functions, and the Game of Life
========================================

Everything happens INSIDE your workspace. If your prompt does not say
[lab07 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            d01-d04  what a function does, and does not, change
                            d05-d06  swap, and why an array is different
                            d07-d08  grids, and a counter in the caller
                            d09-d10  a corner cell, and return inside a loop
  4.  fill the blanks:  b1_sumto.c   b2_swap.c   b3_minmax.c
                        b4_rowsum.c  b5_cos.c
  5.  the checked five: e1.c  e2.c  e3.c  e4.c  e5.c
  6.  ./check.sh            self-check, with your marks so far
  7.  ./check.sh --bundle   bundle it, carry it out

In the five blanks the function's first line is already written for you.
That line is the PROMISE: what goes in, what comes back. Your job is to keep
it. Do not change it — main is already calling it exactly as written.

The five checked programs give you the specification and nothing else. Two of
them (e4, e5) want a world of cells; two (e3, e4) want the same
countNeighbours function. Write it once and copy it over — that is what
functions are for.

Two sample worlds are in your workspace so you can watch it run:

    ./e4 < blinker.txt        three in a row become three in a column
    ./e4 < glider.txt         a shape that walks

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler has never heard of, so it tells you exactly which line is
still waiting for you.

Drills are NOT marked. They are how you find out what you have wrong before
it costs you anything.
