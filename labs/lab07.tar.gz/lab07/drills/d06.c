/* D06 - no & anywhere in the call. Does a[0] change? */
#include <stdio.h>
void wipe(int a[]) { a[0] = 99; }
int main(void) {
    int a[3] = { 1, 2, 3 };
    wipe(a);
    printf("a[0] = %d\n", a[0]);
    return 0;
}
