/* D10 - return does not just end the loop. */
#include <stdio.h>
int firstOver(int a[], int n, int limit) {
    for (int i = 0; i < n; i++) {
        if (a[i] > limit) return a[i];
    }
    return -1;
}
int main(void) {
    int a[5] = { 3, 9, 40, 8, 90 };
    printf("found = %d\n", firstOver(a, 5, 5));
    return 0;
}
