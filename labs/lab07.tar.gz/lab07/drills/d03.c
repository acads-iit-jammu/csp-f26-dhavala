/* D03 - one character different from D02. Same answer? */
#include <stdio.h>
void reallyAddOne(int *n) { *n = *n + 1; }
int main(void) {
    int x = 5;
    reallyAddOne(&x);
    printf("x = %d\n", x);
    return 0;
}
