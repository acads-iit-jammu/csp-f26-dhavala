/* D08 - the counter lives in main. How many times was it bumped? */
#include <stdio.h>
void tally(int *count) { *count = *count + 1; }
int main(void) {
    int calls = 0;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 3; j++)
            tally(&calls);
    printf("calls = %d\n", calls);
    return 0;
}
