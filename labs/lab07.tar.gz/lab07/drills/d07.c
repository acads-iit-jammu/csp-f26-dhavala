/* D07 - reading a grid. Row first, or column first? */
#include <stdio.h>
int main(void) {
    int m[2][3] = { {1, 2, 3}, {4, 5, 6} };
    printf("m[1][0] = %d\n", m[1][0]);
    return 0;
}
