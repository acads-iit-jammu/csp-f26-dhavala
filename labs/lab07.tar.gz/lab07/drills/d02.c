/* D02 - the function changes n. Does x change? */
#include <stdio.h>
void addOne(int n) { n = n + 1; }
int main(void) {
    int x = 5;
    addOne(x);
    printf("x = %d\n", x);
    return 0;
}
