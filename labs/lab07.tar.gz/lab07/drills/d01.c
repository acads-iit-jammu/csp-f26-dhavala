/* D01 - a function hands back a value. What does main print? */
#include <stdio.h>
int twice(int n) { return 2 * n; }
int main(void) {
    printf("%d\n", twice(5) + 1);
    return 0;
}
