/* D04 - two variables, both called n. Which one does main print? */
#include <stdio.h>
int shrink(int n) { n = n - 100; return n; }
int main(void) {
    int n = 7;
    shrink(n);
    printf("n = %d\n", n);
    return 0;
}
