/* D09 - a corner cell. How many neighbours does it HAVE? */
#include <stdio.h>
#define ROWS 8
#define COLS 8
int countNeighbours(int world[ROWS][COLS], int i, int j) {
    int count = 0;
    for (int di = -1; di <= 1; di++)
        for (int dj = -1; dj <= 1; dj++) {
            if (di == 0 && dj == 0) continue;
            int ni = i + di, nj = j + dj;
            if (ni >= 0 && ni < ROWS && nj >= 0 && nj < COLS)
                count += world[ni][nj];
        }
    return count;
}
int main(void) {
    int world[ROWS][COLS] = {0};
    world[0][1] = 1; world[1][0] = 1; world[1][1] = 1;
    printf("corner = %d\n", countNeighbours(world, 0, 0));
    return 0;
}
