/* Lab 09 grader engine (structures, and files).
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader w01..w10 | b1..b5 | e1..e4   exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>

#define MAXPUB 8      /* headroom: a problem may need extra public vectors to pin its own trap */
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[4096];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' ||
                         line[L-1]==' '  || line[L-1]=='\t')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}


/* ---- full-output comparison (for problems that print a grid) ------------
   Compares the WHOLE output, line by line, after normalising whitespace:
   runs of blanks collapse to one, ends are trimmed, blank lines are dropped.
   So printf alignment is the student's business, not the grader's - what is
   checked is the right values in the right order on the right rows.
   Prompts are allowed: a leading prompt on the first line is tolerated by
   letting the expected text match at the END of that line.               */
#define BLANKCH(ch) ((ch)==' ' || (ch)=='\t' || (ch)=='\n' || (ch)=='\r')
static void squeeze(const char *in, char *out, int n) {
    int i = 0, sp = 0; const char *p = in;
    while (BLANKCH(*p)) p++;
    for (; *p && i < n-1; p++) {
        if (BLANKCH(*p)) { sp = 1; continue; }
        if (sp && i > 0) out[i++] = ' ';
        sp = 0;
        if (i < n-1) out[i++] = *p;
    }
    out[i] = 0;
}

/* strsep() is hidden by glibc under -std=c11 (it needs _DEFAULT_SOURCE), and
   since GCC 14 an implicit declaration is a hard error. check-ta.sh compiles
   this file with -std=c11, so the grader would fail to build on the Ubuntu
   lab image and silently score every bundle zero. Written out instead.      */
static char *next_line(char **sp) {
    char *s = *sp, *e;
    if (!s) return NULL;
    e = strchr(s, '\n');
    if (e) { *e = 0; *sp = e + 1; }
    else   { *sp = NULL; }
    return s;
}

static int cmp_full(const char *path, const char *expected, char *why, int wn, int exact) {
    char eb[4096]; strncpy(eb, expected, sizeof eb - 1); eb[sizeof eb - 1] = 0;
    FILE *f = fopen(path, "r");
    if (!f) { snprintf(why, wn, "produced no output at all"); return 1; }

    char gl[1024], gs[1024], es[1024];
    char *esave = eb, *eline;
    int row = 0;
    for (;;) {
        /* next non-blank expected line */
        do { eline = next_line(&esave); } while (eline && *eline == 0);
        /* next non-blank produced line */
        int have = 0;
        while (fgets(gl, sizeof gl, f)) { squeeze(gl, gs, sizeof gs); if (gs[0]) { have = 1; break; } }
        if (!eline && !have) { fclose(f); return 0; }                 /* both ended together */
        if (!eline) { snprintf(why, wn, "extra output after line %d: \"%s\"", row, gs); fclose(f); return 1; }
        if (!have)  { snprintf(why, wn, "output stopped early - line %d is missing (expected \"%s\")", row+1, eline); fclose(f); return 1; }
        row++;
        squeeze(eline, es, sizeof es);
        size_t glen = strlen(gs), elen = strlen(es);
        /* stdout may carry an unterminated prompt in front of the answer, so there
           we match at the END of the line. A FILE the program was told to write has
           no prompts in it: "nothing else" is part of the specification, so compare
           the whole line. Without this, writing "Ravi 1001" passes for "1001".     */
        int ok = exact ? (strcmp(gs, es) == 0)
                       : ((glen >= elen) && strcmp(gs + glen - elen, es) == 0);
        if (!ok) { snprintf(why, wn, "line %d differs\n             you printed : \"%s\"\n             expected     : \"%s\"", row, gs, es);
                   fclose(f); return 1; }
    }
}

/* Vectors for the file problems are whole files. Printing one verbatim on a
   PASS line would bury the result, so show the first line and a count.      */
static const char *shortin(const char *in) {
    static char buf[160];
    const char *nl = strchr(in, '\n');
    if (!nl) return in;
    int lines = 1; const char *p;
    for (p = in; *p; p++) if (*p == '\n') lines++;
    int n = (int)(nl - in); if (n > 60) n = 60;
    snprintf(buf, sizeof buf, "%.*s ... (%d lines)", n, in, lines);
    return buf;
}

static int run_one(const char *prog, const char *input, const char *expected,
                   const char *label, int full,
                   const char *datafile, const char *outfile, const char *expfile) {
    /* Where does the input go? Most problems read stdin. The file problems get a
       real data file instead, and are given an EMPTY stdin — a program that still
       calls scanf() will block, and the 5s cap turns that into a clear TIMEOUT. */
    if (datafile) {
        FILE *d = fopen(datafile, "w");
        if (!d) { printf("  grader: cannot write %s\n", datafile); return 1; }
        fputs(input, d); fputc('\n', d); fclose(d);
        FILE *g = fopen(".gin", "w"); if (g) fclose(g);          /* empty stdin */
    } else {
        FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
        fputs(input, f); fputc('\n', f); fclose(f);
    }
    /* A file left behind by the previous vector must never be mistaken for this
       one's work. Remove it, so "did not write it at all" is a visible failure. */
    if (outfile) remove(outfile);

    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, shortin(input));
        return 1;
    }

    int bad = 0;
    if (full) {
        char why[1024] = "";
        if (cmp_full(".gout", expected, why, sizeof why, 0) != 0) {
            printf("  WRONG    [%s] input: %s\n           %s\n", label, shortin(input), why);
            bad = 1;
        }
    } else {
            char got[4096]; last_line(".gout", got, sizeof got);
        size_t gl = strlen(got), el = strlen(expected);
        /* Contract: the final line must END WITH the expected text, so that an
           unterminated prompt may legally share the line. The match must begin
           at a boundary, though - otherwise "91001 Ravi 8.25" would pass for
           "1001 Ravi 8.25", which is a different roll number. A real prompt
           ends in punctuation or a space, never mid-token.                    */
        int suffix_ok = 0;
        if (gl >= el && strcmp(got + gl - el, expected) == 0) {
            if (gl == el) suffix_ok = 1;
            else {
                char before = got[gl - el - 1];
                /* Only a digit or a letter can glue a prompt to the answer and
                   change its meaning. Punctuation cannot: a prompt of dots or
                   arrows before "x=3 y=4" leaves the answer itself intact.   */
                suffix_ok = !((before >= '0' && before <= '9') ||
                              (before >= 'a' && before <= 'z') ||
                              (before >= 'A' && before <= 'Z'));
            }
        }
        if (!suffix_ok) {
            printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
                   label, shortin(input), got, expected);
            bad = 1;
        }
    }

    /* The written file is graded too, and separately: a correct count printed on
       screen earns nothing if passed.txt was never written. */
    if (outfile) {
        FILE *chk = fopen(outfile, "r");
        if (!chk) {
            printf("  WRONG    [%s] you did not create %s at all\n", label, outfile);
            bad = 1;
        } else {
            fclose(chk);
            char why[1024] = "";
            if (cmp_full(outfile, expfile, why, sizeof why, 1) != 0) {
                printf("  WRONG    [%s] the contents of %s are wrong\n           %s\n", label, outfile, why);
                bad = 1;
            }
        }
    }

    if (!bad) printf("  PASS     [%s] input: %s\n", label, shortin(input));
    return bad;
}

/* ---------------- reference answers (the specs state these anyway) ----
   What this file cannot give you is tomorrow's random data.            */

static const char *PROG[3] = { "EE", "ME", "MM" };
static const char *NAMES[12] = { "Ravi","Asha","Iqbal","Meera","Vikram","Nita",
                                 "Arjun","Sana","Devi","Rahul","Kiran","Tara" };

static int rnd(int lo, int hi) { return lo + rand() % (hi - lo + 1); }

/* one random cgpa in [4.00, 9.99], two decimals, as a double that prints exactly */
static double rand_cgpa(void) { return rnd(400, 999) / 100.0; }

/* Build a random roster. Fills rows[] with "roll name prog cgpa" lines and
   returns the count; the caller gets the parsed columns back as well.      */
static int make_roster(char *out, int n, int *roll, char nm[][16], int *pg, double *cg) {
    int i, len = 0;
    int base = rnd(1001, 1900);
    for (i = 0; i < n; i++) {
        roll[i] = base + i;
        snprintf(nm[i], 16, "%s", NAMES[rand() % 12]);
        pg[i] = rand() % 3;
        /* every so often, repeat an earlier cgpa exactly: the tie rules in
           e2/e3/b5 are part of the specification and must be exercised. */
        cg[i] = (i > 0 && rand() % 4 == 0) ? cg[rand() % i] : rand_cgpa();
        len += sprintf(out + len, "%s%d %s %s %.2f",
                       i ? "\n" : "", roll[i], nm[i], PROG[pg[i]], cg[i]);
    }
    return n;
}

/* ---- the ten write drills ---- */
static void gen_w01(char *in, char *exp, char *ef){ (void)ef;
    int x = rnd(-99,99), y = rnd(-99,99); sprintf(in,"%d %d",x,y); sprintf(exp,"x=%d y=%d",x,y); }
static void gen_w02(char *in, char *exp, char *ef){ (void)ef;
    int r = rnd(1001,1999); double c = rand_cgpa(); sprintf(in,"%d %.2f",r,c); sprintf(exp,"roll=%d cgpa=%.2f",r,c); }
static void gen_w03(char *in, char *exp, char *ef){ (void)ef;
    int x = rnd(-99,99), y = rnd(-99,99); sprintf(in,"%d %d",x,y); sprintf(exp,"a=%d",x); }
static void gen_w04(char *in, char *exp, char *ef){ (void)ef;
    int x = rnd(-99,99); sprintf(in,"%d",x); sprintf(exp,"x=%d",x); }
static void gen_w05(char *in, char *exp, char *ef){ (void)ef;
    int x = rnd(-99,99); sprintf(in,"%d",x); sprintf(exp,"x=%d",x+1); }
static void gen_w06(char *in, char *exp, char *ef){ (void)ef;
    int a[3][2], k, i; for (i=0;i<3;i++){a[i][0]=rnd(-50,50);a[i][1]=rnd(-50,50);} k=rnd(0,2);
    sprintf(in,"%d %d %d %d %d %d %d",a[0][0],a[0][1],a[1][0],a[1][1],a[2][0],a[2][1],k);
    sprintf(exp,"x=%d y=%d",a[k][0],a[k][1]); }
static void gen_w07(char *in, char *exp, char *ef){ (void)ef;
    int x = rnd(-99,99), y = rnd(-99,99); sprintf(in,"%d %d",x,y); sprintf(exp,"sum=%d",x+y); }
static void gen_w08(char *in, char *exp, char *ef){ (void)ef;
    int lx=rnd(-9,0), ly=rnd(-9,0), hx=rnd(1,9), hy=rnd(1,9);
    sprintf(in,"%d %d %d %d",lx,ly,hx,hy); sprintf(exp,"hx=%d hy=%d",hx,hy); }
static void gen_w09(char *in, char *exp, char *ef){ (void)ef;
    double c[3]; int i, bi=0; for(i=0;i<3;i++) c[i]=rand_cgpa();
    for(i=1;i<3;i++) if (c[i] > c[bi]) bi=i;
    sprintf(in,"%.2f %.2f %.2f",c[0],c[1],c[2]); sprintf(exp,"best=%.2f",c[bi]); }
static void gen_w10(char *in, char *exp, char *ef){ (void)ef;
    const char *n = NAMES[rand()%12]; const char *p = PROG[rand()%3];
    sprintf(in,"%s %s",n,p); sprintf(exp,"name=%s program=%s",n,p); }

/* ---- the five blanks ---- */
static void gen_b1(char *in, char *exp, char *ef){ (void)ef;
    int r=rnd(1001,1999); const char *n=NAMES[rand()%12]; double c=rand_cgpa();
    sprintf(in,"%d %s %.2f",r,n,c); sprintf(exp,"%d %s %.2f",r,n,c); }
static void gen_b2(char *in, char *exp, char *ef){ (void)ef;
    int r=rnd(1001,1999); double c=rand_cgpa(); sprintf(in,"%d %.2f",r,c);
    sprintf(exp,"roll=%d cgpa=%.2f",r,c); }
static void gen_b3(char *in, char *exp, char *ef){ (void)ef;
    int n, i, len; double c[8], fwd, rev;
    char a[32], b[32];
    /* The spec does not say in which order to add the marks, so both ends of
       the array are legitimate. Redraw whenever the two orders round to
       different 2-decimal strings, rather than fail a correct student whose
       loop happened to run the other way. */
    for (;;) {
        n = rnd(3,6);
        fwd = 0; rev = 0;
        for (i=0;i<n;i++) c[i] = rand_cgpa();
        for (i=0;i<n;i++)   fwd += c[i];
        for (i=n-1;i>=0;i--) rev += c[i];
        snprintf(a, sizeof a, "%.2f", fwd/n);
        snprintf(b, sizeof b, "%.2f", rev/n);
        if (strcmp(a,b) == 0) break;
    }
    len = sprintf(in,"%d",n);
    for(i=0;i<n;i++) len += sprintf(in+len," %.2f",c[i]);
    sprintf(exp,"average=%s", a); }
static void gen_b4(char *in, char *exp, char *ef){ (void)ef;
    int n=rnd(3,7), i, len=0, k=0; double c;
    len += sprintf(in,"%d",n);
    for(i=0;i<n;i++){ c=rand_cgpa(); if (c > 7.0) k++; len += sprintf(in+len," %.2f",c); }
    sprintf(exp,"above=%d",k); }
static void gen_b5(char *in, char *exp, char *ef){ (void)ef;
    int n=rnd(3,6), i, len=0, bi=0; int rl[8]; double c[8];
    len += sprintf(in,"%d",n);
    for(i=0;i<n;i++){ rl[i]=rnd(1001,1999); c[i]=rand_cgpa(); len += sprintf(in+len," %d %.2f",rl[i],c[i]); }
    for(i=1;i<n;i++) if (c[i] > c[bi]) bi=i;
    sprintf(exp,"topper=%d",rl[bi]); }

/* ---- the four checked problems ---- */
/* e1: is the point inside the rectangle? (edges count as inside) */
static void gen_e1(char *in, char *exp, char *ef){ (void)ef;
    int lx=rnd(-9,0), ly=rnd(-9,0), hx=rnd(1,9), hy=rnd(1,9);
    int px, py;
    if (rand()%2) { px = rnd(lx,hx);     py = rnd(ly,hy); }      /* often inside, often on an edge */
    else          { px = rnd(lx-3,hx+3); py = rnd(ly-3,hy+3); }
    sprintf(in,"%d %d %d %d %d %d",lx,ly,hx,hy,px,py);
    sprintf(exp,"%s", (px>=lx && px<=hx && py>=ly && py<=hy) ? "inside" : "outside"); }

/* e2: the topper's roll and name, from n records on stdin */
static void gen_e2(char *in, char *exp, char *ef){ (void)ef;
    int n=rnd(3,8), i, len=0, bi=0;
    int rl[10]; char nm[10][16]; int pg[10]; double cg[10];
    char rows[1024];
    make_roster(rows, n, rl, nm, pg, cg);
    len = sprintf(in,"%d\n",n);
    sprintf(in+len,"%s",rows);
    for(i=1;i<n;i++) if (cg[i] > cg[bi]) bi=i;
    sprintf(exp,"topper=%d %s",rl[bi],nm[bi]); }

/* e3: which programme has the most students above 7.0?
       ties go to whichever of them appears first in the file */
static void gen_e3(char *in, char *exp, char *ef){ (void)ef;
    int n=rnd(5,12), i;
    int rl[16]; char nm[16][16]; int pg[16]; double cg[16];
    int cnt[3] = {0,0,0}, firstAt[3] = {-1,-1,-1}, best = 0;
    make_roster(in, n, rl, nm, pg, cg);
    for (i=0;i<n;i++) {
        if (firstAt[pg[i]] < 0) firstAt[pg[i]] = i;
        if (cg[i] > 7.0) cnt[pg[i]]++;
    }
    /* -1 means "never appeared" and must not be read as a row number */
    for (i=1;i<3;i++) {
        if (cnt[i] > cnt[best]) best = i;
        else if (cnt[i] == cnt[best] &&
                 firstAt[i] >= 0 && (firstAt[best] < 0 || firstAt[i] < firstAt[best])) best = i;
    }
    sprintf(exp,"program=%s count=%d", PROG[best], cnt[best]); }

/* e4: write the rolls above 7.0 to passed.txt, in file order, and report how many */
static void gen_e4(char *in, char *exp, char *ef){
    int n=rnd(5,12), i, k=0, fl=0;
    int rl[16]; char nm[16][16]; int pg[16]; double cg[16];
    make_roster(in, n, rl, nm, pg, cg);
    ef[0] = 0;
    for (i=0;i<n;i++)
        if (cg[i] > 7.0) { fl += sprintf(ef+fl, "%d\n", rl[i]); k++; }
    sprintf(exp,"passed=%d",k); }

struct problem {
    const char *name;
    const char *src;
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*, char*);
    int full;                   /* 1 = compare the whole output, not just the last line */
    const char *datafile;       /* non-NULL: the input is a FILE of this name, not stdin */
    const char *outfile;        /* non-NULL: the program must also WRITE this file       */
    const char *pub_file[MAXPUB];   /* expected contents of outfile, per public vector   */
};
static struct problem P[] = {
 {"w01", "w01.c", 3, 2, {"3 4", "-2 7", "0 0"},
   {"x=3 y=4", "x=-2 y=7", "x=0 y=0"}, gen_w01, 0, NULL, NULL, {0}},
 {"w02", "w02.c", 3, 2, {"1001 8.25", "1500 6.00", "1999 9.99"},
   {"roll=1001 cgpa=8.25", "roll=1500 cgpa=6.00", "roll=1999 cgpa=9.99"}, gen_w02, 0, NULL, NULL, {0}},
 {"w03", "w03.c", 3, 2, {"3 4", "-7 2", "0 5"},
   {"a=3", "a=-7", "a=0"}, gen_w03, 0, NULL, NULL, {0}},
 {"w04", "w04.c", 3, 2, {"5", "-12", "0"},
   {"x=5", "x=-12", "x=0"}, gen_w04, 0, NULL, NULL, {0}},
 {"w05", "w05.c", 3, 2, {"5", "-12", "0"},
   {"x=6", "x=-11", "x=1"}, gen_w05, 0, NULL, NULL, {0}},
 {"w06", "w06.c", 3, 2, {"1 2 3 4 5 6 1", "1 2 3 4 5 6 0", "1 2 3 4 5 6 2"},
   {"x=3 y=4", "x=1 y=2", "x=5 y=6"}, gen_w06, 0, NULL, NULL, {0}},
 {"w07", "w07.c", 3, 2, {"3 4", "-5 5", "0 0"},
   {"sum=7", "sum=0", "sum=0"}, gen_w07, 0, NULL, NULL, {0}},
 {"w08", "w08.c", 3, 2, {"0 0 4 3", "-2 -2 1 1", "-9 -9 9 9"},
   {"hx=4 hy=3", "hx=1 hy=1", "hx=9 hy=9"}, gen_w08, 0, NULL, NULL, {0}},
 {"w09", "w09.c", 3, 2, {"7.50 8.25 6.00", "9.99 4.00 5.00", "6.00 6.00 6.00"},
   {"best=8.25", "best=9.99", "best=6.00"}, gen_w09, 0, NULL, NULL, {0}},
 {"w10", "w10.c", 3, 2, {"Ravi EE", "Asha ME", "Meera MM"},
   {"name=Ravi program=EE", "name=Asha program=ME", "name=Meera program=MM"}, gen_w10, 0, NULL, NULL, {0}},

 {"b1", "b1_make.c", 3, 3, {"1001 Ravi 8.25", "1500 Asha 6.00", "1999 Tara 9.99"},
   {"1001 Ravi 8.25", "1500 Asha 6.00", "1999 Tara 9.99"}, gen_b1, 0, NULL, NULL, {0}},
 {"b2", "b2_arrow.c", 3, 3, {"1001 8.25", "1500 6.00", "1999 9.99"},
   {"roll=1001 cgpa=8.25", "roll=1500 cgpa=6.00", "roll=1999 cgpa=9.99"}, gen_b2, 0, NULL, NULL, {0}},
 {"b3", "b3_average.c", 3, 3, {"3 6.00 7.00 8.00", "1 9.99", "4 5.00 5.00 5.00 5.00"},
   {"average=7.00", "average=9.99", "average=5.00"}, gen_b3, 0, NULL, NULL, {0}},
 {"b4", "b4_above.c", 4, 3, {"3 6.00 7.00 8.00", "1 9.99", "3 7.00 7.00 7.00", "4 7.01 8.00 6.99 7.50"},
   {"above=1", "above=1", "above=0", "above=3"}, gen_b4, 0, NULL, NULL, {0}},
 {"b5", "b5_topper.c", 3, 3, {"3 1001 6.00 1002 8.50 1003 7.00", "1 1500 5.00", "2 1001 9.00 1002 9.00"},
   {"topper=1002", "topper=1500", "topper=1001"}, gen_b5, 0, NULL, NULL, {0}},

 {"e1", "e1.c", 6, 4,
   {"0 0 4 3 2 1", "0 0 4 3 5 1", "0 0 4 3 0 0", "0 0 4 3 4 3", "0 0 4 3 2 4", "-2 -2 2 2 -2 2"},
   {"inside", "outside", "inside", "inside", "outside", "inside"}, gen_e1, 0, NULL, NULL, {0}},
 {"e2", "e2.c", 4, 4,
   {"3\n1001 Ravi EE 8.20\n1002 Asha ME 6.50\n1003 Iqbal EE 7.10",
    "1\n1500 Tara MM 5.00",
    "4\n1001 Ravi EE 7.00\n1002 Asha ME 9.50\n1003 Iqbal EE 7.10\n1004 Devi MM 6.00",
    "3\n1001 Ravi EE 9.00\n1002 Asha ME 9.00\n1003 Iqbal MM 8.00"},
   {"topper=1001 Ravi", "topper=1500 Tara", "topper=1002 Asha", "topper=1001 Ravi"},
   gen_e2, 0, NULL, NULL, {0}},
 {"e3", "e3.c", 4, 4,
   {"1001 Ravi EE 8.20\n1002 Asha ME 6.50\n1003 Iqbal EE 7.10\n1004 Meera MM 9.00\n1005 Vikram ME 7.80\n1006 Nita EE 6.90", "1001 Ravi ME 8.00\n1002 Asha EE 8.50", "1001 Ravi EE 6.00\n1002 Asha ME 5.50", "1007 Tara MM 7.01\n1008 Kiran MM 7.00\n1009 Devi EE 9.99"},
   {"program=EE count=2", "program=ME count=1", "program=EE count=0", "program=MM count=1"},
   gen_e3, 0, "students.txt", NULL, {0}},
 {"e4", "e4.c", 4, 4,
   {"1001 Ravi EE 8.20\n1002 Asha ME 6.50\n1003 Iqbal EE 7.10\n1004 Meera MM 9.00\n1005 Vikram ME 7.80\n1006 Nita EE 6.90", "1001 Ravi ME 8.00\n1002 Asha EE 8.50", "1001 Ravi EE 6.00\n1002 Asha ME 5.50", "1007 Tara MM 7.01\n1008 Kiran MM 7.00\n1009 Devi EE 9.99"},
   {"passed=4", "passed=2", "passed=0", "passed=2"},
   gen_e4, 0, "students.txt", "passed.txt",
   {"1001\n1003\n1004\n1005\n", "1001\n1002\n", "", "1007\n1009\n"}},
};

int main(int argc, char **argv) {
    /* ./grader --count e1   prints how many vectors e1 has, and exits.
       check-ta.sh uses this so partial credit never has to guess a total. */
    if (argc == 3 && strcmp(argv[1], "--count") == 0) {
        for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
            if (strcmp(P[i].name, argv[2]) == 0) { printf("%d\n", P[i].npub + P[i].nrand); return 0; }
        return 2;
    }
    if (argc != 2) { printf("usage: ./grader w01..w10|b1..b5|e1..e4   |   ./grader --count PROB\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    /* Seeded without getpid(): glibc hides POSIX declarations under -std=c11
       (the same trap that hid strsep and would have scored every bundle zero),
       and nothing else here needs <unistd.h>. The address of a local varies
       per process under ASLR, which is all the per-run entropy we want. */
    srand((unsigned)time(NULL) ^ (unsigned)(uintptr_t)&argc);

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    /* The vectors overwrite the data file. Keep the copy the student was given,
       so that after ./check.sh the sample in the lab sheet still reproduces. */
    char saved[65536]; long savedlen = -1;
    if (p->datafile) {
        FILE *b = fopen(p->datafile, "rb");
        if (b) { savedlen = (long) fread(saved, 1, sizeof saved, b); fclose(b); }
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public", p->full,
                          p->datafile, p->outfile, p->outfile ? p->pub_file[i] : NULL);
    for (int i = 0; i < p->nrand; i++) {
        char in[2048], exp[4096], ef[4096];
        ef[0] = 0;
        p->gen(in, exp, ef);
        failed += run_one(p->name, in, exp, "random", p->full,
                          p->datafile, p->outfile, ef);
    }

    if (p->datafile && savedlen >= 0) {
        FILE *b = fopen(p->datafile, "wb");
        if (b) { fwrite(saved, 1, (size_t) savedlen, b); fclose(b); }
    }
    return failed;
}
