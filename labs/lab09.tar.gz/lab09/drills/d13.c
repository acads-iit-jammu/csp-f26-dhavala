/* D13 - the second line is missing its last field.
   What does fscanf return each time? */
#include <stdio.h>
int main(void) {
    FILE *f = fopen("d13_tmp.txt", "w");
    int roll = 0; char name[20] = ""; double m = 0.0;
    fprintf(f, "11 Asha 91.5\n12 Bilal\n");
    fclose(f);

    f = fopen("d13_tmp.txt", "r");
    printf("first  = %d\n", fscanf(f, "%d %19s %lf", &roll, name, &m));
    printf("second = %d\n", fscanf(f, "%d %19s %lf", &roll, name, &m));
    printf("third  = %d\n", fscanf(f, "%d %19s %lf", &roll, name, &m));
    fclose(f);
    remove("d13_tmp.txt");
    return 0;
}
