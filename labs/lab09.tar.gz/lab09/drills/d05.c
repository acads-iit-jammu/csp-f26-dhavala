/* D05 - the same function, given the ADDRESS instead. Now? */
#include <stdio.h>
struct Point { int x, y; };
void moveReal(struct Point *q) { q->x = 99; }
int main(void) {
    struct Point p = { 1, 2 };
    moveReal(&p);
    printf("%d\n", p.x);
    return 0;
}
