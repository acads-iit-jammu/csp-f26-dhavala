/* D14 - the same six values, laid out two different ways.
   Does the reading loop care? */
#include <stdio.h>
static int count(const char *path) {
    FILE *f = fopen(path, "r");
    int roll, n = 0; char name[20]; double m;
    while (fscanf(f, "%d %19s %lf", &roll, name, &m) == 3) n++;
    fclose(f);
    return n;
}
int main(void) {
    FILE *f;
    f = fopen("d14_a.txt", "w"); fprintf(f, "11 Asha 91.5\n12 Bilal 78.0\n");  fclose(f);
    f = fopen("d14_b.txt", "w"); fprintf(f, "11\nAsha\n91.5\n12\nBilal\n78.0\n"); fclose(f);
    printf("A = %d, B = %d\n", count("d14_a.txt"), count("d14_b.txt"));
    remove("d14_a.txt"); remove("d14_b.txt");
    return 0;
}
