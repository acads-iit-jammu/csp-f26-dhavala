/* D15 - two records in the file, and the loop tests feof.
   How many times does the body run? */
#include <stdio.h>
int main(void) {
    FILE *f = fopen("d15_tmp.txt", "w");
    int roll = 0, n = 0; char name[20] = "none"; double m = 0.0;
    fprintf(f, "11 Asha 91.5\n12 Bilal 78.0\n");
    fclose(f);

    f = fopen("d15_tmp.txt", "r");
    while (!feof(f)) {
        fscanf(f, "%d %19s %lf", &roll, name, &m);
        n++;
        printf("body %d: %d %s\n", n, roll, name);
    }
    fclose(f);
    remove("d15_tmp.txt");
    return 0;
}
