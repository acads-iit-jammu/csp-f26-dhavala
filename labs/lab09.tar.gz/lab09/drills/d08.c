/* D08 - a structure inside a structure. How many dots to reach the int? */
#include <stdio.h>
struct Point { int x, y; };
struct Rect  { struct Point lo, hi; };
int main(void) {
    struct Rect r = { {0, 0}, {4, 3} };
    printf("%d %d\n", r.lo.x, r.hi.y);
    return 0;
}
