/* D12 - three lines are written, then the SAME file is opened "w" again.
   How many lines does it hold at the end? */
#include <stdio.h>
int main(void) {
    FILE *f = fopen("d12_tmp.txt", "w");
    int c;
    fprintf(f, "one\ntwo\nthree\n");
    fclose(f);

    f = fopen("d12_tmp.txt", "w");          /* again, with "w" */
    fprintf(f, "four\n");
    fclose(f);

    f = fopen("d12_tmp.txt", "r");
    c = 0;
    { int ch; while ((ch = fgetc(f)) != EOF) if (ch == '\n') c++; }
    fclose(f);
    remove("d12_tmp.txt");
    printf("lines = %d\n", c);
    return 0;
}
