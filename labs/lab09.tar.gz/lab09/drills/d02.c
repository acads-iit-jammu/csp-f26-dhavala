/* D02 - the members need not be the same type. */
#include <stdio.h>
struct Student { int roll; double cgpa; };
int main(void) {
    struct Student s;
    s.roll = 1001;
    s.cgpa = 8.25;
    printf("%d %.2f\n", s.roll, s.cgpa);
    return 0;
}
