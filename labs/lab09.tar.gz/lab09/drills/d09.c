/* D09 - predict BOTH numbers before you run this one. */
#include <stdio.h>
struct Pad { char c; int n; };
int main(void) {
    printf("%zu %zu\n", sizeof(struct Pad), sizeof(char) + sizeof(int));
    return 0;
}
