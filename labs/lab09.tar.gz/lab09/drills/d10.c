/* D10 - programme codes are strings. What does strcmp give for EQUAL? */
#include <stdio.h>
#include <string.h>
int main(void) {
    char a[8] = "EE";
    char b[8] = "EE";
    if (strcmp(a, b))
        printf("branch A\n");
    else
        printf("branch B\n");
    return 0;
}
