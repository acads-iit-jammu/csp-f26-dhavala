/* D03 - b = a. Is b another name for a, or a second structure? */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point a = { 1, 2 };
    struct Point b = a;
    b.x = 99;
    printf("%d %d\n", a.x, b.x);
    return 0;
}
