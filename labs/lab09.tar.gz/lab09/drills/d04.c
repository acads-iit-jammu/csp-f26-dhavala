/* D04 - the function changes its parameter. Does main's p change? */
#include <stdio.h>
struct Point { int x, y; };
void moveCopy(struct Point q) { q.x = 99; }
int main(void) {
    struct Point p = { 1, 2 };
    moveCopy(p);
    printf("%d\n", p.x);
    return 0;
}
