/* D11 - the file is not there. Does fopen crash, or hand something back? */
#include <stdio.h>
int main(void) {
    FILE *f = fopen("no-such-file-here.txt", "r");
    if (f == NULL) printf("NULL\n");
    else           printf("opened\n");
    return 0;
}
