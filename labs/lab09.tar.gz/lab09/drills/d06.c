/* D06 - an array of structures: which part is the index, which the member? */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point a[3] = { {1,2}, {3,4}, {5,6} };
    printf("%d %d\n", a[1].x, a[2].y);
    return 0;
}
