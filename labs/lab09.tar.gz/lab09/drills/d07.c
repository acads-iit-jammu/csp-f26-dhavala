/* D07 - two spellings of the same thing. Do they agree? */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point p = { 7, 8 };
    struct Point *q = &p;
    printf("%d %d\n", q->x, (*q).x);
    return 0;
}
