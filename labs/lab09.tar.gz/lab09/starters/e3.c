/* E3 - which programme has the most students above 7?           [checked]
   READS   : the file students.txt in the current directory. Each line is
                 <roll> <name> <programme> <cgpa>
             and the file ends when it ends - you are NOT told how many
             lines there are. Programmes are EE, ME and MM.
   ENSURES : final line ends with:  program=<code> count=<how many>
             counting students STRICTLY above 7.00 in each programme, and
             reporting the programme with the most of them.
             Ties, including the all-zero case, go to whichever of the
             tied programmes appears FIRST in the file.
   EXAMPLE : for the students.txt that ships with this lab,
                 "program=EE count=2"
   BEFORE  : blank b4; Tuesday's lecture on reading files
   CHECK   : ./check.sh e3
   Open with fopen(..., "r") and CHECK IT AGAINST NULL before using it.
   Read to the end with
        while (fscanf(f, "%d %19s %7s %lf", ...) == 4) { ... }
   which stops as soon as a line does not deliver all four. Compare
   programme codes with strcmp, never with ==.
   You do not need to store the records at all: three counters will do.   */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
