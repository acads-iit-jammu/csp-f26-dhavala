/* E3 - which programme has the most students above 7?           [checked]
   READS   : the file students.txt in the current directory. Each line is
                 <roll> <name> <programme> <cgpa>
             and the file ends when it ends - you are NOT told how many
             lines there are. Every line is a complete, valid record; name is
             one word of at most 19 characters; programme is one of EE, ME,
             MM; cgpa is 4.00..9.99. The file always has at least one line.
             NOTE: one word is a SIMPLIFICATION for this lab, not how names
             really are. "Ravi Kumar" would make %19s stop at the space and
             your read return fewer fields than you asked for, ending the
             loop early and skipping the rest of the file - silently. See
             the Week 11 appendix for how real names are handled.
   ENSURES : final line ends with:  program=<code> count=<how many>
             counting students STRICTLY above 7.00 in each programme, and
             reporting the programme with the most of them.
             Ties, including the all-zero case, go to whichever of the
             tied programmes appears FIRST in the file.
   EXAMPLE : for the students.txt that ships with this lab,
                 "program=EE count=2"
   BEFORE  : blank b4; Tuesday's lecture on reading files
   CHECK   : ./check.sh e3
   Open with fopen(..., "r") and CHECK IT AGAINST NULL before using it.
   Read to the end with
        while (fscanf(f, "%d %19s %7s %lf", ...) == 4) { ... }
   which stops as soon as a read does not deliver all four. Compare
   programme codes with strcmp, never with ==.
   You do not need to store the records at all. Three counters give you the
   three totals; the tie rule needs one more value per programme - the row at
   which it FIRST appeared, counting every student of that programme, not only
   those above 7.00. Six small variables, and no array of records.          */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
