/* W08 - a structure inside a structure.                          [1 mark]
   GIVEN   : four integers lx ly hx hy - the two corners of a rectangle
   ENSURES : final line ends with:  hx=<hx> hy=<hy>
   WRITE   : the scanf. Two steps to reach a member: r.hi is a Point,
             and r.hi.x is the int inside it.
   BEFORE  : drill d08
   CHECK   : ./check.sh w08                                               */
#include <stdio.h>
struct Point { int x, y; };
struct Rect  { struct Point lo, hi; };
int main(void) {
    struct Rect r;

    TODO_line;                       /* TODO: read lx ly hx hy into r */

    printf("hx=%d hy=%d\n", r.hi.x, r.hi.y);  /* given - do not change */
    return 0;
}
