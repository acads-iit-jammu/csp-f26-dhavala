/* B1 (fill the blanks) - one complete record.                    [5 marks]
   GIVEN   : a roll (1001..1999), a name (one word, <= 19 chars), a cgpa
   ENSURES : final line ends with:  <roll> <name> <cgpa to 2 decimals>
   EXAMPLE : input "1001 Ravi 8.25" -> "1001 Ravi 8.25"
   BEFORE  : write drills w02, w10
   CHECK   : ./check.sh b1
   Three members, three conversions, one scanf. Watch which ones need &:
   roll and cgpa do, name does not, because an array is already an address. */
#include <stdio.h>

struct Student { int roll; char name[20]; double cgpa; };

int main(void) {
    struct Student s;

    TODO_line;              /* TODO: one scanf that fills all three members */

    TODO_line2;             /* TODO: print them: <roll> <name> <cgpa to 2dp> */

    return 0;
}
