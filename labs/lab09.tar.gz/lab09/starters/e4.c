/* E4 - write the pass list out to a file.                       [checked]
   READS   : students.txt, exactly as in e3 - one record per line,
                 <roll> <name> <programme> <cgpa>
             name one word of at most 19 characters, programme EE/ME/MM,
             cgpa 4.00..9.99, at least one line, length not known in advance.
             NOTE: one word is a SIMPLIFICATION for this lab, not how names
             really are. "Ravi Kumar" would make %19s stop at the space and
             your read return fewer fields than you asked for, ending the
             loop early and skipping the rest of the file - silently. See
             the Week 11 appendix for how real names are handled.
   WRITES  : passed.txt - the roll numbers of the students STRICTLY above
             7.00, one per line, in the order they appear in students.txt,
             and nothing else.
   ENSURES : final line ends with:  passed=<how many you wrote>
   EXAMPLE : for the students.txt that ships with this lab, passed.txt is
                 1001
                 1003
                 1004
                 1005
             and the final line is "passed=4".
   BEFORE  : e3; Tuesday's lecture on writing files
   CHECK   : ./check.sh e4
   BOTH are graded: the file AND the line you print. A correct count on
   screen earns nothing if passed.txt was never written, and the checker
   deletes any old passed.txt before each run so a stale one cannot pass
   for this one.
   Open the output with fopen(..., "w") and fclose() it when you are done
   - data you wrote may still be sitting in a buffer until you do.
   If nobody qualifies, passed.txt must exist and be empty.               */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
