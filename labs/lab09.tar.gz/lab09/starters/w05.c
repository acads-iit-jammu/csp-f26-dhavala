/* W05 - a structure passed BY ADDRESS.                           [1 mark]
   GIVEN   : one integer x, -99..99
   ENSURES : final line ends with:  x=<x+1>        (changed!)
   WRITE   : the body of bump. Add one to the caller's x, through p.
   BEFORE  : drill d05, and w04 - the comparison is the lesson
   CHECK   : ./check.sh w05
   p is a POINTER to the structure, so reach a member with p->x.          */
#include <stdio.h>
struct Point { int x, y; };

void bump(struct Point *p)           /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: add one to the caller's x */
}

int main(void) {
    struct Point s;
    if (scanf("%d", &s.x) != 1) return 1;     /* given */
    s.y = 0;
    bump(&s);                                 /* given - note the & */
    printf("x=%d\n", s.x);                    /* given - do not change */
    return 0;
}
