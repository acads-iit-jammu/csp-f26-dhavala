/* B3 (fill the blanks) - average over an array of records.       [5 marks]
   GIVEN   : n (1..32), then n cgpa values, each 4.00..9.99
   ENSURES : final line ends with:  average=<mean to 2 decimals>
   EXAMPLE : input "3 6.00 7.00 8.00" -> "average=7.00"
   BEFORE  : write drill w09
   CHECK   : ./check.sh b3
   total is a double and n is an int, so total / n is real division - the
   trap from W03 does not bite here. It would if total were an int.        */
#include <stdio.h>

struct Student { double cgpa; };

int main(void) {
    struct Student a[32];
    int n, i;
    double total = 0.0;

    if (scanf("%d", &n) != 1) return 1;                   /* given */
    for (i = 0; i < n; i++)
        if (scanf("%lf", &a[i].cgpa) != 1) return 1;      /* given */

    TODO_loop;              /* TODO: add every a[i].cgpa into total */

    TODO_print;             /* TODO: print average=<total/n> to 2 decimals */

    return 0;
}
