/* W06 - an array of structures.                                  [1 mark]
   GIVEN   : three points as six integers, then an index k (0, 1 or 2)
   ENSURES : final line ends with:  x=<a[k].x> y=<a[k].y>
   EXAMPLE : input "1 2 3 4 5 6 1" -> "x=3 y=4"
   WRITE   : the loop that reads the three points.
   BEFORE  : drill d06
   CHECK   : ./check.sh w06
   a[i] is a whole structure; a[i].x is the int inside it.                */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point a[3];
    int i, k;

    TODO_loop;                       /* TODO: read a[0], a[1], a[2] */

    if (scanf("%d", &k) != 1) return 1;       /* given */
    printf("x=%d y=%d\n", a[k].x, a[k].y);    /* given - do not change */
    return 0;
}
