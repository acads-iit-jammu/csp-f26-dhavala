/* W09 - the largest member in an array of structures.            [1 mark]
   GIVEN   : three cgpa values, each 4.00..9.99
   ENSURES : final line ends with:  best=<largest, to 2 decimals>
   WRITE   : the loop that finds the largest.
   BEFORE  : drill d09
   CHECK   : ./check.sh w09
   Keep an INDEX of the best so far, not a copy of the value - the same
   habit you will need in e2, where you must report the record, not just
   the number.                                                            */
#include <stdio.h>
struct Student { double cgpa; };
int main(void) {
    struct Student a[3];
    int i, best = 0;
    for (i = 0; i < 3; i++)
        if (scanf("%lf", &a[i].cgpa) != 1) return 1;      /* given */

    TODO_loop;                       /* TODO: leave the best index in `best` */

    printf("best=%.2f\n", a[best].cgpa);      /* given - do not change */
    return 0;
}
