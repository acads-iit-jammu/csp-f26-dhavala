/* W10 - character arrays inside a structure.                     [1 mark]
   GIVEN   : a name (one word, at most 19 characters) and a programme
             code (EE, ME or MM)
   ENSURES : final line ends with:  name=<name> program=<program>
   WRITE   : the scanf.
   BEFORE  : drill d10
   CHECK   : ./check.sh w10
   s.name is already an array, so it IS an address: no & in front of it.
   Bound the conversions - %19s and %7s - so a long word cannot overrun.  */
#include <stdio.h>
struct Student { char name[20]; char program[8]; };
int main(void) {
    struct Student s;

    TODO_line;                       /* TODO: read the name and the programme */

    printf("name=%s program=%s\n", s.name, s.program);   /* given - do not change */
    return 0;
}
