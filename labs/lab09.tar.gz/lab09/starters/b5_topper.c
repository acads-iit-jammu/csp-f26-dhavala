/* B5 (fill the blanks) - the record with the highest cgpa.       [5 marks]
   GIVEN   : n (1..32), then n pairs: roll cgpa
   ENSURES : final line ends with:  topper=<the roll of the highest cgpa>
   EXAMPLE : input "3 1001 6.00 1002 8.50 1003 7.00" -> "topper=1002"
             input "2 1001 9.00 1002 9.00"           -> "topper=1001"
   BEFORE  : write drill w09
   CHECK   : ./check.sh b5
   A tie goes to the FIRST of them. Test strictly with > and you get that
   for free; write >= and the last one wins instead. The second example is
   there to catch exactly that.                                            */
#include <stdio.h>

struct Student { int roll; double cgpa; };

int main(void) {
    struct Student a[32];
    int n, i, best = 0;

    if (scanf("%d", &n) != 1) return 1;                           /* given */
    for (i = 0; i < n; i++)
        if (scanf("%d %lf", &a[i].roll, &a[i].cgpa) != 2) return 1;   /* given */

    TODO_loop;              /* TODO: leave the index of the best in `best` */

    printf("topper=%d\n", a[best].roll);      /* given - do not change */
    return 0;
}
