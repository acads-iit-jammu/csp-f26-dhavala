/* E1 - is the point inside the rectangle?                        [checked]
   GIVEN   : four integers lx ly hx hy - the low (bottom-left) and high
             (top-right) corners of a rectangle - then two integers px py.
             lx <= hx and ly <= hy always.
   ENSURES : final line ends with:  inside     if the point is inside
                                    outside    if it is not
             A point exactly ON an edge or corner counts as INSIDE.
   EXAMPLE : input "0 0 4 3 2 1" -> "inside"
             input "0 0 4 3 5 1" -> "outside"     (x too big)
             input "0 0 4 3 4 3" -> "inside"      (the corner itself)
   BEFORE  : write drill w08
   CHECK   : ./check.sh e1
   This is Monday's lecture problem. Build it from two structures:
        struct Point { int x, y; };
        struct Rect  { struct Point lo, hi; };
   and write
        int inside(struct Rect r, struct Point p)
   returning 1 or 0. Four conditions, all of which must hold. Two of the
   public vectors sit exactly on the boundary: they decide >= against >.  */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
