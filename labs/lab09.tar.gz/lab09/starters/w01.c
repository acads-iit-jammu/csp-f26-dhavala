/* W01 - put two numbers into a structure.                        [1 mark]
   GIVEN   : two integers x and y, each -99..99
   ENSURES : final line ends with:  x=<x> y=<y>
   WRITE   : the scanf. Read straight into the members of p.
   BEFORE  : drill d01
   CHECK   : ./check.sh w01
   &p.x means "the address of the member x of p" - the & applies to the
   whole thing p.x, not to p.                                             */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point p;

    TODO_line;                       /* TODO: scanf("%d %d", ... , ... ); */

    printf("x=%d y=%d\n", p.x, p.y);          /* given - do not change */
    return 0;
}
