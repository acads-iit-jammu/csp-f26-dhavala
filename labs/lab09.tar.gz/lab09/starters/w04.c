/* W04 - a structure passed BY VALUE.                             [1 mark]
   GIVEN   : one integer x, -99..99
   ENSURES : final line ends with:  x=<x>          (unchanged!)
   WRITE   : the body of moveCopy. Set the x it was given to 99.
   BEFORE  : drill d04
   CHECK   : ./check.sh w04
   Yes, the answer is that nothing happens to main's s. Write it anyway
   and watch it not happen - that is the drill.                           */
#include <stdio.h>
struct Point { int x, y; };

void moveCopy(struct Point p)        /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: set p.x to 99 */
}

int main(void) {
    struct Point s;
    if (scanf("%d", &s.x) != 1) return 1;     /* given */
    s.y = 0;
    moveCopy(s);                              /* given */
    printf("x=%d\n", s.x);                    /* given - do not change */
    return 0;
}
