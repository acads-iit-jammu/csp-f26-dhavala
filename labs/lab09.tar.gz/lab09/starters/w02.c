/* W02 - one structure, two different types inside it.            [1 mark]
   GIVEN   : an integer roll (1001..1999) and a cgpa (4.00..9.99)
   ENSURES : final line ends with:  roll=<roll> cgpa=<cgpa to 2 decimals>
   WRITE   : the scanf. A double is read with %lf, not %f.
   BEFORE  : drill d02
   CHECK   : ./check.sh w02                                               */
#include <stdio.h>
struct Student { int roll; double cgpa; };
int main(void) {
    struct Student s;

    TODO_line;                       /* TODO: read roll and cgpa into s */

    printf("roll=%d cgpa=%.2f\n", s.roll, s.cgpa);   /* given - do not change */
    return 0;
}
