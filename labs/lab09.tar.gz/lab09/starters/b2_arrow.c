/* B2 (fill the blanks) - the same record through a pointer.      [5 marks]
   GIVEN   : a roll (1001..1999) and a cgpa (4.00..9.99)
   ENSURES : final line ends with:  roll=<roll> cgpa=<cgpa to 2 decimals>
   EXAMPLE : input "1001 8.25" -> "roll=1001 cgpa=8.25"
   BEFORE  : write drill w07
   CHECK   : ./check.sh b2
   Use p everywhere below, not s. &p->roll is the address of the member -
   -> binds tighter than &, so it means &(p->roll), which is what you want. */
#include <stdio.h>

struct Student { int roll; double cgpa; };

int main(void) {
    struct Student s;
    struct Student *p = &s;          /* given - p now aims at s */

    TODO_line;              /* TODO: read into the members, through p */

    TODO_line2;             /* TODO: print them, through p */

    return 0;
}
