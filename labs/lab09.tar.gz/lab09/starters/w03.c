/* W03 - assigning a structure COPIES it.                         [1 mark]
   GIVEN   : two integers x and y, each -99..99
   ENSURES : final line ends with:  a=<x>
   WRITE   : copy a into b, then set b.x to 99. a must be unharmed.
   BEFORE  : drill d03
   CHECK   : ./check.sh w03
   This is the whole point of the drill: b = a does not make b another
   name for a. It makes a second structure with the same contents.        */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point a, b;
    if (scanf("%d %d", &a.x, &a.y) != 2) return 1;    /* given */

    TODO_lines;                      /* TODO: two lines - copy, then change b.x */

    printf("a=%d\n", a.x);                    /* given - do not change */
    return 0;
}
