/* W07 - reaching members through a pointer, with ->.             [1 mark]
   GIVEN   : two integers x and y, each -99..99
   ENSURES : final line ends with:  sum=<x+y>
   WRITE   : point q at p, then print the sum using q and -> only.
   BEFORE  : drill d07
   CHECK   : ./check.sh w07
   q->x is the same thing as (*q).x, and is how everyone writes it.       */
#include <stdio.h>
struct Point { int x, y; };
int main(void) {
    struct Point p;
    struct Point *q;
    if (scanf("%d %d", &p.x, &p.y) != 2) return 1;    /* given */

    TODO_lines;                      /* TODO: aim q at p, then print sum=<...> */

    return 0;
}
