/* B4 (fill the blanks) - count the records above a mark.         [5 marks]
   GIVEN   : n (1..32), then n cgpa values, each 4.00..9.99
   ENSURES : final line ends with:  above=<how many are STRICTLY above 7.00>
   EXAMPLE : input "3 6.00 7.00 8.00"      -> "above=1"
             input "3 7.00 7.00 7.00"      -> "above=0"
   BEFORE  : write drill w09, blank b3
   CHECK   : ./check.sh b4
   Strictly above: exactly 7.00 does NOT count. One of the public vectors
   is there only to catch > written as >=.                                 */
#include <stdio.h>

struct Student { double cgpa; };

int main(void) {
    struct Student a[32];
    int n, i, above = 0;

    if (scanf("%d", &n) != 1) return 1;                   /* given */
    for (i = 0; i < n; i++)
        if (scanf("%lf", &a[i].cgpa) != 1) return 1;      /* given */

    TODO_loop;              /* TODO: count the ones strictly above 7.0 */

    printf("above=%d\n", above);              /* given - do not change */
    return 0;
}
