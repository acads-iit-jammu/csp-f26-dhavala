/* E2 - the topper, from a list of records.                       [checked]
   GIVEN   : n on the first line (1..64), then n lines, each holding
                 <roll> <name> <programme> <cgpa>
             name is one word of at most 19 characters; programme is one
             of EE, ME, MM; cgpa is 4.00..9.99.
             NOTE: one word is a SIMPLIFICATION for this lab, not how names
             really are. "Ravi Kumar" would make %19s stop at the space and
             your read return fewer fields than you asked for, ending the
             loop early and skipping the rest of the file - silently. See
             the Week 11 appendix for how real names are handled.
   ENSURES : final line ends with:  topper=<roll> <name>
             of the student with the highest cgpa. A tie goes to the one
             that appears FIRST in the input.
   EXAMPLE : input "3"
                   "1001 Ravi EE 8.20"
                   "1002 Asha ME 6.50"
                   "1003 Iqbal EE 7.10"   ->  "topper=1001 Ravi"
   BEFORE  : write drills w09, w10 and blank b5
   CHECK   : ./check.sh e2
   Declare the record once, with all four members, and read into an array
   of them. Keep the INDEX of the best so far - you have to report two
   things about that student, so remembering only the cgpa is not enough. */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
