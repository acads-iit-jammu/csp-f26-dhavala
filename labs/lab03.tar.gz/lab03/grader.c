/* Lab 03 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader f1..f5 | e1..e3          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 3
static int use_timeout = -1;

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    if (use_timeout)
        snprintf(cmd, sizeof cmd, "timeout 5 ./%s < .gin > .gout 2>&1", prog);
    else
        snprintf(cmd, sizeof cmd, "./%s < .gin > .gout 2>&1", prog);
    int rc = system(cmd);
    if (use_timeout && rc != 0 && (rc == 124*256 || rc/256 == 124)) {
        printf("  TIMEOUT  [%s] input: %s  (5s — is there an accidental infinite wait?)\n", label, input);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) --- */
static void gen_f1(char *in, char *exp) {
    int p = rand()%100001;
    sprintf(in, "%d", p);
    sprintf(exp, "rupees=%d paise=%d", p/100, p%100);
}
static void gen_f2(char *in, char *exp) {
    int a = rand()%101, b = rand()%101, c = rand()%101;
    sprintf(in, "%d %d %d", a, b, c);
    sprintf(exp, "avg=%.2f", (a+b+c)/3.0);
}
static void gen_f3(char *in, char *exp) {
    int a = rand()%1001, b = rand()%1001;
    sprintf(in, "%d %d", a, b);
    sprintf(exp, "a=%d b=%d", b, a);
}
static void gen_f4(char *in, char *exp) {
    int c = 'a' + rand()%26;
    sprintf(in, "%c", (char)c);
    sprintf(exp, "upper=%c code=%d", (char)(c - ('a'-'A')), c - ('a'-'A'));
}
static void gen_f5(char *in, char *exp) {
    int c = rand()%111 - 50;                       /* -50 .. 60 */
    sprintf(in, "%d", c);
    sprintf(exp, "f=%.2f", c*9.0/5 + 32);
}
static void gen_e1(char *in, char *exp) {
    int t = rand()%1000 + 1;
    sprintf(in, "%d", t);
    sprintf(exp, "feet=%d inches=%d", t/12, t%12);
}
static void gen_e2(char *in, char *exp) {
    int total = rand()%100 + 1, marks = rand()%(total+1);
    sprintf(in, "%d %d", marks, total);
    sprintf(exp, "pct=%.2f", marks*100.0/total);
}
static void gen_e3(char *in, char *exp) {
    int c = 'A' + rand()%26;
    sprintf(in, "%c", (char)c);
    sprintf(exp, "lower=%c code=%d", (char)(c + ('a'-'A')), c + ('a'-'A'));
}

struct problem {
    const char *name;
    const char *src;            /* source file to compile */
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
};
static struct problem P[] = {
 {"f1", "f1_money.c",   2, 2, {"1234","99"},
        {"rupees=12 paise=34","rupees=0 paise=99"}, gen_f1},
 {"f2", "f2_average.c", 2, 2, {"10 11 11","0 0 0"},
        {"avg=10.67","avg=0.00"}, gen_f2},
 {"f3", "f3_swap.c",    2, 2, {"3 8","0 1000"},
        {"a=8 b=3","a=1000 b=0"}, gen_f3},
 {"f4", "f4_upper.c",   2, 2, {"q","a"},
        {"upper=Q code=81","upper=A code=65"}, gen_f4},
 {"f5", "f5_temp.c",    2, 2, {"37","0"},
        {"f=98.60","f=32.00"}, gen_f5},
 {"e1", "e1.c",         3, 3, {"100","1","1000"},
        {"feet=8 inches=4","feet=0 inches=1","feet=83 inches=4"}, gen_e1},
 {"e2", "e2.c",         3, 3, {"47 60","0 1","100 100"},
        {"pct=78.33","pct=0.00","pct=100.00"}, gen_e2},
 {"e3", "e3.c",         3, 3, {"Q","A","Z"},
        {"lower=q code=113","lower=a code=97","lower=z code=122"}, gen_e3},
};

int main(int argc, char **argv) {
    if (argc != 2) { printf("usage: ./grader f1..f5|e1..e3\n"); return 2; }
    use_timeout = (system("command -v timeout >/dev/null 2>&1") == 0);
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public");
    for (int i = 0; i < p->nrand; i++) {
        char in[128], exp[256];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random");
    }
    return failed;
}
