CS-1-01 (MO) · Lab 03 — Consolidation: types, operators, precedence
Full instructions: course site > Lab Sheets > Lab 03

  1.  tar xzf lab03.tar.gz && cd lab03
  2.  ./install.sh          <- it PUTS YOU in your workspace and changes
                               your prompt to [lab03 OK ...] so you can
                               always see that you are in the right place
  3.  script session.txt    <- START THE RECORDER FIRST
  4.  ./drill.sh --all      <- 16 predict-then-run drills. Predicting IS
                               the exercise; running is just the marking.
  5.  fill the blanks:  f1_money.c  f2_average.c  f3_swap.c
                        f4_upper.c  f5_temp.c
                        (structure is written; only expressions are missing)
  6.  graded:           e1.c  e2.c  e3.c
  7.  ./check.sh e2         (check one)      ./check.sh   (check everything)
  8.  ./check.sh --bundle   (then carry the bundle out with you)

LOST? Type  ./where.sh  — it works from anywhere and tells you the exact
line to type to get back. You never have to remember a path.

Public test inputs are in each spec. The checker also draws fresh random
inputs from each GIVEN — so compute, don't memorise.
