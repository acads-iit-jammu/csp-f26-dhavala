/* F4 (fill the blanks) — a lowercase letter to uppercase.
   GIVEN   : one lowercase letter, a..z
   ENSURES : final line ends with:  upper=<C> code=<N>
             where <N> is the ASCII code OF THE UPPERCASE letter
   EXAMPLE : input "q"  ->  "upper=Q code=81"
   CHECK   : ./check.sh f4
   Do NOT write 32. Derive the gap the way Drill 12 did, from the
   letters themselves - then it is obvious which way to move. */
#include <stdio.h>

int main(void) {
    char lower, upper;

    printf("Enter a lowercase letter: ");
    scanf(" %c", &lower);            /* the space before %c matters - Lab 02 */

    upper = /* TODO 1: shift it - which direction? */ ;

    printf("upper=%c code=%d\n", upper, /* TODO 2: its code */ );
    return 0;
}
