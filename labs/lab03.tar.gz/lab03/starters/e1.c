/* E1 - inches into feet and inches.                          [graded]
   GIVEN   : one integer, total inches, 1..1000
   ENSURES : final line ends with:  feet=<F> inches=<I>
   EXAMPLE : input "100"  ->  "feet=8 inches=4"
   CHECK   : ./check.sh e1
   Same pair of operators as F1 - a different divisor. 12 inches
   make a foot. Only the two expressions are missing.                */
#include <stdio.h>

int main(void) {
    int total_inches, feet, inches;

    printf("Enter total inches: ");
    scanf("%d", &total_inches);

    feet   = /* TODO 1 */ ;
    inches = /* TODO 2 */ ;

    printf("feet=%d inches=%d\n", feet, inches);     /* given - do not change */
    return 0;
}
