/* E2 - percentage scored.                                    [graded]
   GIVEN   : two integers on one line: marks then total,
             with total 1..100 and 0 <= marks <= total
   ENSURES : final line ends with:  pct=<P>      (<P> to 2 decimals)
   EXAMPLE : input "47 60"  ->  "pct=78.33"
   CHECK   : ./check.sh e2
   One expression. If you get 78.00 instead of 78.33, you have met
   Drill 04 again - and the fix is the one from Drill 03.            */
#include <stdio.h>

int main(void) {
    int marks, total;
    double pct;

    printf("Enter marks and total: ");
    scanf("%d %d", &marks, &total);

    pct = /* TODO 1: what percentage is marks of total? */ ;

    printf("pct=%.2f\n", pct);                       /* given - do not change */
    return 0;
}
