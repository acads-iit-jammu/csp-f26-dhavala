/* F5 (fill the blank) — Celsius to Fahrenheit.
   GIVEN   : one integer temperature in Celsius, -50..60
   ENSURES : final line ends with:  f=<F>       (<F> to 2 decimals)
   EXAMPLE : input "37"  ->  "f=98.60"
   CHECK   : ./check.sh f5
   The formula is  F = C x 9/5 + 32.  Type it exactly like that and it
   will be WRONG - see Drill 03. One character fixes it.               */
#include <stdio.h>

int main(void) {
    int celsius;
    double fahrenheit;

    printf("Enter temperature in Celsius: ");
    scanf("%d", &celsius);

    fahrenheit = /* TODO 1: convert - mind the 9/5 */ ;

    printf("f=%.2f\n", fahrenheit);                  /* given - do not change */
    return 0;
}
