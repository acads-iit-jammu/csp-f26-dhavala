/* F1 (fill the blanks) — paise into rupees and paise.
   GIVEN   : one integer, total paise, 0..100000
   ENSURES : final line ends with:  rupees=<R> paise=<P>
   EXAMPLE : input "1234"  ->  "rupees=12 paise=34"
   CHECK   : ./check.sh f1
   Everything is written for you EXCEPT the two expressions.
   Which operator gives whole rupees? Which gives what is left over? */
#include <stdio.h>

int main(void) {
    int total_paise, rupees, paise;

    printf("Enter total paise: ");
    scanf("%d", &total_paise);

    rupees = /* TODO 1: how many whole rupees? */ ;
    paise  = /* TODO 2: what is left over?     */ ;

    printf("rupees=%d paise=%d\n", rupees, paise);   /* given - do not change */
    return 0;
}
