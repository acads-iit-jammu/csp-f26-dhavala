/* F3 (fill the blanks) — swap two values.
   GIVEN   : two integers on one line, each 0..1000
   ENSURES : final line ends with:  a=<A> b=<B>   (the two, swapped)
   EXAMPLE : input "3 8"  ->  "a=8 b=3"
   CHECK   : ./check.sh f3
   Three assignments, and THE ORDER MATTERS. Get it wrong and one of
   the two values is overwritten before you ever copy it - and it is
   gone for good. Trace it on paper first, with a box for each name. */
#include <stdio.h>

int main(void) {
    int a, b, temp;

    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);

    temp = /* TODO 1: */ ;
    a    = /* TODO 2: */ ;
    b    = /* TODO 3: */ ;

    printf("a=%d b=%d\n", a, b);                     /* given - do not change */
    return 0;
}
