/* F2 (fill the blank) — average of three integers.
   GIVEN   : three integers on one line, each 0..100
   ENSURES : final line ends with:  avg=<A>     (<A> to 2 decimals)
   EXAMPLE : input "10 11 11"  ->  "avg=10.67"
   CHECK   : ./check.sh f2
   ONE expression is missing. Drill 04 is the trap waiting for you here:
   if you divide two ints, the fraction is gone before avg ever sees it. */
#include <stdio.h>

int main(void) {
    int a, b, c;
    double avg;

    printf("Enter three integers: ");
    scanf("%d %d %d", &a, &b, &c);

    avg = /* TODO 1: the average - and keep the fraction! */ ;

    printf("avg=%.2f\n", avg);                       /* given - do not change */
    return 0;
}
