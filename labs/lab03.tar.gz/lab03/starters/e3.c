/* E3 - an uppercase letter to lowercase.                     [graded]
   GIVEN   : one uppercase letter, A..Z
   ENSURES : final line ends with:  lower=<C> code=<N>
             where <N> is the ASCII code OF THE LOWERCASE letter
   EXAMPLE : input "Q"  ->  "lower=q code=113"
   CHECK   : ./check.sh e3
   This is F4 held up to a mirror. Same gap, opposite direction -
   work out the sign yourself rather than guessing.                  */
#include <stdio.h>

int main(void) {
    char upper, lower;

    printf("Enter an uppercase letter: ");
    scanf(" %c", &upper);

    lower = /* TODO 1 */ ;

    printf("lower=%c code=%d\n", lower, /* TODO 2 */ );
    return 0;
}
