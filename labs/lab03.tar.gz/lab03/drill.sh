#!/usr/bin/env bash
# ./drill.sh          list the drills and your progress
# ./drill.sh 3        do drill 3      (also: ./drill.sh d03, ./drill.sh s1)
# ./drill.sh --all    work through every drill you have not done yet
#
# Each drill: you SEE the code, you WRITE your prediction, and only THEN
# does it run. Predicting is the exercise. Running is just the marking.
set -u

if [ ! -f TEAM.txt ]; then
  echo "STOP: this is not your workspace (no TEAM.txt here)."
  echo "Run:  ./where.sh    — it will tell you exactly what to type."
  exit 2
fi

LOG=notes/drills.log
mkdir -p notes; [ -f "$LOG" ] || : > "$LOG"
ALL="d01 d02 d03 d04 d05 d06 d07 d08 d09 d10 d11 d12 d13 d14 s1 s2"

status_of(){ grep -h "^[^ ]* $1 " "$LOG" 2>/dev/null | tail -1 | awk '{print $3}'; }

list(){
  echo "=================================================================="
  echo "  Lab 03 drills — predict first, then run."
  echo
  local done=0 hit=0
  for d in $ALL; do
    s="$(status_of "$d")"
    case "$s" in
      HIT)  mark="[HIT ]"; done=$((done+1)); hit=$((hit+1));;
      MISS) mark="[miss]"; done=$((done+1));;
      *)    mark="[    ]";;
    esac
    case "$d" in
      s*) printf "  %s %-4s %s\n" "$mark" "$d" "(stretch)";;
      *)  printf "  %s %-4s\n" "$mark" "$d";;
    esac
  done
  echo
  echo "  done: $done/16   predicted correctly: $hit"
  echo "  next:  ./drill.sh --all"
  echo "=================================================================="
}

one(){
  local d="$1" src="drills/$1.c"
  [ -f "$src" ] || { echo "drill.sh: no such drill '$d' (try ./drill.sh)"; return 2; }

  echo
  echo "=============== DRILL $d ==========================================="
  cat "$src"
  echo "-------------------------------------------------------------------"
  printf 'YOUR PREDICTION (what will it print?): '
  IFS= read -r pred || return 1
  [ -n "$pred" ] || pred="(no prediction)"

  echo
  echo "--- what actually happens ---"
  local out rc
  if out="$(gcc -std=c11 "$src" -o ".drill_$d" 2>&1)"; then
    out="$(./".drill_$d" 2>&1; printf 'X')"; out="${out%X}"   # keep trailing newline info
    rc=0
    printf '%s' "$out"
    case "$out" in *$'\n') ;; *) printf '   <-- (no newline at the end!)\n';; esac
  else
    rc=1
    echo "COMPILE ERROR — the compiler said:"
    printf '%s\n' "$out" | head -4 | sed 's/^/    /'
  fi
  rm -f ".drill_$d"
  echo "-----------------------------"

  # auto-compare, ignoring whitespace only
  local squash_p squash_a verdict
  squash_p="$(printf '%s' "$pred" | tr -d '[:space:]')"
  squash_a="$(printf '%s' "$out"  | tr -d '[:space:]')"
  if [ "$rc" = 0 ] && [ -n "$squash_p" ] && [ "$squash_p" = "$squash_a" ]; then
    verdict=HIT
    echo "  ** correct — you predicted it exactly. **"
  else
    echo "  you said : $pred"
    if [ "$rc" = 0 ]; then
      echo "  it said  : $(printf '%s' "$out" | tr '\n' '~' | sed 's/~$//; s/~/ [newline] /g')"
    else
      echo "  it said  : (it did not compile)"
    fi
    printf '  Were you right anyway (wording aside)? [y/N] '
    IFS= read -r yn || yn=n
    case "$yn" in y|Y) verdict=HIT;; *) verdict=MISS;; esac
  fi

  printf '%s %s %s pred="%s"\n' "$(date +%FT%T)" "$d" "$verdict" "$pred" >> "$LOG"
  [ "$verdict" = MISS ] && echo "  logged as a miss — that is the useful kind. Ask why before moving on."
  return 0
}

case "${1:-}" in
  "")     list;;
  --all)  for d in $ALL; do [ -n "$(status_of "$d")" ] || one "$d" || break; done; echo; list;;
  --help|-h) sed -n '2,8p' "$0";;
  *)      arg="$1"
          case "$arg" in
            [0-9]) arg="d0$arg";;
            [0-9][0-9]) arg="d$arg";;
          esac
          one "$arg";;
esac
