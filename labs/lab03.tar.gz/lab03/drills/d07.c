/* Drill 07 — compound assignment.
   Is this  x = x * 2 + 3,  or  x = x * (2 + 3) ? */
#include <stdio.h>
int main(void) {
    int x = 5;
    x *= 2 + 3;
    printf("%d\n", x);
    return 0;
}
