/* Drill 11 — assigning a real number to an int.
   Does it round to the nearest, or throw the fraction away? */
#include <stdio.h>
int main(void) {
    int n = 3.9;
    printf("%d\n", n);
    return 0;
}
