/* Drill 09 — one value, two readers.
   The SAME thing is printed twice, with two different format specifiers. */
#include <stdio.h>
int main(void) {
    printf("%d %c\n", 'A', 'A');
    return 0;
}
