/* Drill 01 — integer division.
   Both operands are int. What does C do with the leftover half? */
#include <stdio.h>
int main(void) {
    printf("%d\n", 7 / 2);
    return 0;
}
