/* Drill 12 — deriving the case gap instead of memorising 32.
   What is ('a' - 'A')? Add it to an uppercase letter. */
#include <stdio.h>
int main(void) {
    char up = 'Q';
    printf("%c\n", up + ('a' - 'A'));
    return 0;
}
