/* Drill 02 — negative division and remainder.
   Careful: does -7/2 round DOWN, or TOWARDS ZERO?
   And what sign does the remainder take? */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", -7 / 2, -7 % 2);
    return 0;
}
