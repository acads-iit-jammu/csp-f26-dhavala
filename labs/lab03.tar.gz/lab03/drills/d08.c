/* Drill 08 — assignment is right-associative, and it has a VALUE.
   What does  a = b = 5  give to each? Then what does b become? */
#include <stdio.h>
int main(void) {
    int a, b;
    a = b = 5;
    b += a;
    printf("%d %d\n", a, b);
    return 0;
}
