/* Drill 10 — characters do arithmetic.
   What is 'A' + 1? Print it both ways. */
#include <stdio.h>
int main(void) {
    char c = 'A';
    printf("%c %d\n", c + 1, c + 1);
    return 0;
}
