/* Drill 04 — can a float variable rescue a bad division?
   The variable is a float. The division is not. Who wins? */
#include <stdio.h>
int main(void) {
    float f = 7 / 2;
    printf("%.6f\n", f);
    return 0;
}
