/* Drill 14 — printf adds nothing you did not ask for.
   Three calls, ONE \n between them. How many lines appear,
   and what happens to your shell prompt afterwards? */
#include <stdio.h>
int main(void) {
    printf("A");
    printf("B\n");
    printf("C");
    return 0;
}
