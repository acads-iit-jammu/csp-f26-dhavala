/* Drill 03 — where the cast sits.
   Three lines, three answers. Only ONE of them differs. Which, and why? */
#include <stdio.h>
int main(void) {
    printf("%f\n", 7 / 2.0);
    printf("%f\n", (float) 7 / 2);
    printf("%f\n", (float) (7 / 2));
    return 0;
}
