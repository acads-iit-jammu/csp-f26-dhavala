/* Stretch S2 — predict the ERROR, not the output.
   This program does not compile. Before you run it: what will
   the compiler complain about, and on which line?
   (What kind of numbers can % work with?) */
#include <stdio.h>
int main(void) {
    float f = 7.0;
    printf("%f\n", f % 2);
    return 0;
}
