/* Drill 13 — printf's own arithmetic.
   Does %.0f truncate or round? What does the 5 in %5.1f do?
   The | bars are there so you can SEE the spaces. */
#include <stdio.h>
int main(void) {
    printf("%.2f|%.0f|%5.1f|\n", 3.14159, 3.6, 3.14159);
    return 0;
}
