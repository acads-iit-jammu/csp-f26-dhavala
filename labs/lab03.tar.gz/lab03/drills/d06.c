/* Drill 06 — associativity.
   With no parentheses, WHICH division happens first?
   (Hint: it is not "the innermost one" — there is no inner one.) */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", 100 / 10 / 2, 100 / (10 / 2));
    return 0;
}
