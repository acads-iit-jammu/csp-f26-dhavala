/* Drill 05 — precedence.
   Same digits, one pair of parentheses. */
#include <stdio.h>
int main(void) {
    printf("%d %d\n", 2 + 3 * 4, (2 + 3) * 4);
    return 0;
}
