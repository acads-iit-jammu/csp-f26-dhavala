/* Stretch S1 — a comparison IS a value.
   (This one looks ahead to Week 7. Have a guess anyway.)
   Which happens first: the + or the > ? And what does a
   comparison evaluate TO? */
#include <stdio.h>
int main(void) {
    printf("%d\n", 2 + 3 > 4);
    return 0;
}
