Lab 08 — Pointers and Strings
=============================

Everything happens INSIDE your workspace. If your prompt does not say
[lab08 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder (your proof of work)
  3.  ./drill.sh --all      10 READ drills — predict, then run. NOT marked.
  4.  w01 ... w10           10 WRITE drills, 1 mark each. One line of C
                            each. This is where you practise the notation.
  5.  b1_deref.c  b2_swap.c  b3_length.c  b4_count.c  b5_upper.c
                            5 blanks, 5 marks each. One function body each.
  6.  e1.c  e2.c  e3.c  e4.c
                            4 problems, 10 marks each. Specification only.
  7.  ./check.sh            self-check, with your marks so far
  8.  ./check.sh --bundle   bundle it, carry it out

                     10 + 25 + 40 = 75 marks

The order matters. Each write drill rehearses one piece of notation; each
blank uses two or three of them; each checked problem uses several blanks.
Every starter says, on its BEFORE line, which drills come first.

Every problem has a ready-made input file, named the same way:

    ./w01 < w01_sample.txt        ./b3_length < b3_sample.txt
    ./e2 < e2_sample.txt

Each file reproduces the EXAMPLE printed at the top of that starter, so if
your program is right you see exactly what the specification promised.

How to build and run one:

    gcc w01.c -o w01
    ./w01 < w01_sample.txt
    ./check.sh w01

Plain gcc. No -lm, no other flags.

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler has never heard of, so it tells you exactly which line is
still waiting for you.
