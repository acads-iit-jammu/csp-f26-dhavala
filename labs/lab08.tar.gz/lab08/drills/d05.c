/* D05 - two ways of writing the same thing. Do they agree? */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 40, 50 };
    printf("%d %d\n", a[3], *(a + 3));
    return 0;
}
