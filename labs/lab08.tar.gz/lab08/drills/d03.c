/* D03 - how many pointers are declared here? What is q? */
#include <stdio.h>
int main(void) {
    int x = 3;
    int *p, q;
    p = &x;
    q = 4;
    printf("%d %d\n", *p, q);
    return 0;
}
