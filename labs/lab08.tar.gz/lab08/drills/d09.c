/* D09 - how many comparisons does isPalindrome make before it answers? */
#include <stdio.h>

int comparisons = 0;

int isPalindrome(char s[], int n)
{
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        comparisons++;
        if (s[lo] != s[hi])
            return 0;
        lo++;
        hi--;
    }
    return 1;
}

int main(void) {
    char a[] = "level";
    printf("%d %d\n", isPalindrome(a, 5), comparisons);
    return 0;
}
