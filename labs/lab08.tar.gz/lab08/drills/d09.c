/* D09 - strcmp returns zero when the strings are WHAT? */
#include <stdio.h>
#include <string.h>
int main(void) {
    if (strcmp("abc", "abc"))
        printf("branch A\n");
    else
        printf("branch B\n");
    return 0;
}
