/* D02 - the write goes through the pointer. What is x afterwards? */
#include <stdio.h>
int main(void) {
    int x = 5;
    int *p = &x;
    *p = 7;
    printf("x = %d\n", x);
    return 0;
}
