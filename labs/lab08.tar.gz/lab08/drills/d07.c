/* D07 - six boxes for five letters. Predict both numbers. */
#include <stdio.h>
#include <string.h>
int main(void) {
    char s[] = "level";
    printf("%zu %zu\n", sizeof s, strlen(s));
    return 0;
}
