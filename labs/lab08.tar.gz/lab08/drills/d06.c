/* D06 - sizeof in main, and sizeof in the function. Predict BOTH. */
#include <stdio.h>
void show(int a[]) {
    printf("%zu\n", sizeof a);
}
int main(void) {
    int a[10];
    printf("%zu\n", sizeof a);
    show(a);
    return 0;
}
