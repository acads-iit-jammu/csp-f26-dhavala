/* D10 - the function changes its parameter. Does main's x change? */
#include <stdio.h>
void addOne(int n) { n = n + 1; }
int main(void) {
    int x = 5;
    addOne(x);
    printf("x = %d\n", x);
    return 0;
}
