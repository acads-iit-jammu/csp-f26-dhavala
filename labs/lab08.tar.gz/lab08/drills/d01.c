/* D01 - p holds the address of x. What does *p print? */
#include <stdio.h>
int main(void) {
    int x = 5;
    int *p = &x;
    printf("%d\n", *p);
    return 0;
}
