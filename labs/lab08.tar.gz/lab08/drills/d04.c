/* D04 - p + 1 moves how far? Predict the number. */
#include <stdio.h>
int main(void) {
    int a[5] = { 10, 20, 30, 40, 50 };
    int *p = a;
    printf("%td\n", (p + 1) - p);
    return 0;
}
