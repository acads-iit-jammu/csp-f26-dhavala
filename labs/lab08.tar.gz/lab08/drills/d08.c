/* D08 - how many times does the loop body run? */
#include <stdio.h>
int main(void) {
    char s[] = "hello";
    int n = 0;
    while (s[n] != '\0')
        n++;
    printf("steps = %d\n", n);
    return 0;
}
