/* B1 (fill the blanks) - a function that changes the caller's variable.
   GIVEN   : two integers x and v, each -99..99
   ENSURES : final line ends with:  x=<v>
   EXAMPLE : input "5 9" -> "x=9"
   BEFORE  : write drills w02, w04
   CHECK   : ./check.sh b1
   setTo is given WHERE the caller's variable lives, not a copy of it.   */
#include <stdio.h>

void setTo(int *n, int v)            /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: put v into the caller's variable */
}

int main(void) {
    int x, v;
    if (scanf("%d %d", &x, &v) != 2) return 1;
    setTo(&x, v);                             /* given - note the & */
    printf("x=%d\n", x);                      /* given - do not change */
    return 0;
}
