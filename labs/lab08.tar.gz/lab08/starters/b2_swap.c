/* B2 (fill the blanks) - the swap that actually swaps.
   GIVEN   : two integers a and b, each -99..99
   ENSURES : final line ends with:  a=<B> b=<A>      (they come back exchanged)
   EXAMPLE : input "3 8"  -> "a=8 b=3"
             input "-5 0" -> "a=0 b=-5"
   BEFORE  : write drill w08, read drill d10
   CHECK   : ./check.sh b2
   You will need one extra variable to hold a value while you move the other. */
#include <stdio.h>

void swap(int *a, int *b)            /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: exchange the two values */
}

int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) return 1;
    swap(&a, &b);                             /* given - note the two & signs */
    printf("a=%d b=%d\n", a, b);              /* given - do not change */
    return 0;
}
