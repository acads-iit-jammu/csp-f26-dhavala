/* B4 (fill the blanks) - how many times does a character appear?
   GIVEN   : one word of lowercase letters (1 to 16), then one character
   ENSURES : final line ends with:  count=<N>
   EXAMPLE : input "hello l"  -> "count=2"
             input "banana a" -> "count=3"
             input "abc z"    -> "count=0"
   BEFORE  : write drill w06, blank b3
   CHECK   : ./check.sh b4
   Walk the string once. A character that never appears is a count of zero,
   not an error.                                                           */
#include <stdio.h>

int countChar(char s[], char c)      /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: count how many times c appears in s */
}

int main(void) {
    char s[60]; char c;
    if (scanf("%59s %c", s, &c) != 2) return 1;
    printf("count=%d\n", countChar(s, c));     /* given - do not change */
    return 0;
}
