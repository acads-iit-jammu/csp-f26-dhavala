/* W08 - a swap that actually swaps.                    [1 mark]
   GIVEN   : two integers a and b, each -99..99
   ENSURES : final line ends with:  a=<b> b=<a>
   WRITE   : the body of swap, and the call.
   BEFORE   : drills d02, d10
   CHECK   : ./check.sh w08                                        */
#include <stdio.h>

void swap(int *x, int *y)
{
    TODO_body;              /* TODO: exchange the two values */
}

int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) return 1;

    TODO_call;              /* TODO: call swap so that a and b change */

    printf("a=%d b=%d\n", a, b);     /* given - do not change */
    return 0;
}
