/* B5 (fill the blanks) - put a string into capitals, in place.
   GIVEN   : one word of lowercase letters, 1 to 16 of them
   ENSURES : final line ends with:  upper=<the word in capitals>
   EXAMPLE : input "hello" -> "upper=HELLO"
             input "a"     -> "upper=A"
   BEFORE  : write drill w06, blank b3
   CHECK   : ./check.sh b5
   toUpper returns nothing. It changes the caller's array directly, which it
   can do because an array argument is converted to a pointer.
   To move a letter from the small range to the capital range, subtract 'a'
   and add 'A'. That says what it means and does not rely on remembering 32. */
#include <stdio.h>

void toUpper(char s[])               /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: change every letter of s to a capital */
}

int main(void) {
    char s[60];
    if (scanf("%59s", s) != 1) return 1;
    toUpper(s);
    printf("upper=%s\n", s);                   /* given - do not change */
    return 0;
}
