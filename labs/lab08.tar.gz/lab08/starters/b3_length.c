/* B3 (fill the blanks) - the length of a string, by hand.
   GIVEN   : one word of lowercase letters, 1 to 20 of them
   ENSURES : final line ends with:  len=<length>
   EXAMPLE : input "level" -> "len=5"
             input "a"     -> "len=1"
   BEFORE  : write drill w06, read drill d08
   CHECK   : ./check.sh b3
   Do not use strlen. Count the characters before the '\0' yourself. The
   terminator is not part of the length.                                   */
#include <stdio.h>

int myStrlen(char s[])               /* the promise - do not change this line */
{
    TODO_body;                       /* TODO: count the characters and return it */
}

int main(void) {
    char s[60];
    if (scanf("%59s", s) != 1) return 1;
    printf("len=%d\n", myStrlen(s));           /* given - do not change */
    return 0;
}
