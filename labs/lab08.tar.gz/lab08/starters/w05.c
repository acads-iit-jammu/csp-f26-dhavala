/* W05 - the length of a string, using the library.     [1 mark]
   GIVEN   : one word of lowercase letters, up to 12 of them
   ENSURES : final line ends with:  len=<length>
   WRITE   : one expression, using strlen.
   BEFORE   : drill d07
   CHECK   : ./check.sh w05                                        */
#include <stdio.h>
#include <string.h>
int main(void) {
    char s[50];
    if (scanf("%49s", s) != 1) return 1;

    printf("len=%zu\n", TODO_expression);    /* TODO: the length of s */
    return 0;
}
