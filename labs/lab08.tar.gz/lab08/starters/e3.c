/* E3 - the longest run of one repeated character.               [checked]
   GIVEN   : one word of lowercase letters, 1 to 16 of them
   ENSURES : final line ends with:  longest=<N> char=<C>
             N is the length of the longest unbroken run of the same
             character, and C is that character. If two runs are equally
             long, report the one that STARTS EARLIER.
   EXAMPLE : input "aaabbbb" -> "longest=4 char=b"
             input "abcde"   -> "longest=1 char=a"
             input "aabbaaa" -> "longest=3 char=a"
   BEFORE  : write drill w06 and blank b4
   CHECK   : ./check.sh e3
   You need two counters: how long the run you are currently in is, and how
   long the best run so far was. A character that differs from the one
   before it does not merely fail to extend the run - it ENDS it, and the
   current counter goes back to 1.
   Work "aabbaaa" out on paper before writing any code.                    */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
