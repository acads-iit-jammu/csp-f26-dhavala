/* W06 - the length of a string, by walking it.         [1 mark]
   GIVEN   : one word of lowercase letters, up to 12 of them
   ENSURES : final line ends with:  count=<length>
   WRITE   : the loop. Stop when you reach the '\0'. Do not use strlen.
   BEFORE   : drill d08
   CHECK   : ./check.sh w06                                        */
#include <stdio.h>
int main(void) {
    char s[50];
    int n = 0;
    if (scanf("%49s", s) != 1) return 1;

    TODO_loop;              /* TODO: advance n to the end of the text */

    printf("count=%d\n", n);         /* given - do not change */
    return 0;
}
