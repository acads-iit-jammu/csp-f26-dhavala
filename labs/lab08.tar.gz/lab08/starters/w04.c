/* W04 - let a function change the caller's variable.   [1 mark]
   GIVEN   : one integer x, -99..99
   ENSURES : final line ends with:  x=<x + 1>
   WRITE   : the body of addOne, one line, and the call.
   BEFORE   : drills d02, d10
   CHECK   : ./check.sh w04                                        */
#include <stdio.h>

void addOne(int *n)
{
    TODO_body;              /* TODO: add one to the caller's variable */
}

int main(void) {
    int x;
    if (scanf("%d", &x) != 1) return 1;

    TODO_call;              /* TODO: call addOne so that x changes */

    printf("x=%d\n", x);             /* given - do not change */
    return 0;
}
