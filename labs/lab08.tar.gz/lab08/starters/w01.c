/* W01 - print a variable THROUGH A POINTER.            [1 mark]
   GIVEN   : one integer x, -99..99
   ENSURES : final line ends with:  value=<x>
   WRITE   : one line. Declare a pointer called p and point it at x.
   BEFORE   : drill d01
   CHECK   : ./check.sh w01                                        */
#include <stdio.h>
int main(void) {
    int x;
    if (scanf("%d", &x) != 1) return 1;

    TODO_line;              /* TODO: int *p = ... ; */

    printf("value=%d\n", *p);        /* given - do not change */
    return 0;
}
