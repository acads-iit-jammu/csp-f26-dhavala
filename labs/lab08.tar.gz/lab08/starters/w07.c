/* W07 - are two strings the same?                      [1 mark]
   GIVEN   : two words of three lowercase letters each
   ENSURES : final line ends with:  same=1  if they are equal
                                    same=0  if they are not
   WRITE   : the condition. Remember what strcmp returns when equal.
   BEFORE   : drill d09
   CHECK   : ./check.sh w07                                        */
#include <stdio.h>
#include <string.h>
int main(void) {
    char a[50], b[50];
    if (scanf("%49s %49s", a, b) != 2) return 1;

    if (TODO_condition) printf("same=1\n");    /* TODO */
    else                printf("same=0\n");
    return 0;
}
