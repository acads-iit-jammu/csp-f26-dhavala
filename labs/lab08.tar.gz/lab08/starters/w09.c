/* W09 - read a word and print it back.                 [1 mark]
   GIVEN   : one word of lowercase letters, up to 12 of them
   ENSURES : final line ends with:  word=<the word>
   WRITE   : the scanf. Note there is NO & before an array.
   BEFORE   : section 11b of the W10 notes
   CHECK   : ./check.sh w09                                        */
#include <stdio.h>
int main(void) {
    char w[50];

    TODO_read;              /* TODO: read one word into w, at most 49 characters */

    printf("word=%s\n", w);          /* given - do not change */
    return 0;
}
