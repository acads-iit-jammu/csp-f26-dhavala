/* E2 - reverse a word in place, and say how much work it took.  [checked]
   GIVEN   : one word of lowercase letters, 1 to 16 of them
   ENSURES : final line ends with:  reversed=<the word backwards> swaps=<N>
             N is the number of exchanges you performed.
   EXAMPLE : input "abcd"  -> "reversed=dcba swaps=2"
             input "level" -> "reversed=level swaps=2"
             input "a"     -> "reversed=a swaps=0"
   BEFORE  : write drills w06, w08 and blank b3
   CHECK   : ./check.sh e2
   Two indices start at the two ends and move towards each other, exchanging
   as they go, and stop when they meet. A word of odd length has a middle
   character that is never exchanged - look at "level", which is five
   characters but only two swaps.
   Reverse the caller's array itself; do not build a second one.           */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
