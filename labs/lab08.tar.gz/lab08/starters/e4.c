/* E4 - shift every letter along the alphabet, in place.         [checked]
   GIVEN   : one word of lowercase letters (1 to 16), then an integer k,
             0 to 25
   ENSURES : final line ends with:  shifted=<the shifted word>
             Each letter moves k places later in the alphabet, wrapping
             round from z back to a.
   EXAMPLE : input "abc 2"   -> "shifted=cde"
             input "xyz 3"   -> "shifted=abc"
             input "hello 0" -> "shifted=hello"
   BEFORE  : blank b5
   CHECK   : ./check.sh e4
   Write it as    void shift(char s[], int k)    and change the caller's
   array directly, as b5 did.
   The wrap is the whole problem. Work with the letter's position in the
   alphabet rather than its character code: subtract 'a' to get 0..25, do
   the arithmetic there, then add 'a' back. The % operator does the
   wrapping for you.                                                       */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
