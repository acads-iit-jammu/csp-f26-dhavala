/* W02 - change a variable THROUGH A POINTER.           [1 mark]
   GIVEN   : two integers x and v, each -99..99
   ENSURES : final line ends with:  x=<v>
   WRITE   : one line. Use p to put v into x. Do not mention x.
   BEFORE   : drill d02
   CHECK   : ./check.sh w02                                        */
#include <stdio.h>
int main(void) {
    int x, v;
    int *p = &x;
    if (scanf("%d %d", &x, &v) != 2) return 1;

    TODO_line;              /* TODO: write v into x, using p */

    printf("x=%d\n", x);             /* given - do not change */
    return 0;
}
