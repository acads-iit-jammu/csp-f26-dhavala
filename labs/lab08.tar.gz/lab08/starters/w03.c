/* W03 - reach an array element through a pointer.      [1 mark]
   GIVEN   : five integers 0..99, then an index k, 0..4
   ENSURES : final line ends with:  a=<the k-th element>
   WRITE   : one expression. Use p and k, not a[k].
   BEFORE   : drills d04, d05
   CHECK   : ./check.sh w03                                        */
#include <stdio.h>
int main(void) {
    int a[5], i, k;
    int *p = a;
    for (i = 0; i < 5; i++) if (scanf("%d", &a[i]) != 1) return 1;
    if (scanf("%d", &k) != 1) return 1;

    printf("a=%d\n", TODO_expression);   /* TODO: the k-th element, via p */
    return 0;
}
