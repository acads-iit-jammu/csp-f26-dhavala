/* W10 - the first and last characters of a word.       [1 mark]
   GIVEN   : one word of lowercase letters, up to 12 of them
   ENSURES : final line ends with:  first=<c> last=<c>
   WRITE   : the two expressions. The last character is not at strlen(s).
   BEFORE   : drills d07, d08
   CHECK   : ./check.sh w10                                        */
#include <stdio.h>
#include <string.h>
int main(void) {
    char s[50];
    if (scanf("%49s", s) != 1) return 1;

    printf("first=%c last=%c\n", TODO_first, TODO_last);   /* TODO: both */
    return 0;
}
