/* E1 - three answers out of one walk.                          [checked]
   GIVEN   : one "word" of 1 to 12 characters, which may contain letters
             (either case), digits, and punctuation such as ! # _ - .
   ENSURES : final line ends with:  letters=<L> digits=<D> others=<O>
             L counts a-z and A-Z, D counts 0-9, O counts everything else.
   EXAMPLE : input "ab12!"  -> "letters=2 digits=2 others=1"
             input "abcdef" -> "letters=6 digits=0 others=0"
   BEFORE  : write drills w04, w06 and blank b4
   CHECK   : ./check.sh e1
   Write it as
        void classify(char s[], int *letters, int *digits, int *others)
   and call it once from main.
   A function can only return one value, and you owe the caller three. All
   three therefore come back through pointers, which is what w04 rehearsed
   with one. Walk the string once, not three times.                        */
#include <stdio.h>

int main(void) {
    TODO_write_this_program;
}
