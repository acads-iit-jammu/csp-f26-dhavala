/* Lab 08 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e5          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 8      /* headroom: a problem may need extra public vectors to pin its own trap */
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}


/* ---- full-output comparison (for problems that print a grid) ------------
   Compares the WHOLE output, line by line, after normalising whitespace:
   runs of blanks collapse to one, ends are trimmed, blank lines are dropped.
   So printf alignment is the student's business, not the grader's - what is
   checked is the right values in the right order on the right rows.
   Prompts are allowed: a leading prompt on the first line is tolerated by
   letting the expected text match at the END of that line.               */
#define BLANKCH(ch) ((ch)==' ' || (ch)=='\t' || (ch)=='\n' || (ch)=='\r')
static void squeeze(const char *in, char *out, int n) {
    int i = 0, sp = 0; const char *p = in;
    while (BLANKCH(*p)) p++;
    for (; *p && i < n-1; p++) {
        if (BLANKCH(*p)) { sp = 1; continue; }
        if (sp && i > 0) out[i++] = ' ';
        sp = 0;
        if (i < n-1) out[i++] = *p;
    }
    out[i] = 0;
}

/* strsep() is hidden by glibc under -std=c11 (it needs _DEFAULT_SOURCE), and
   since GCC 14 an implicit declaration is a hard error. check-ta.sh compiles
   this file with -std=c11, so the grader would fail to build on the Ubuntu
   lab image and silently score every bundle zero. Written out instead.      */
static char *next_line(char **sp) {
    char *s = *sp, *e;
    if (!s) return NULL;
    e = strchr(s, '\n');
    if (e) { *e = 0; *sp = e + 1; }
    else   { *sp = NULL; }
    return s;
}

static int cmp_full(const char *path, const char *expected, char *why, int wn) {
    char eb[4096]; strncpy(eb, expected, sizeof eb - 1); eb[sizeof eb - 1] = 0;
    FILE *f = fopen(path, "r");
    if (!f) { snprintf(why, wn, "produced no output at all"); return 1; }

    char gl[1024], gs[1024], es[1024];
    char *esave = eb, *eline;
    int row = 0;
    for (;;) {
        /* next non-blank expected line */
        do { eline = next_line(&esave); } while (eline && *eline == 0);
        /* next non-blank produced line */
        int have = 0;
        while (fgets(gl, sizeof gl, f)) { squeeze(gl, gs, sizeof gs); if (gs[0]) { have = 1; break; } }
        if (!eline && !have) { fclose(f); return 0; }                 /* both ended together */
        if (!eline) { snprintf(why, wn, "extra output after line %d: \"%s\"", row, gs); fclose(f); return 1; }
        if (!have)  { snprintf(why, wn, "output stopped early - line %d is missing (expected \"%s\")", row+1, eline); fclose(f); return 1; }
        row++;
        squeeze(eline, es, sizeof es);
        size_t glen = strlen(gs), elen = strlen(es);
        int ok = (glen >= elen) && strcmp(gs + glen - elen, es) == 0;   /* allow a prompt in front */
        if (!ok) { snprintf(why, wn, "line %d differs\n             you printed : \"%s\"\n             expected     : \"%s\"", row, gs, es);
                   fclose(f); return 1; }
    }
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label, int full) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    if (full) {
        char why[1024] = "";
        if (cmp_full(".gout", expected, why, sizeof why) == 0) {
            printf("  PASS     [%s] input: %s\n", label, input);
            return 0;
        }
        printf("  WRONG    [%s] input: %s\n           %s\n", label, input, why);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference answers (the specs state these anyway) ----
   What this file cannot give you is tomorrow's random inputs.          */

static void rand_word(char *w, int lo, int hi) {
    int n = rand() % (hi - lo + 1) + lo, i;
    for (i = 0; i < n; i++) w[i] = (char)('a' + rand() % 26);
    w[n] = 0;
}
static void rand_runs(char *w) {           /* a word with deliberate runs */
    int n = 0, groups = rand() % 4 + 2, g;
    for (g = 0; g < groups; g++) {
        char c = (char)('a' + rand() % 4);
        int k = rand() % 4 + 1, i;
        for (i = 0; i < k && n < 40; i++) w[n++] = c;
    }
    w[n] = 0;
}
static void rand_mixed(char *w) {
    static const char pool[] = "abcXYZ019!#_-.";
    int n = rand() % 12 + 1, i;
    for (i = 0; i < n; i++) w[i] = pool[rand() % (int)(sizeof pool - 1)];
    w[n] = 0;
}
static int runLongest(const char *s, char *which) {
    int best = 1, cur = 1, bi = 0, i;
    if (!s[0]) { *which = '-'; return 0; }
    for (i = 1; s[i]; i++) {
        if (s[i] == s[i-1]) cur++; else cur = 1;
        if (cur > best) { best = cur; bi = i - cur + 1; }
    }
    *which = s[bi];
    return best;
}

/* ---- the ten write drills ---- */
static void gen_w01(char *in, char *exp){ int x = rand()%199-99; sprintf(in,"%d",x); sprintf(exp,"value=%d",x); }
static void gen_w02(char *in, char *exp){ int x = rand()%199-99, v = rand()%199-99; sprintf(in,"%d %d",x,v); sprintf(exp,"x=%d",v); }
static void gen_w03(char *in, char *exp){
    int a[5], i, k = rand()%5, n = 0;
    for (i = 0; i < 5; i++) a[i] = rand()%100;
    for (i = 0; i < 5; i++) n += sprintf(in+n, "%d ", a[i]);
    sprintf(in+n, "%d", k);
    sprintf(exp, "a=%d", a[k]);
}
static void gen_w04(char *in, char *exp){ int x = rand()%199-99; sprintf(in,"%d",x); sprintf(exp,"x=%d",x+1); }
static void gen_w05(char *in, char *exp){ char w[64]; rand_word(w,1,12); sprintf(in,"%s",w); sprintf(exp,"len=%d",(int)strlen(w)); }
static void gen_w06(char *in, char *exp){ char w[64]; rand_word(w,1,12); sprintf(in,"%s",w); sprintf(exp,"count=%d",(int)strlen(w)); }
static void gen_w07(char *in, char *exp){
    char a[8], b[8]; rand_word(a,3,3);
    if (rand()%2) strcpy(b,a); else rand_word(b,3,3);
    sprintf(in,"%s %s",a,b); sprintf(exp,"same=%d", strcmp(a,b)==0);
}
static void gen_w08(char *in, char *exp){ int a=rand()%199-99,b=rand()%199-99; sprintf(in,"%d %d",a,b); sprintf(exp,"a=%d b=%d",b,a); }
static void gen_w09(char *in, char *exp){ char w[64]; rand_word(w,1,12); sprintf(in,"%s",w); sprintf(exp,"word=%s",w); }
static void gen_w10(char *in, char *exp){ char w[64]; rand_word(w,1,12); sprintf(in,"%s",w);
    sprintf(exp,"first=%c last=%c", w[0], w[strlen(w)-1]); }

/* ---- the five blanks ---- */
static void gen_b1(char *in, char *exp){ int x=rand()%199-99,v=rand()%199-99; sprintf(in,"%d %d",x,v); sprintf(exp,"x=%d",v); }
static void gen_b2(char *in, char *exp){ int a=rand()%199-99,b=rand()%199-99; sprintf(in,"%d %d",a,b); sprintf(exp,"a=%d b=%d",b,a); }
static void gen_b3(char *in, char *exp){ char w[64]; rand_word(w,1,20); sprintf(in,"%s",w); sprintf(exp,"len=%d",(int)strlen(w)); }
static void gen_b4(char *in, char *exp){
    char w[64]; char c; int i, n = 0;
    rand_word(w,1,16);
    c = (rand()%2) ? w[rand()%(int)strlen(w)] : (char)('a'+rand()%26);   /* often present */
    for (i = 0; w[i]; i++) if (w[i]==c) n++;
    sprintf(in,"%s %c",w,c); sprintf(exp,"count=%d",n);
}
static void gen_b5(char *in, char *exp){
    char w[64]; int i; rand_word(w,1,16);
    sprintf(in,"%s",w);
    { char u[64]; for (i=0; w[i]; i++) u[i]=(char)(w[i]-'a'+'A'); u[i]=0; sprintf(exp,"upper=%s",u); }
}

/* ---- the four checked problems ---- */
static void gen_e1(char *in, char *exp){
    char w[64]; int i, L=0, D=0, O=0;
    rand_mixed(w);
    for (i=0; w[i]; i++){
        if ((w[i]>='a'&&w[i]<='z')||(w[i]>='A'&&w[i]<='Z')) L++;
        else if (w[i]>='0'&&w[i]<='9') D++;
        else O++;
    }
    sprintf(in,"%s",w); sprintf(exp,"letters=%d digits=%d others=%d",L,D,O);
}
static void gen_e2(char *in, char *exp){
    char w[64], r[64]; int n, i;
    rand_word(w,1,16); n=(int)strlen(w);
    for (i=0;i<n;i++) r[i]=w[n-1-i];
    r[n]=0;
    sprintf(in,"%s",w); sprintf(exp,"reversed=%s swaps=%d",r,n/2);
}
static void gen_e3(char *in, char *exp){
    char w[64], c; int best;
    rand_runs(w);
    best = runLongest(w,&c);
    sprintf(in,"%s",w); sprintf(exp,"longest=%d char=%c",best,c);
}
static void gen_e4(char *in, char *exp){
    char w[64], o[64]; int k = rand()%26, i;
    rand_word(w,1,16);
    for (i=0; w[i]; i++) o[i]=(char)('a'+(w[i]-'a'+k)%26);
    o[strlen(w)]=0;
    sprintf(in,"%s %d",w,k); sprintf(exp,"shifted=%s",o);
}

struct problem {
    const char *name;
    const char *src;
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
    int full;                   /* 1 = compare the whole output, not just the last line */
};
static struct problem P[] = {
 {"w01", "w01.c", 4, 2,
   {"5", "-7", "0", "42"},
   {"value=5", "value=-7", "value=0", "value=42"},
   gen_w01, 0},
 {"w02", "w02.c", 3, 2,
   {"5 9", "-3 0", "0 -12"},
   {"x=9", "x=0", "x=-12"},
   gen_w02, 0},
 {"w03", "w03.c", 3, 2,
   {"10 20 30 40 50 2", "1 2 3 4 5 0", "7 7 7 7 7 4"},
   {"a=30", "a=1", "a=7"},
   gen_w03, 0},
 {"w04", "w04.c", 3, 2,
   {"5", "-1", "99"},
   {"x=6", "x=0", "x=100"},
   gen_w04, 0},
 {"w05", "w05.c", 3, 2,
   {"level", "a", "programming"},
   {"len=5", "len=1", "len=11"},
   gen_w05, 0},
 {"w06", "w06.c", 3, 2,
   {"level", "a", "programming"},
   {"count=5", "count=1", "count=11"},
   gen_w06, 0},
 {"w07", "w07.c", 3, 2,
   {"abc abc", "abc abd", "aaa aaa"},
   {"same=1", "same=0", "same=1"},
   gen_w07, 0},
 {"w08", "w08.c", 3, 2,
   {"3 8", "-5 0", "7 7"},
   {"a=8 b=3", "a=0 b=-5", "a=7 b=7"},
   gen_w08, 0},
 {"w09", "w09.c", 3, 2,
   {"level", "hello", "z"},
   {"word=level", "word=hello", "word=z"},
   gen_w09, 0},
 {"w10", "w10.c", 3, 2,
   {"level", "hello", "z"},
   {"first=l last=l", "first=h last=o", "first=z last=z"},
   gen_w10, 0},
 {"b1", "b1_deref.c", 4, 3,
   {"5 9", "-3 0", "0 -12", "7 7"},
   {"x=9", "x=0", "x=-12", "x=7"},
   gen_b1, 0},
 {"b2", "b2_swap.c", 4, 3,
   {"3 8", "-5 0", "7 7", "0 -99"},
   {"a=8 b=3", "a=0 b=-5", "a=7 b=7", "a=-99 b=0"},
   gen_b2, 0},
 {"b3", "b3_length.c", 4, 3,
   {"level", "a", "programming", "xy"},
   {"len=5", "len=1", "len=11", "len=2"},
   gen_b3, 0},
 {"b4", "b4_count.c", 4, 3,
   {"hello l", "banana a", "abc z", "aaaa a"},
   {"count=2", "count=3", "count=0", "count=4"},
   gen_b4, 0},
 {"b5", "b5_upper.c", 4, 3,
   {"hello", "a", "programming", "xyz"},
   {"upper=HELLO", "upper=A", "upper=PROGRAMMING", "upper=XYZ"},
   gen_b5, 0},
 {"e1", "e1.c", 6, 3,
   {"ab12!", "abcdef", "12345", "!!!", "a1!", "aB1!"},
   {"letters=2 digits=2 others=1", "letters=6 digits=0 others=0", "letters=0 digits=5 others=0", "letters=0 digits=0 others=3", "letters=1 digits=1 others=1", "letters=2 digits=1 others=1"},
   gen_e1, 0},
 {"e2", "e2.c", 4, 3,
   {"abcd", "level", "a", "abcde"},
   {"reversed=dcba swaps=2", "reversed=level swaps=2", "reversed=a swaps=0", "reversed=edcba swaps=2"},
   gen_e2, 0},
 {"e3", "e3.c", 5, 3,
   {"aaabbbb", "abcde", "aa", "aabbaaa", "z"},
   {"longest=4 char=b", "longest=1 char=a", "longest=2 char=a", "longest=3 char=a", "longest=1 char=z"},
   gen_e3, 0},
 {"e4", "e4.c", 4, 3,
   {"abc 2", "xyz 3", "hello 0", "abc 25"},
   {"shifted=cde", "shifted=abc", "shifted=hello", "shifted=zab"},
   gen_e4, 0},
};

int main(int argc, char **argv) {
    /* ./grader --count e1   prints how many vectors e1 has, and exits.
       check-ta.sh uses this so partial credit never has to guess a total. */
    if (argc == 3 && strcmp(argv[1], "--count") == 0) {
        for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
            if (strcmp(P[i].name, argv[2]) == 0) { printf("%d\n", P[i].npub + P[i].nrand); return 0; }
        return 2;
    }
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e5   |   ./grader --count PROB\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public", p->full);
    for (int i = 0; i < p->nrand; i++) {
        char in[512], exp[4096];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random", p->full);
    }
    return failed;
}
