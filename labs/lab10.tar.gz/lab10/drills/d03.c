/* d03: Two pointers, one allocation. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) { int *p = malloc(sizeof *p); if (!p) return 1;
*p = 7; int *q = p; *q = 9; printf("%d %d\n", *p, *q); free(p); return 0; }
