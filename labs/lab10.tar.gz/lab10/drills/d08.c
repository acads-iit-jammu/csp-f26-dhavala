/* d08: Each invocation has its own local. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void show(int n) { int saved = n * 10; if (n > 0) show(n - 1); printf("%d ", saved); }
int main(void) { show(2); puts(""); return 0; }
