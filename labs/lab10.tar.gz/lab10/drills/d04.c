/* d04: A successful resize. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) { int *p = malloc(2 * sizeof *p); if (!p) return 1;
p[0] = 7; p[1] = 2; int *tmp = realloc(p, 4 * sizeof *p);
if (!tmp) { free(p); return 1; } p = tmp; p[2] = 5; p[3] = 8;
printf("%d %d %d %d\n", p[0], p[1], p[2], p[3]); free(p); return 0; }
