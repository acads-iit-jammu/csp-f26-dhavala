/* d07: Factorial including zero. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int fact(int n) { if (n == 0) return 1; return n * fact(n - 1); }
int main(void) { printf("%d %d\n", fact(0), fact(3)); return 0; }
