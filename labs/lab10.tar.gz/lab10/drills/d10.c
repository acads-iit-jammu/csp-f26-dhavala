/* d10: Repeated Fibonacci calls. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int calls = 0;
int fib(int n) { calls++; if (n <= 1) return n;
int left = fib(n - 1); int right = fib(n - 2); return left + right; }
int main(void) { int result = fib(4); printf("value=%d calls=%d\n", result, calls); return 0; }
