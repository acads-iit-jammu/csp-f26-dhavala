/* d06: Before and after the recursive call. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void visit(int n) { if (n == 0) return;
printf("enter%d ", n); visit(n - 1); printf("leave%d ", n); }
int main(void) { visit(2); puts(""); return 0; }
