/* d09: Maximum of a shorter prefix. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int largest(const int a[], int n) { if (n == 1) return a[0];
int maxOfPrefix = largest(a, n - 1);
if (a[n - 1] > maxOfPrefix) return a[n - 1];
return maxOfPrefix; }
int main(void) { int a[] = {-4, -2, -9}; printf("%d\n", largest(a, 3)); return 0; }
