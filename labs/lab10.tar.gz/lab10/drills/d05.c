/* d05: A simulated failed resize. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* This helper deliberately returns NULL, leaving p allocated. */
int *simulate_failed_resize(int *p) { (void)p; return NULL; }
int main(void) { int *p = malloc(sizeof *p); if (!p) return 1;
*p = 7; int *tmp = simulate_failed_resize(p);
if (tmp == NULL) { printf("kept=%d\n", *p); free(p); return 0; }
free(tmp); return 0; }
