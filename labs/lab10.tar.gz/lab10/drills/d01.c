/* d01: Allocate then write. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) { int *p = malloc(3 * sizeof *p); if (!p) return 1;
for (int i = 0; i < 3; i++) p[i] = 2 * i + 1;
printf("%d %d\n", p[0], *(p + 2)); free(p); return 0; }
