/* d02: Zeroed integer storage. Predict before running. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) { int *p = calloc(3, sizeof *p); if (!p) return 1;
p[1] = 8; printf("%d %d %d\n", p[0], p[1], p[2]); free(p); return 0; }
