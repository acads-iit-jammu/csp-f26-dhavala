#!/usr/bin/env bash
# Lab 10 self-check. Run inside your workspace.
#   ./check.sh          everything (write drills w01-w08, blanks b1-b4, checked e1-e4)
#   ./check.sh e2       just one problem
#   ./check.sh --bundle check everything, then bundle regardless
set -u
QUIET=0; BUNDLE=0; ONLY=""
for a in "$@"; do case "$a" in
  --quiet) QUIET=1;; --bundle) BUNDLE=1;;
  w01|w02|w03|w04|w05|w06|w07|w08|b1|b2|b3|b4|e1|e2|e3|e4) ONLY="$a";;
  *) echo "usage: ./check.sh [w01..w08|b1..b4|e1..e4] [--bundle]"; exit 2;;
esac; done

# ---- the anti-litter guard: are we even in a workspace? ----
if [ ! -f TEAM.txt ]; then
  echo "STOP: this is not your workspace (no TEAM.txt here)."
  echo "Run:  ./where.sh    — it will tell you exactly what to type."
  exit 2
fi
echo "workspace: $(pwd)"

pass=0; fail=0; vfail=0
ok(){ pass=$((pass+1)); [ "$QUIET" = 1 ] || printf 'PASS  %s\n' "$1"; }
no(){ fail=$((fail+1)); [ "$QUIET" = 1 ] || printf 'FAIL  %s\n' "$1"; }

if [ -z "$ONLY" ]; then
  # workspace items
  if [ -s TEAM.txt ] && grep -q '^rolls: [A-Za-z0-9]' TEAM.txt; then ok "TEAM.txt names your team"; else no "TEAM.txt with your roll number(s)"; fi
  if [ -f session.txt ] && [ "$(wc -c < session.txt)" -gt 200 ]; then ok "session.txt recorded (script ran)"; else no "a session.txt of real size (start 'script session.txt' FIRST)"; fi
  # drills
  nd=$(awk '{print $2}' notes/drills.log 2>/dev/null | sort -u | wc -l | tr -d ' ')
  nh=$(awk '$3=="HIT"{print $2}' notes/drills.log 2>/dev/null | sort -u | wc -l | tr -d ' ')
  echo "note  drills attempted: $nd/10 (predicted right: $nh) — not marked, but read your log"
fi

# ---- grader engine ----
# Rebuild the distributed engine for local checking; TA grading uses its own copy.
if ! gcc -std=c11 grader.c -o grader; then
  echo "grader: build failed"; exit 2
fi
if [ ! -x grader ]; then
  no "the grader engine (re-run install.sh, or: gcc grader.c -o grader)"
else
  PROBS="${ONLY:-w01 w02 w03 w04 w05 w06 w07 w08 b1 b2 b3 b4 e1 e2 e3 e4}"
  marks=0; outof=0; table=""
  for p in $PROBS; do
    case "$p" in w*) tag="drill  "; pts=1;; b*) tag="blank  "; pts=6;; *) tag="CHECKED"; pts=12;; esac
    echo "--- $p ($tag) --------------------------"
    of="$(./grader --count "$p" 2>/dev/null)"; of="${of:-0}"
    gout="$(./grader "$p" 2>&1)"; f=$?
    printf '%s\n' "$gout"
    vfail=$((vfail+f))
    # Derive the passes from the grader's EXIT CODE, which is the number of
    # failed vectors. Do NOT grep its output for "PASS": the WRONG diagnostic
    # echoes the student's own text back, so a program printing "PASS" could
    # inflate its own mark to full.
    case "$gout" in
      *MISSING*|*COMPILE-FAIL*) vpass=0 ;;
      *) vpass=$(( of - f ))
         if [ "$vpass" -lt 0 ]; then vpass=0; fi ;;
    esac
    got=0; [ "$of" -gt 0 ] && got=$(( (pts * vpass + of/2) / of ))
    marks=$(( marks + got )); outof=$(( outof + pts ))
    table="$table$(printf '\n    %-3s %d/%d vectors   %2d of %2d marks' "$p" "$vpass" "$of" "$got" "$pts")"
    if [ "$f" -eq 0 ]; then ok "$p: all vectors pass"; else no "$p: $f vector(s) failing"; fi
  done
fi

echo "----------------------------------------"
echo "check: $pass passed, $fail failed (vector failures: $vfail)"
if [ -n "${table:-}" ]; then
  echo
  echo "  YOUR MARKS SO FAR   (write drills 1 each, blanks 6 each, checked 12 each)"
  printf '%s\n' "$table"
  echo "    ---------------------------------------------"
  printf '    %-3s               %2d of %2d marks\n' "" "${marks:-0}" "${outof:-0}"
  echo
  echo "  Marks are PARTIAL: every vector you pass earns its share, so fixing"
  echo "  one failing case is always worth doing. The PREDICT drills (./drill.sh)"
  echo "  are not marked; the WRITE drills w01-w08 are."
  echo "  This is an ESTIMATE — the random vectors are drawn fresh each run,"
  echo "  so the number can move by a mark or two between checks."
fi

if [ "$BUNDLE" = 1 ]; then
  [ "$fail" -gt 0 ] && echo "bundle: WARNING — bundling with $fail FAIL(s); submitted as-is (the verdicts travel with it)"
  rolls="$(sed -n 's/^rolls: //p' TEAM.txt | tr ' ' '_')"
  branch="$(sed -n 's/^branch: //p' TEAM.txt)"
  week="$(sed -n 's/^week: //p' TEAM.txt)"
  lab="$(sed -n 's/^lab: //p' TEAM.txt)"
  name="lab$(printf '%02d' "${lab:-10}")_${rolls}_${branch}_w$(printf '%02d' "${week:-0}").tar.gz"
  ws="$(basename "$PWD")"
  ( cd .. && tar czf "$name" "$ws" ) && echo "bundle: ../$name — carry it out (Moodle / email yourself). The machine forgets; you must not."
fi

exit "$fail"
