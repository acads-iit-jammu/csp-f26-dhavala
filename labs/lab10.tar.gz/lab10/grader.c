/* Lab 10: trusted engine, whole-output checks, four public + eight fresh random cases.
 * Exit status is failed vectors, never inferred from student-controlled output.
 * POSIX runtime: Linux/macOS. Does not execute submitted scripts or graders.
 * This is a teaching checker, not an isolation boundary for hostile native code.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <fcntl.h>
#define CASES 12
static const char *names[] = {"w01","w02","w03","w04","w05","w06","w07","w08","b1","b2","b3","b4","e1","e2","e3","e4"};
static const char *pub_in[16][4] = {
{"3 7\n","1 -100\n","20 100\n","2 0\n"},
{"0 9\n","1 7\n","1 -1\n","0 -100\n"},
{"4 -2\n","1 100\n","20 -100\n","3 0\n"},
{"7\n","-100\n","0\n","100\n"},
{"5\n","0\n","1\n","12\n"},
{"4\n","0\n","1\n","20\n"},
{"4 -4 -2 -9 -1\n","1 -100\n","4 9 9 8 7\n","3 -5 0 -1\n"},
{"6\n","0\n","1\n","10\n"},
{"lab\n","a\n","AbBa\n","ABCDEFGHIJKLMNOPQRSTUVWXYZabcd\n"},
{"2 4 5 7 2\n","1 2 -100 9\n","3 5 0 -4 -2 -9\n","10 20 100 0 1 2 3 4 5 6 7 8 9\n"},
{"2040\n","0\n","9\n","999999\n"},
{"5 2 2 1 2 3 2\n","0 0\n","3 -1 -1 -1 -1\n","4 5 1 2 3 4\n"},
{"5 3 1 3 5 2 3\n","3 10 1 2 3\n","1 -100 -100\n","4 -2 -2 -1 -2 9\n"},
{"2 2 11 7 22 9 33 9 44 2\n","1 1 1 -10 2 -3\n","2 1 10 9 20 2 30 1\n","1 2 3 0 4 0 5 0\n"},
{"level\n","x\n","abca\n","Abba\n"},
{"6 2 1 2 4 2 2 1 2\n","0 0 0\n","3 5 3 5 5 5\n","4 -1 0 0 1 2 -1\n"}
};
static const char *pub_out[16][4] = {
{"first=7 last=7\n","first=-100 last=-100\n","first=100 last=100\n","first=0 last=0\n"},
{"result=-1\n","result=7\n","result=-1\n","result=-1\n"},
{"values: -2 -1 0 1\n","values: 100\n","values: -100 -99 -98 -97 -96 -95 -94 -93 -92 -91 -90 -89 -88 -87 -86 -85 -84 -83 -82 -81\n","values: 0 1 2\n"},
{"value=7\nreset=1\n","value=-100\nreset=1\n","value=0\nreset=1\n","value=100\nreset=1\n"},
{"factorial=120\n","factorial=1\n","factorial=1\n","factorial=479001600\n"},
{"sum=10\n","sum=0\n","sum=1\n","sum=210\n"},
{"maximum=-1\n","maximum=-100\n","maximum=9\n","maximum=0\n"},
{"fib=8\n","fib=0\n","fib=1\n","fib=55\n"},
{"source=#ab copy=lab\n","source=# copy=a\n","source=#bBa copy=AbBa\n","source=#BCDEFGHIJKLMNOPQRSTUVWXYZabcd copy=ABCDEFGHIJKLMNOPQRSTUVWXYZabcd\n"},
{"values: 7 2 5 5\n","values: 9 -100\n","values: -4 -2 -9 0 0\n","values: 0 1 2 3 4 5 6 7 8 9 100 100 100 100 100 100 100 100 100 100\n"},
{"digit-sum=6\n","digit-sum=0\n","digit-sum=9\n","digit-sum=54\n"},
{"count=3\n","count=0\n","count=3\n","count=0\n"},
{"count=3 values: 3 5 3\n","count=0 values:\n","count=1 values: -100\n","count=4 values: -2 -1 -2 9\n"},
{"records: 11:7 22:9 33:9 44:2\nbest=22 value=9\n","records: 1:-10 2:-3\nbest=2 value=-3\n","records: 10:9 20:2 30:1\nbest=10 value=9\n","records: 3:0 4:0 5:0\nbest=3 value=0\n"},
{"palindrome=1\n","palindrome=1\n","palindrome=0\n","palindrome=0\n"},
{"index=2\n","index=-1\n","index=-1\n","index=3\n"}
};
static int rnd(int lo, int hi) { return lo + rand() % (hi - lo + 1); }
/* Independent, iterative output oracle; recursion is assessed in the viva too. */
static void generate(int p, char *in, char *out) {
    int n, m, t, start, a[40], ids[40], len = 0, ol = 0;
    if (p == 8 || p == 14) {
        n = rnd(1,30); char word[31];
        for (int i=0;i<n;i++) word[i] = "abcABC"[rnd(0,5)];
        if (p==14 && rnd(0,1)) for(int i=0;i<n/2;i++) word[n-1-i]=word[i];
        word[n]=0; sprintf(in,"%s\n",word);
        if (p==8) sprintf(out,"source=#%s copy=%s\n",word+1,word);
        else { int ok=1; for(int i=0;i<n/2;i++) if(word[i]!=word[n-1-i]) ok=0;
            sprintf(out,"palindrome=%d\n",ok); }
        return;
    }
    if (p==0 || p==1 || p==2) {
        n = p==1 ? rnd(0,1) : rnd(1,20); t=rnd(-100,100);
        sprintf(in,"%d %d\n",n,t);
        if(p==0) sprintf(out,"first=%d last=%d\n",t,t);
        if(p==1) sprintf(out,"result=%d\n",n?t:-1);
        if(p==2) { ol=sprintf(out,"values:"); for(int i=0;i<n;i++) ol+=sprintf(out+ol," %d",t+i); sprintf(out+ol,"\n"); }
        return;
    }
    if(p==3 || p==4 || p==5 || p==7 || p==10) {
        n = p==3 ? rnd(-100,100) : p==4 ? rnd(0,12) : p==5 ? rnd(0,20) : p==7 ? rnd(0,10) : rnd(0,999999);
        sprintf(in,"%d\n",n);
        if(p==3) sprintf(out,"value=%d\nreset=1\n",n);
        if(p==4) { unsigned long v=1; for(int i=1;i<=n;i++) v*=i; sprintf(out,"factorial=%lu\n",v); }
        if(p==5) sprintf(out,"sum=%d\n",n*(n+1)/2);
        if(p==7) { int x=0,y=1; for(int i=0;i<n;i++){int z=x+y;x=y;y=z;} sprintf(out,"fib=%d\n",x); }
        if(p==10){int v=0; for(int k=n;k;k/=10) v+=k%10; sprintf(out,"digit-sum=%d\n",v);}
        return;
    }
    if(p==13) {
        n=rnd(1,10);m=rnd(1,10);len=sprintf(in,"%d %d",n,m);ol=sprintf(out,"records:");int best=0;
        int offset=rnd(1,900);
        for(int i=0;i<n+m;i++) { ids[i]=offset+i; a[i]=rnd(-100,100);
            len+=sprintf(in+len," %d %d",ids[i],a[i]);ol+=sprintf(out+ol," %d:%d",ids[i],a[i]);
            if(a[i]>a[best]) best=i; }
        sprintf(in+len,"\n");sprintf(out+ol,"\nbest=%d value=%d\n",ids[best],a[best]);return;
    }
    n=(p==11||p==15)?rnd(0,20):p==9?rnd(1,10):rnd(1,20);
    t=(p==11||p==15)?rnd(-5,5):rnd(-100,100);start=rnd(0,n);m=rnd(n+1, p==9?20:21);
    if(p==6) len=sprintf(in,"%d",n);
    else if(p==9) len=sprintf(in,"%d %d %d",n,m,t);
    else if(p==15) len=sprintf(in,"%d %d %d",n,t,start);
    else len=sprintf(in,"%d %d",n,t);
    for(int i=0;i<n;i++) { a[i]=(p==11||p==15)?rnd(-5,5):rnd(-100,100);len+=sprintf(in+len," %d",a[i]); }
    sprintf(in+len,"\n");
    if(p==6){int best=a[0];for(int i=1;i<n;i++)if(a[i]>best)best=a[i];sprintf(out,"maximum=%d\n",best);}
    if(p==9){ol=sprintf(out,"values:");for(int i=0;i<m;i++)ol+=sprintf(out+ol," %d",i<n?a[i]:t);sprintf(out+ol,"\n");}
    if(p==11){int count=0;for(int i=0;i<n;i++)if(a[i]==t)count++;sprintf(out,"count=%d\n",count);}
    if(p==12){int count=0;for(int i=0;i<n;i++)if(a[i]>=t)count++;ol=sprintf(out,"count=%d values:",count);
        for(int i=0;i<n;i++) { if(a[i]>=t) ol+=sprintf(out+ol," %d",a[i]); }
        sprintf(out+ol,"\n");}
    if(p==15){int found=-1;for(int i=start;i<n;i++)if(a[i]==t){found=i;break;}sprintf(out,"index=%d\n",found);}
}
/* Normalize whitespace only; never accept extra prompts or prefixes. */
static void normalize(const char *src, char *dst) {
    int space=0, n=0;
    for(;*src;src++) {
        if(isspace((unsigned char)*src)) {space=1;continue;}
        if(space && n)dst[n++]=' ';
        dst[n++]=*src;space=0;
    }
    dst[n]=0;
}
static int launch(char *const args[], const char *input, const char *output, int seconds) {
    pid_t pid=fork();
    if(pid<0)return 125;
    if(pid==0){
        setpgid(0,0);
        int in=open(input,O_RDONLY),out=open(output,O_WRONLY|O_CREAT|O_TRUNC,0600);
        int err=open(".lab10.stderr",O_WRONLY|O_CREAT|O_TRUNC,0600);
        if(in<0||out<0||err<0)_exit(125);
        dup2(in,0);dup2(out,1);dup2(err,2);close(in);close(out);close(err);
        struct rlimit lim={65536,65536};setrlimit(RLIMIT_FSIZE,&lim);
        struct rlimit core={0,0};setrlimit(RLIMIT_CORE,&core);
        execvp(args[0],args);_exit(127);
    }
    setpgid(pid,pid);
    struct timespec tick={0,10000000};int status=0;
    for(int i=0;i<seconds*100;i++) {
        pid_t got=waitpid(pid,&status,WNOHANG);
        if(got==pid)return WIFEXITED(status)?WEXITSTATUS(status):128;
        nanosleep(&tick,NULL);
    }
    kill(-pid,SIGKILL);waitpid(pid,&status,0);return 124;
}
static void show_error(void){
    FILE *f=fopen(".lab10.stderr","r");if(!f)return;
    char line[512];for(int i=0;i<6 && fgets(line,sizeof line,f);i++)fputs(line,stdout);fclose(f);
}
int main(int argc,char **argv) {
    int count=argc==3 && strcmp(argv[1],"--count")==0;
    if(argc!=2&&!count){puts("usage: grader PROBLEM | grader --count PROBLEM");return 2;}
    int p=-1;for(int i=0;i<16;i++)if(strcmp(names[i],argv[count?2:1])==0)p=i;
    if(p<0)return 2;
    if(count){printf("%d\n",CASES);return 0;}
    srand((unsigned)time(NULL)^(unsigned)getpid());
    char src[32];snprintf(src,sizeof src,"%s.c",names[p]);
    if(access(src,R_OK)){printf("MISSING %s\n",src);return CASES;}
    char *compile[]={"gcc","-std=c11","-Wall","-Wextra","-Wpedantic",src,"-o",".lab10-program",NULL};
    if(launch(compile,"/dev/null",".lab10.compile",15)){printf("COMPILE-FAIL %s (complete the numbered TODO regions)\n",src);show_error();return CASES;}
    int failures=0;
    for(int c=0;c<CASES;c++){
        char in[4096],out[4096],actual[65537],wanted[65537],got[65537];
        if(c<4){strcpy(in,pub_in[p][c]);strcpy(out,pub_out[p][c]);}else generate(p,in,out);
        FILE *f=fopen(".lab10.input","w");if(!f)return CASES;fputs(in,f);fclose(f);
        char *run[]={"./.lab10-program",NULL};int rc=launch(run,".lab10.input",".lab10.output",3);
        f=fopen(".lab10.output","r");size_t len=f?fread(actual,1,sizeof actual-1,f):0;if(f)fclose(f);actual[len]=0;
        normalize(actual,got);normalize(out,wanted);
        int bad=rc!=0||strcmp(got,wanted)!=0;failures+=bad;
        printf("%s %s %d%s\n",bad?"FAIL":"PASS",c<4?"public":"random",c+1,rc==124?" TIMEOUT":"");
        if(bad){printf("  input: %s  expected: %s  got: %.250s\n  exit: %d\n",in,out,actual,rc);}
    }
    return failures;
}
