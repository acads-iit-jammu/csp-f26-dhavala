# Lab 10 — Dynamic Memory and Recursion

Common pack for EE, ME and MT. EE: Tue 27 October; ME/MT: Wed 28 October 2026.
Both sessions: 2–4 pm. Work in teams of one or two; swap the keyboard halfway.

Allocation and recursion each carry 50 of the 100 marks.

1. From the extracted lab10 directory, run ./install.sh. At home use
   ./install.sh --branch ee (or me / mt).
2. Work only in the workspace shown by the installer, with a [lab10 OK] prompt.
   ./where.sh helps you recover your workspace. Reinstalling preserves edited files.
   Earlier workspaces are retained.
3. Start: script session.txt
4. Read and predict: ./drill.sh --all (10 drills, unmarked).
5. Edit w01.c..w08.c, b1.c..b4.c, e1.c..e4.c.
   Each numbered TODO is a region, not a required number of lines. Remove its
   #error directive when you complete that region. Unfinished files deliberately
   report COMPILE-FAIL. Keep the supplied function signatures and drivers.
6. For example:
      gcc -std=c11 -Wall -Wextra -Wpedantic b1.c -o b1
      ./b1 < b1_sample.txt
      cat b1_expected.txt
      ./check.sh b1
7. Run ./check.sh for all problems. Public and fresh random checks award partial
   credit. Complete stdout is checked, ignoring whitespace differences; extra
   prompts or debug messages fail. A program must also exit successfully.
8. After recording your work, type exit to stop script's recording shell, then:
      ./check.sh --bundle
   The submission is written ABOVE your workspace as lab10_<rolls>_<branch>_w13.tar.gz.
   Partial work can be bundled. Upload it as directed by the instructor and keep
   a copy outside the lab machine. session.txt is required as the audit trail.

Scoring: write drills 8 x 1 = 8; FIBs 4 x 6 = 24; exercises 4 x 12 = 48.
Viva/source review: 10 allocation + 10 recursion. Output tests cannot establish
correct ownership or recursive implementation on their own. Each topic has
40 program marks + 10 viva marks. Per-problem program marks are rounded to the
nearest whole mark (half rounds up); the total is an estimate because of random
cases. Never memorise the sample output.

All inputs satisfy the GIVEN in each starter. No invalid-input parser is required.
All normal automated vectors assume allocation succeeds. Still implement each
specified allocation-failure path; staff can force failures and inspect cleanup.
Use malloc/realloc where required. Recursion functions must use recursion, not
loops. Supplied input/output loops are permitted. Alternative correct implementations
inside TODO regions are welcome; fixed line counts are not a requirement.

PUBLIC-CASES.txt lists all four public cases for each problem. Each problem also
has its own sample input and expected-output file. C library functions used here
are declared by stdio.h, stdlib.h and string.h, already supplied in starters.

Reference: W13 lecture notes and the memory/recursion explorers on the course site.
Adapted teaching approach following Prof. Shweta Agrawal's CS1100 lectures,
IIT Madras, used with permission. The exercises and test harness are course-specific.
