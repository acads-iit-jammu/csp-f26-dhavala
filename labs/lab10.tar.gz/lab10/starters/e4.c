/* Lab 10 | EE / ME / MT | e4: Recursive first occurrence
TOPIC: recursion
BEFORE: b4
GIVEN: n in 0..20, target in -5..5, start in 0..n; then n ints in -5..5. Input: n target start values.
TASK: Write first_index: return the smallest index i with start<=i<n and a[i]==target, or -1 if absent. Indices are zero-based. Use recursion, not loops; stop before accessing a[n]. Do not change a.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int first_index(const int a[], int n, int target, int start) {
/* TODO 1: Write the complete recursive search, including absence and return propagation. */
#error Complete TODO_1
}
int main(void) {
    int n, target, start, a[20] = {0};
    if (scanf("%d %d %d", &n, &target, &start) != 3) return 1;
    for (int i = 0; i < n; i++) if (scanf("%d", &a[i]) != 1) return 1;
    printf("index=%d\n", first_index(a, n, target, start));
    return 0;
}
