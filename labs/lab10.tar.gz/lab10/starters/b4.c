/* Lab 10 | EE / ME / MT | b4: Count matches recursively
TOPIC: recursion
BEFORE: w06 w07
GIVEN: n in 0..20, target in -5..5; then n ints in -5..5. Input: n target values.
TASK: Return the number of target occurrences among the first n elements. Use recursion, not loops.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int count_matches(const int a[], int n, int target) {
    /* TODO 1: Handle the empty prefix before accessing an element. */
#error Complete TODO_1
    /* TODO 2: Collect the count from the shorter prefix. */
#error Complete TODO_2
    /* TODO 3: Account for the last element and return the count. */
#error Complete TODO_3
}
int main(void) {
    int n, target, a[20] = {0};
    if (scanf("%d %d", &n, &target) != 2) return 1;
    for (int i = 0; i < n; i++) if (scanf("%d", &a[i]) != 1) return 1;
    printf("count=%d\n", count_matches(a, n, target));
    return 0;
}
