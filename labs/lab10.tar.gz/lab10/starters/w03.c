/* Lab 10 | EE / ME / MT | w03: Initialise allocated elements
TOPIC: allocation
BEFORE: d01 d02 w01
GIVEN: n in 1..20; start in -100..100. Input: n start.
TASK: Set p[i] to start + i for every valid index.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    int n, start;
    if (scanf("%d %d", &n, &start) != 2) return 1;
    int *p = malloc(n * sizeof *p);
    if (p == NULL) { puts("allocation-failed"); return 1; }
    /* TODO 1: Initialise all n elements as specified. */
#error Complete TODO_1
    printf("values:");
    for (int i = 0; i < n; i++) printf(" %d", p[i]);
    puts("");
    free(p);
    return 0;
}
