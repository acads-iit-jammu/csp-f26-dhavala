/* Lab 10 | EE / ME / MT | w01: Allocate an integer array
TOPIC: allocation
BEFORE: d01
GIVEN: n in 1..20; value in -100..100. Input: n value.
TASK: Allocate n ints using malloc and sizeof *p.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    int n, value;
    if (scanf("%d %d", &n, &value) != 2) return 1;
    /* TODO 1: Declare p and allocate n int elements. */
#error Complete TODO_1
    if (p == NULL) { puts("allocation-failed"); return 1; }
    for (int i = 0; i < n; i++) p[i] = value;
    printf("first=%d last=%d\n", p[0], p[n - 1]);
    free(p);
    return 0;
}
