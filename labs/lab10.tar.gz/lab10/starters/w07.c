/* Lab 10 | EE / ME / MT | w07: Capture the recursive result
TOPIC: recursion
BEFORE: d09
GIVEN: n in 1..20, then n integers in -100..100.
TASK: Find the maximum recursively. maxOfPrefix must hold the maximum of the first n-1 elements.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int largest(const int a[], int n) {
    if (n == 1) return a[0];
    /* TODO 1: Declare maxOfPrefix and collect the recursive result for the prefix. */
#error Complete TODO_1
    if (a[n - 1] > maxOfPrefix) return a[n - 1];
    return maxOfPrefix;
}
int main(void) {
    int n, a[20];
    if (scanf("%d", &n) != 1) return 1;
    for (int i = 0; i < n; i++) if (scanf("%d", &a[i]) != 1) return 1;
    printf("maximum=%d\n", largest(a, n));
    return 0;
}
