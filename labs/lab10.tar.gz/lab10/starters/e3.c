/* Lab 10 | EE / ME / MT | e3: Recursive palindrome
TOPIC: recursion
BEFORE: b3 b4
GIVEN: One word, 1..30 ASCII letters. Comparison is case-sensitive. Input: word.
TASK: Write palindrome(s,left,right) for the inclusive range. Return 1 for a palindrome, otherwise 0. A range with left>=right is a palindrome. Compare ends and recurse inward; no loops, reversal library or string copy inside this function. Do not change s.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int palindrome(const char s[], int left, int right) {
/* TODO 1: Write the complete recursive function, including stopping and mismatch cases. */
#error Complete TODO_1
}
int main(void) {
    char word[31];
    if (scanf("%30s", word) != 1) return 1;
    printf("palindrome=%d\n", palindrome(word, 0, (int)strlen(word) - 1));
    return 0;
}
