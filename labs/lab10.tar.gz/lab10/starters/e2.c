/* Lab 10 | EE / ME / MT | e2: Append records and find the best
TOPIC: allocation
BEFORE: b2 w04
GIVEN: n and m in 1..10; then n first-batch records and m second-batch records, each id value. IDs are unique integers in 1..1000; values in -100..100. Input: n m records.
TASK: Write join_readings and best_index. join_readings must malloc space for the first batch, copy it, realloc for both batches, and append the second batch in order. Return NULL on either failure and release anything allocated inside the function. Do not change inputs. Caller frees successful result. best_index returns the zero-based index of the largest value; ties keep the earliest record.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Reading { int id; int value; };
struct Reading *join_readings(const struct Reading first[], int n,
                             const struct Reading second[], int m) {
/* TODO 1: Implement the complete allocation, copy, resize and append function. */
#error Complete TODO_1
}
int best_index(const struct Reading a[], int n) {
/* TODO 2: Return the best index, keeping the earliest record on a tie. */
#error Complete TODO_2
}
int main(void) {
    int n, m;
    struct Reading first[10], second[10];
    if (scanf("%d %d", &n, &m) != 2) return 1;
    for (int i = 0; i < n; i++)
        if (scanf("%d %d", &first[i].id, &first[i].value) != 2) return 1;
    for (int i = 0; i < m; i++)
        if (scanf("%d %d", &second[i].id, &second[i].value) != 2) return 1;
    struct Reading *all = join_readings(first, n, second, m);
    if (all == NULL) { puts("allocation-failed"); return 1; }
    printf("records:");
    for (int i = 0; i < n + m; i++) printf(" %d:%d", all[i].id, all[i].value);
    int best = best_index(all, n + m);
    printf("\nbest=%d value=%d\n", all[best].id, all[best].value);
    free(all);
    return 0;
}
