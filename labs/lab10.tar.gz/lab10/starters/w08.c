/* Lab 10 | EE / ME / MT | w08: Combine two returned answers
TOPIC: recursion
BEFORE: d10
GIVEN: n in 0..10. Input: n.
TASK: F(0)=0, F(1)=1; combine the two returned Fibonacci values.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int fib(int n) {
    if (n <= 1) return n;
    int left = fib(n - 1);
    int right = fib(n - 2);
    /* TODO 1: Combine and return the two results. */
#error Complete TODO_1
}
int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 1;
    printf("fib=%d\n", fib(n));
    return 0;
}
