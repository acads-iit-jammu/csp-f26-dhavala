/* Lab 10 | EE / ME / MT | b2: Resize without losing ownership
TOPIC: allocation
BEFORE: d04 w01 w02 w03 w04
GIVEN: old_n in 1..10, new_n in old_n+1..20, fill in -100..100; then old_n ints in -100..100. Input: old_n new_n fill values.
TASK: grow returns the resized array with preserved old values and added elements equal to fill. On failure return NULL and leave the original allocation valid; the caller frees it. Use realloc.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *grow(int *p, int old_n, int new_n, int fill) {
    /* TODO 1: Attempt the resize with a temporary pointer and handle failure. */
#error Complete TODO_1
    /* TODO 2: Initialise only the newly added elements. */
#error Complete TODO_2
    return tmp;
}
int main(void) {
    int old_n, new_n, fill;
    if (scanf("%d %d %d", &old_n, &new_n, &fill) != 3) return 1;
    int *p = malloc(old_n * sizeof *p);
    if (p == NULL) { puts("allocation-failed"); return 1; }
    for (int i = 0; i < old_n; i++) {
        if (scanf("%d", &p[i]) != 1) { free(p); return 1; }
    }
    int *resized = grow(p, old_n, new_n, fill);
    if (resized == NULL) { free(p); puts("allocation-failed"); return 1; }
    p = resized;
    printf("values:");
    for (int i = 0; i < new_n; i++) printf(" %d", p[i]);
    puts("");
    free(p);
    return 0;
}
