/* Lab 10 | EE / ME / MT | b3: Recursive digit sum
TOPIC: recursion
BEFORE: w05 w06
GIVEN: n in 0..999999. Input: n.
TASK: Return the sum of decimal digits recursively, including n=0. Use recursion, not loops.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int digit_sum(int n) {
    /* TODO 1: Handle a one-digit number, including zero. */
#error Complete TODO_1
    /* TODO 2: Collect the recursive answer after removing the last digit. */
#error Complete TODO_2
    /* TODO 3: Combine the last digit and the recursive result. */
#error Complete TODO_3
}
int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 1;
    printf("digit-sum=%d\n", digit_sum(n));
    return 0;
}
