/* Lab 10 | EE / ME / MT | w04: Release and reset
TOPIC: allocation
BEFORE: d03 d05
GIVEN: value in -100..100. Input: value.
TASK: Release the allocation once, then set p to NULL.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    int value;
    if (scanf("%d", &value) != 1) return 1;
    int *p = malloc(sizeof *p);
    if (p == NULL) { puts("allocation-failed"); return 1; }
    *p = value;
    printf("value=%d\n", *p);
    /* TODO 1: Release the storage and reset its owning pointer. */
#error Complete TODO_1
    printf("reset=%d\n", p == NULL);
    return 0;
}
