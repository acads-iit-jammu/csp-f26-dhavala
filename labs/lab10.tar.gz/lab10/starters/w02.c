/* Lab 10 | EE / ME / MT | w02: Check the pointer
TOPIC: allocation
BEFORE: d05
GIVEN: flag is 0 or 1; value in -100..100. Input: flag value.
TASK: Return -1 if p is NULL; otherwise return *p. The driver simulates the two possible pointer states without trying to exhaust memory.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int read_or_error(const int *p) {
    /* TODO 1: Handle a NULL pointer before the supplied dereference. */
#error Complete TODO_1
    return *p;
}
int main(void) {
    int flag, value;
    if (scanf("%d %d", &flag, &value) != 2) return 1;
    const int *p = NULL;
    if (flag == 1) p = &value;
    printf("result=%d\n", read_or_error(p));
    return 0;
}
