/* Lab 10 | EE / ME / MT | w06: Progress towards the base case
TOPIC: recursion
BEFORE: d06
GIVEN: n in 0..20. Input: n.
TASK: Return 1 + ... + n recursively; sum_to(0) is 0.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int sum_to(int n) {
    if (n == 0) return 0;
    /* TODO 1: Combine n with the answer for a smaller argument; use recursion. */
#error Complete TODO_1
}
int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 1;
    printf("sum=%d\n", sum_to(n));
    return 0;
}
