/* Lab 10 | EE / ME / MT | b1: An independent string copy
TOPIC: allocation
BEFORE: w01 w02 d03
GIVEN: One word, 1..30 ASCII letters. Input: word.
TASK: Complete copy_word: return independently allocated, terminated storage containing source; return NULL on failure. strcpy is allowed. Driver changes source after copying.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *copy_word(const char *source) {
    /* TODO 1: Allocate enough space, including the terminator; handle failure. */
#error Complete TODO_1
    /* TODO 2: Copy all characters and the terminator into the new allocation. */
#error Complete TODO_2
    return copy;
}
int main(void) {
    char source[31];
    if (scanf("%30s", source) != 1) return 1;
    char *copy = copy_word(source);
    if (copy == NULL) { puts("allocation-failed"); return 1; }
    source[0] = '#';
    printf("source=%s copy=%s\n", source, copy);
    free(copy);
    return 0;
}
