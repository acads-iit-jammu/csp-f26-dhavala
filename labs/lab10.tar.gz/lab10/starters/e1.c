/* Lab 10 | EE / ME / MT | e1: Filter readings into a new array
TOPIC: allocation
BEFORE: w01 w02 w03 w04 b1
GIVEN: n in 1..20, threshold in -100..100; then n ints in -100..100. Input: n threshold values.
TASK: Write filter. Retain values >= threshold in original order, without changing a. Return a separately allocated array and write its count through out_count. For no matches return NULL and set count=0. On allocation failure return NULL and set count=-1. Caller owns and frees the result. No static result array.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *filter(const int a[], int n, int threshold, int *out_count) {
/* TODO 1: Implement the complete filter function, including allocation, count reporting and failure handling. */
#error Complete TODO_1
}
int main(void) {
    int n, threshold, a[20];
    if (scanf("%d %d", &n, &threshold) != 2) return 1;
    for (int i = 0; i < n; i++) if (scanf("%d", &a[i]) != 1) return 1;
    int count;
    int *result = filter(a, n, threshold, &count);
    if (count == -1) { puts("allocation-failed"); return 1; }
    printf("count=%d values:", count);
    for (int i = 0; i < count; i++) printf(" %d", result[i]);
    puts("");
    free(result);
    return 0;
}
