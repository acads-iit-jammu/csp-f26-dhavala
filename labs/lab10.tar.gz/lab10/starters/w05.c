/* Lab 10 | EE / ME / MT | w05: Factorial base case
TOPIC: recursion
BEFORE: d07
GIVEN: n in 0..12. Input: n.
TASK: Complete the base case, including 0!.
Edit only numbered TODO regions; each may contain several statements.
Keep the supplied function signatures and driver/output contract.
Use i++ in loops. Do not add prompts. Inputs satisfy GIVEN.
Allocation failure: supplied drivers print allocation-failed and return 1.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned long factorial(int n) {
    /* TODO 1: Return the factorial base value when n is zero. */
#error Complete TODO_1
    return (unsigned long)n * factorial(n - 1);
}
int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 1;
    printf("factorial=%lu\n", factorial(n));
    return 0;
}
