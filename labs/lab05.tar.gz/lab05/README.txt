Lab 05 — Decisions
==================

Everything happens INSIDE your workspace. If your prompt does not say
[lab05 OK ...], you are not in it — run ./where.sh.

  1.  ./install.sh          creates the workspace and puts you in it
  2.  script session.txt    start the recorder
  3.  ./drill.sh --all      10 drills — PREDICT first, then run
                            d01-d02   if, and the two classic if-bugs
                            d03-d04   switch: fall-through, and %2 on negatives
                            d05-d07   break and continue, and where they land
                            d08-d10   short circuit, ladder order, no match
  4.  fill the blanks:  b1_sign.c   b2_days.c   b3_bill.c
                        b4_grade.c  b5_convert.c
  5.  the checked three: e1.c (triangle)  e2.c (coprime)  e3.c (first multiple of 7)
  6.  ./check.sh            self-check      ./check.sh e2   just one
  7.  ./check.sh --bundle   bundle it, carry it out

One drill loops forever on purpose. Every drill run is capped at 5 seconds,
so it cannot hang the machine — but read the WARNING in that drill first,
and predict before you run it.

The starters do not compile as shipped. That is deliberate: each blank is a
name the compiler will not recognise, so it names the line waiting for you.
