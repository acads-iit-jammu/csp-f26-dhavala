/* Lab 03 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e5          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 6      /* headroom: a problem may need extra public vectors to pin its own trap */
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) --- */
static int days_in(int m){
    switch (m) { case 4: case 6: case 9: case 11: return 30;
                 case 2: return 28;
                 default: return 31; }
}
static int bill_for(int u){ return (u <= 100) ? u*3 : (u <= 300) ? u*5 : u*8; }
static int common_div(int a,int b){ int i; for (i=2; i<=a && i<=b; i++) if (a%i==0 && b%i==0) return i; return 0; }
static const char *tri(int a,int b,int c){
    if (a + b <= c || a + c <= b || b + c <= a) return "invalid";
    if (a == b && b == c) return "equilateral";
    if (a == b || b == c || a == c) return "isosceles";
    return "scalene";
}
static void gen_b1(char *in, char *exp) {                 /* sign of a number */
    int n = rand()%201 - 100;
    sprintf(in, "%d", n);
    sprintf(exp, "sign=%s", n > 0 ? "positive" : n < 0 ? "negative" : "zero");
}
static void gen_b2(char *in, char *exp) {                 /* days in a month */
    int m = rand()%12 + 1;
    sprintf(in, "%d", m);
    sprintf(exp, "days=%d", days_in(m));
}
static void gen_b3(char *in, char *exp) {                 /* electricity bill by slab */
    int u = rand()%501;
    sprintf(in, "%d", u);
    sprintf(exp, "bill=%d", bill_for(u));
}
static void gen_b4(char *in, char *exp) {                 /* grade from marks */
    int m = rand()%101;
    char g = (m >= 90) ? 'A' : (m >= 75) ? 'B' : (m >= 60) ? 'C' : (m >= 40) ? 'D' : 'F';
    sprintf(in, "%d", m);
    sprintf(exp, "grade=%c", g);
}
static void gen_b5(char *in, char *exp) {                 /* temperature converter */
    const char *codes = "cfk";
    char code = codes[rand()%3];
    int v = rand()%201 - 50;
    double r = (code=='c') ? v*9.0/5 + 32 : (code=='f') ? (v-32)*5.0/9 : v + 273.15;
    sprintf(in, "%d %c", v, code);
    sprintf(exp, "result=%.2f", r);
}
static void gen_e1(char *in, char *exp) {                 /* triangle */
    int a = rand()%12 + 1, b = rand()%12 + 1, c = rand()%12 + 1;
    if (rand()%3 == 0) b = a;
    if (rand()%5 == 0) { b = a; c = a; }
    sprintf(in, "%d %d %d", a, b, c);
    sprintf(exp, "type=%s", tri(a,b,c));
}
static void gen_e2(char *in, char *exp) {                 /* coprime / first common divisor */
    int a = rand()%98 + 2, b = rand()%98 + 2;
    /* Two thirds of the time, plant a shared factor so the pair has SEVERAL
       common divisors. Without this most pairs share at most one, and a
       program that forgets to break -- reporting the largest instead of the
       smallest -- would pass nearly every vector. */
    if (rand()%3) { int f = 2 + rand()%5; a = (a % (98/f) + 1) * f; b = (b % (98/f) + 1) * f; }
    int d = common_div(a,b);
    sprintf(in, "%d %d", a, b);
    if (d) sprintf(exp, "a=%d b=%d common=%d", a, b, d);
    else   sprintf(exp, "a=%d b=%d coprime", a, b);
}
static void gen_e3(char *in, char *exp) {                 /* first multiple of 7 in five numbers */
    int v[5], i, at = 0;
    char buf[128] = "";
    for (i = 0; i < 5; i++) {
        v[i] = rand()%90 + 1;
        if (rand()%4 == 0) v[i] = 7 * (rand()%13 + 1);     /* plant one often */
    }
    /* Half the time, plant TWO multiples of 7. Without this most vectors hold
       at most one, first-hit and last-hit coincide, and a program that forgets
       to break -- the whole point of e3 -- passes anyway. */
    if (rand()%2) { int a = rand()%4, b = a + 1 + rand()%(4-a);
                    v[a] = 7 * (rand()%13 + 1); v[b] = 7 * (rand()%13 + 1); }
    for (i = 0; i < 5; i++) { char t[16]; sprintf(t, "%s%d", i?" ":"", v[i]); strcat(buf, t); }
    for (i = 0; i < 5; i++) if (v[i] % 7 == 0) { at = i+1; break; }
    strcpy(in, buf);
    if (at) sprintf(exp, "found=%d at=%d", v[at-1], at);
    else    sprintf(exp, "none in 5");
}

static void gen_e4(char *in, char *exp) {                 /* continue + break */
    int v[8], i, sum = 0, added = 0, stop = 8;
    int zero_at = (rand()%3) ? (rand()%8) : -1;             /* plant a 0 two thirds of the time */
    for (i = 0; i < 8; i++) {
        v[i] = rand()%99 + 1;
        if (rand()%3 == 0) v[i] = 3 * (rand()%33 + 1);      /* and multiples of 3 often */
    }
    if (zero_at >= 0) v[zero_at] = 0;
    in[0] = 0;
    for (i = 0; i < 8; i++) { char t[16]; sprintf(t, "%s%d", i?" ":"", v[i]); strcat(in, t); }
    for (i = 0; i < 8; i++) {
        if (v[i] == 0) { stop = i; break; }
        if (v[i] % 3 != 0) continue;
        sum += v[i]; added++;
    }
    (void)stop;
    sprintf(exp, "sum=%d added=%d", sum, added);
}
static void gen_e5(char *in, char *exp) {                 /* break inside a switch inside a loop */
    int balance = rand()%9000 + 500, i, ops = 0, ncmd = rand()%5 + 2;   /* 2..6 before Q */
    char buf[256]; sprintf(buf, "%d", balance);
    for (i = 0; i < ncmd; i++) {
        int pick = rand()%3, amt = rand()%900 + 1; char t[32];
        if (pick == 0)      { sprintf(t, " D %d", amt); balance += amt; }
        else if (pick == 1) { sprintf(t, " W %d", amt); if (amt <= balance) balance -= amt; }
        else                { sprintf(t, " B"); }
        strcat(buf, t); ops++;
    }
    strcat(buf, " Q");
    /* the bait: commands AFTER Q, which a correct program never reaches */
    { char t[32]; sprintf(t, " D %d", rand()%900 + 1); strcat(buf, t); }
    strcpy(in, buf);
    sprintf(exp, "balance=%d ops=%d", balance, ops);
}

struct problem {
    const char *name;
    const char *src;
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
};
static struct problem P[] = {
 {"b1", "b1_sign.c",    3, 2, {"7","-4","0"},   {"sign=positive","sign=negative","sign=zero"}, gen_b1},
 {"b2", "b2_days.c",    3, 2, {"4","2","12"},   {"days=30","days=28","days=31"}, gen_b2},
 {"b3", "b3_bill.c",    3, 2, {"80","250","400"},{"bill=240","bill=1250","bill=3200"}, gen_b3},
 {"b4", "b4_grade.c",   2, 2, {"91","39"},      {"grade=A","grade=F"}, gen_b4},
 /* 37 c and 100 f are here on purpose: they are the two public vectors that do
    NOT divide evenly, so an integer-division formula fails on the publics alone
    rather than only when a random draw happens to catch it. */
 {"b5", "b5_convert.c", 5, 2, {"100 c","212 f","0 k","37 c","100 f"},
        {"result=212.00","result=100.00","result=273.15","result=98.60","result=37.78"}, gen_b5},
 {"e1", "e1.c",         3, 3, {"3 3 3","5 5 8","2 3 9"},
        {"type=equilateral","type=isosceles","type=invalid"}, gen_e1},
 {"e2", "e2.c",         3, 3, {"12 18","9 28","49 91"},
        {"a=12 b=18 common=2","a=9 b=28 coprime","a=49 b=91 common=7"}, gen_e2},
 {"e3", "e3.c",         4, 3, {"3 5 14 9 11","1 2 3 4 5","70 1 2 3 4","3 14 5 21 9"},
        {"found=14 at=3","none in 5","found=70 at=1","found=14 at=2"}, gen_e3},
 {"e4", "e4.c",         3, 3, {"4 9 7 12 0 6 3 5","3 6 9 12 15 18 21 24","1 2 4 5 7 8 10 11"},
        {"sum=21 added=2","sum=108 added=8","sum=0 added=0"}, gen_e4},
 {"e5", "e5.c",         3, 3, {"1000 D 500 W 200 B Q D 999","500 W 900 Q D 1","100 B B B Q W 50"},
        {"balance=1300 ops=3","balance=500 ops=1","balance=100 ops=3"}, gen_e5},
};

int main(int argc, char **argv) {
    /* ./grader --count e1   prints how many vectors e1 has, and exits.
       check-ta.sh uses this so partial credit never has to guess a total. */
    if (argc == 3 && strcmp(argv[1], "--count") == 0) {
        for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
            if (strcmp(P[i].name, argv[2]) == 0) { printf("%d\n", P[i].npub + P[i].nrand); return 0; }
        return 2;
    }
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e5   |   ./grader --count PROB\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src);
              return p->npub + p->nrand; }   /* a missing file fails every vector */
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        /* The exit code is a COUNT OF FAILED VECTORS, and callers do arithmetic
           on it. A program that will not compile fails every vector, not one. */
        return p->npub + p->nrand;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public");
    for (int i = 0; i < p->nrand; i++) {
        char in[128], exp[256];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random");
    }
    return failed;
}
