/* Lab 03 grader engine.
   Compiles a problem's source, feeds it inputs, and checks the FINAL
   non-empty output line against the contract. Public vectors are printed
   in the lab sheet; random vectors are drawn fresh from each problem's
   GIVEN on every run.
   Usage:  ./grader b1..b5 | e1..e3          exit code = failed vectors
   (Reading this source tells you the formulas — which the specs already
   state. What it cannot give you is tomorrow's random numbers.)          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAXPUB 3
static const char *timeout_prefix = "";   /* how we cap a runaway program (see main) */

static void last_line(const char *path, char *buf, int n) {
    FILE *f = fopen(path, "r"); buf[0] = 0;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        int L = (int)strlen(line);
        while (L > 0 && (line[L-1]=='\n' || line[L-1]=='\r' || line[L-1]==' ')) line[--L]=0;
        if (L > 0) { strncpy(buf, line, n-1); buf[n-1]=0; }
    }
    fclose(f);
}

static int run_one(const char *prog, const char *input, const char *expected, const char *label) {
    FILE *f = fopen(".gin", "w"); if (!f) { printf("  grader: cannot write .gin\n"); return 1; }
    fputs(input, f); fputc('\n', f); fclose(f);
    char cmd[512];
    /* the outer 2>/dev/null hides the shell's own "Alarm clock" job message */
    snprintf(cmd, sizeof cmd, "( %s./%s < .gin > .gout 2>&1 ) 2>/dev/null", timeout_prefix, prog);
    int rc = system(cmd);
    /* 124 = timeout(1), gtimeout, or our perl wrapper */
    if (rc != 0 && rc/256 == 124) {
        printf("  TIMEOUT  [%s] input: %s  (5s — an infinite loop, or a scanf still waiting?)\n", label, input);
        return 1;
    }
    char got[512]; last_line(".gout", got, sizeof got);
    size_t gl = strlen(got), el = strlen(expected);
    /* contract: the final line must END WITH the expected text
       (an unterminated prompt may legally share the line) */
    if (gl >= el && strcmp(got + gl - el, expected) == 0) {
        printf("  PASS     [%s] input: %s\n", label, input);
        return 0;
    }
    printf("  WRONG    [%s] input: %s\n           your final line: \"%s\"\n           expected exactly: \"%s\"\n",
           label, input, got, expected);
    return 1;
}

/* ---------------- reference formulas (the specs state these anyway) --- */
static int first_divisor(int n){ int i; for (i = 2; (long)i*i <= n; i++) if (n % i == 0) return i; return 0; }
static const char *tri(int a,int b,int c){
    if (a + b <= c || a + c <= b || b + c <= a) return "invalid";
    if (a == b && b == c) return "equilateral";
    if (a == b || b == c || a == c) return "isosceles";
    return "scalene";
}
static void gen_b1(char *in, char *exp) {                 /* even or odd */
    int n = rand()%201 - 100;
    sprintf(in, "%d", n);
    sprintf(exp, "%s", (n % 2 == 0) ? "even" : "odd");
}
static void gen_b2(char *in, char *exp) {                 /* vowel or consonant */
    const char *L = "abcdefghijklmnopqrstuvwxyz";
    char c = L[rand()%26];
    sprintf(in, "%c", c);
    sprintf(exp, "%s", strchr("aeiou", c) ? "vowel" : "consonant");
}
static void gen_b3(char *in, char *exp) {                 /* ticket price by age */
    int age = rand()%90;
    int p = (age < 5) ? 0 : (age < 18) ? 60 : (age < 60) ? 150 : 80;
    sprintf(in, "%d", age);
    sprintf(exp, "price=%d", p);
}
static void gen_b4(char *in, char *exp) {                 /* grade from marks */
    int m = rand()%101;
    char g = (m >= 90) ? 'A' : (m >= 75) ? 'B' : (m >= 60) ? 'C' : (m >= 40) ? 'D' : 'F';
    sprintf(in, "%d", m);
    sprintf(exp, "grade=%c", g);
}
static void gen_b5(char *in, char *exp) {                 /* mini calculator */
    const char *ops = "+-*";
    char op = ops[rand()%3];
    int a = rand()%100 + 1, b = rand()%100 + 1;
    long r = (op=='+') ? a+b : (op=='-') ? a-b : (long)a*b;
    sprintf(in, "%d %c %d", a, op, b);
    sprintf(exp, "result=%ld", r);
}
static void gen_e1(char *in, char *exp) {                 /* triangle */
    int a = rand()%12 + 1, b = rand()%12 + 1, c = rand()%12 + 1;
    if (rand()%3 == 0) b = a;                              /* make isosceles likely */
    if (rand()%5 == 0) { b = a; c = a; }                   /* and equilateral sometimes */
    sprintf(in, "%d %d %d", a, b, c);
    sprintf(exp, "type=%s", tri(a,b,c));
}
static void gen_e2(char *in, char *exp) {                 /* prime by first divisor */
    int n = rand()%98 + 2;                                 /* 2..99 */
    int d = first_divisor(n);
    sprintf(in, "%d", n);
    if (d) sprintf(exp, "n=%d divisor=%d", n, d);
    else   sprintf(exp, "n=%d prime", n);
}
static void gen_e3(char *in, char *exp) {                 /* PIN, three attempts */
    int pin = 4242, tries = rand()%4 + 1;                  /* 1..4 */
    char buf[128] = ""; int i;
    for (i = 1; i < tries; i++) { char t[16]; sprintf(t, "%d ", 1000 + rand()%1000); strcat(buf, t); }
    if (tries <= 3) { char t[16]; sprintf(t, "%d", pin); strcat(buf, t);
                      sprintf(exp, "access=granted tries=%d", tries); }
    else { strcat(buf, "9999");
           sprintf(exp, "access=denied"); }
    strcpy(in, buf);
}

struct problem {
    const char *name;
    const char *src;            /* source file to compile */
    int npub, nrand;
    const char *pub_in[MAXPUB]; const char *pub_exp[MAXPUB];
    void (*gen)(char*, char*);
};
static struct problem P[] = {
 {"b1", "b1_evenodd.c",   3, 2, {"7","-4","-5"},     {"odd","even","odd"}, gen_b1},
 {"b2", "b2_vowel.c",     2, 2, {"e","k"},           {"vowel","consonant"}, gen_b2},
 {"b3", "b3_ticket.c",    2, 2, {"3","70"},          {"price=0","price=80"}, gen_b3},
 {"b4", "b4_grade.c",     2, 2, {"91","39"},         {"grade=A","grade=F"}, gen_b4},
 {"b5", "b5_calc.c",      2, 2, {"6 * 7","10 - 25"}, {"result=42","result=-15"}, gen_b5},
 {"e1", "e1.c",           3, 3, {"3 3 3","5 5 8","2 3 9"},
        {"type=equilateral","type=isosceles","type=invalid"}, gen_e1},
 {"e2", "e2.c",           3, 3, {"97","91","2"},
        {"n=97 prime","n=91 divisor=7","n=2 prime"}, gen_e2},
 {"e3", "e3.c",           3, 3, {"4242","1111 4242","1 2 3 4"},
        {"access=granted tries=1","access=granted tries=2","access=denied"}, gen_e3},
};

int main(int argc, char **argv) {
    if (argc != 2) { printf("usage: ./grader b1..b5|e1..e3\n"); return 2; }
    /* Cap every run at 5s so one runaway loop cannot stall the lab. timeout(1)
       is standard on Linux; macOS has neither timeout nor gtimeout by default,
       so fall back to perl's alarm, which is present on both.                  */
    if      (system("command -v timeout  >/dev/null 2>&1") == 0) timeout_prefix = "timeout 5 ";
    else if (system("command -v gtimeout >/dev/null 2>&1") == 0) timeout_prefix = "gtimeout 5 ";
    else if (system("command -v perl     >/dev/null 2>&1") == 0)
        /* perl forks, kills its own child on alarm, and exits 124 itself — so the
           shell never sees a signalled child and never prints "Alarm clock". */
        timeout_prefix = "perl -e 'my $p=fork; unless($p){exec @ARGV; exit 127} "
                         "$SIG{ALRM}=sub{kill \"KILL\",$p; exit 124}; alarm(5); "
                         "waitpid($p,0); exit($? >> 8)' ";
    else printf("  grader: NOTE — no timeout available; an infinite loop will hang here.\n");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    struct problem *p = NULL;
    for (unsigned i = 0; i < sizeof P / sizeof P[0]; i++)
        if (strcmp(argv[1], P[i].name) == 0) p = &P[i];
    if (!p) { printf("grader: unknown problem %s\n", argv[1]); return 2; }

    FILE *f = fopen(p->src, "r");
    if (!f) { printf("  MISSING  %s not found — are you inside your workspace? (run ./where.sh)\n", p->src); return 1; }
    fclose(f);

    char cmd[256];
    snprintf(cmd, sizeof cmd, "gcc %s -o %s 2> .gcc.err", p->src, p->name);
    if (system(cmd) != 0) {
        printf("  COMPILE-FAIL  %s — the compiler said:\n", p->src);
        printf("           (an unfilled /* TODO */ blank looks like this too)\n");
        system("head -5 .gcc.err | sed 's/^/           /'");
        return 1;
    }

    int failed = 0;
    for (int i = 0; i < p->npub; i++)
        failed += run_one(p->name, p->pub_in[i], p->pub_exp[i], "public");
    for (int i = 0; i < p->nrand; i++) {
        char in[128], exp[256];
        p->gen(in, exp);
        failed += run_one(p->name, in, exp, "random");
    }
    return failed;
}
