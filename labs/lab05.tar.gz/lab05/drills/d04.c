/* D04 - the same switch, now with breaks, and input -5.
   -5 is odd. So which line prints? (Lab 03, drill 02, is the clue.) */
#include <stdio.h>
int main(void) {
    int input = -5;
    printf("input %% 2 is %d\n", input % 2);
    switch (input % 2) {
        case 0:  printf("even\n");    break;
        case 1:  printf("odd\n");     break;
        default: printf("neither\n");
    }
    return 0;
}
