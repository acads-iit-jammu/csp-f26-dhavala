/* D02 - which if does the else belong to?
   There are no braces. Read it the way the COMPILER must. */
#include <stdio.h>
int main(void) {
    int a = 0, b = 5;
    if (a > 0)
        if (b > 0) printf("both positive\n");
        else       printf("a positive, b not\n");
    printf("done\n");
    return 0;
}
