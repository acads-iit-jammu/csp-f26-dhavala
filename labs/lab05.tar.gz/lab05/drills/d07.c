/* D07 - the SAME idea in a while loop. Look at where i++ lives.
   WARNING: predict before you run. This one is capped at 5 seconds. */
#include <stdio.h>
int main(void) {
    int i = 0;
    while (i < 5) {
        if (i == 2) continue;
        printf("%d ", i);
        fflush(stdout);      /* so you SEE how far it got */
        i++;
    }
    printf("\ndone\n");
    return 0;
}
