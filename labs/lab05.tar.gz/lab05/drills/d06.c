/* D06 - continue in a FOR loop. Which numbers appear? */
#include <stdio.h>
int main(void) {
    int i;
    for (i = 0; i < 5; i++) {
        if (i == 2) continue;
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}
