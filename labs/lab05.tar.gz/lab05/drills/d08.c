/* D08 - short circuit. Does the right-hand side ever run? */
#include <stdio.h>
int noisy(void) { printf("[right side ran] "); return 1; }
int main(void) {
    int n = 0;
    if (n != 0 && noisy()) printf("both true\n");
    else                   printf("not both\n");
    return 0;
}
