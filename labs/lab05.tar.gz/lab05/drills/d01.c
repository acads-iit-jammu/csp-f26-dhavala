/* D01 - one equals sign, or two?
   x starts at 7. Note the condition carefully. What prints? */
#include <stdio.h>
int main(void) {
    int x = 7;
    if (x = 0)
        printf("condition was TRUE, x=%d\n", x);
    else
        printf("condition was FALSE, x=%d\n", x);
    return 0;
}
