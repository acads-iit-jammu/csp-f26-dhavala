/* D09 - a ladder in the wrong order. age is 8.
   Which price prints, and is it the one the rules intend?
   (under 5 free, 5-17 is 60, 18-59 is 150, 60+ is 80) */
#include <stdio.h>
int main(void) {
    int age = 8, price;
    if      (age < 60) price = 150;
    else if (age < 18) price = 60;
    else if (age < 5)  price = 0;
    else               price = 80;
    printf("price=%d\n", price);
    return 0;
}
