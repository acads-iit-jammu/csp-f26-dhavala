/* D10 - a switch where nothing matches, and there is no default. */
#include <stdio.h>
int main(void) {
    char grade = 'X';
    printf("before\n");
    switch (grade) {
        case 'A': printf("excellent\n"); break;
        case 'B': printf("good\n");      break;
    }
    printf("after\n");
    return 0;
}
