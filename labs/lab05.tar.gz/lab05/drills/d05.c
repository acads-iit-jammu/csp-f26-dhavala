/* D05 - break inside a switch, inside a loop.
   The menu says 'q' for quit. Does the loop stop? How many passes run? */
#include <stdio.h>
int main(void) {
    int pass = 0;
    while (pass < 4) {
        pass++;
        char choice = 'q';
        switch (choice) {
            case 'q': printf("pass %d: quitting...\n", pass); break;
        }
    }
    printf("loop finished after %d passes\n", pass);
    return 0;
}
