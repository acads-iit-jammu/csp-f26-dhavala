/* D03 - a switch with no breaks at all. Input is 4.
   How many lines does this print? */
#include <stdio.h>
int main(void) {
    int input = 4;
    switch (input % 2) {
        case 0:  printf("Number is even\n");
        case 1:  printf("Number is odd\n");
        default: printf("Neither even nor odd\n");
    }
    return 0;
}
