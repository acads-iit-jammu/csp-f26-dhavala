/* B4 (fill the blanks) - a grade from marks.
   GIVEN   : one integer, marks 0..100
   ENSURES : final line ends with:  grade=<G>
   GRADES  : >= 90 A    >= 75 B    >= 60 C    >= 40 D    otherwise F
   EXAMPLE : input "91"  ->  "grade=A"     input "39"  ->  "grade=F"
   CHECK   : ./check.sh b4
   Same shape as B3. Now write the ladder in the OTHER direction (largest
   first) and ask yourself what breaks if you write it smallest first.    */
#include <stdio.h>

int main(void) {
    int marks;
    char grade;

    printf("Enter marks: ");
    TODO_read_marks;             /* TODO 1 */

    TODO_ladder;                 /* TODO 2: the whole ladder */

    printf("grade=%c\n", grade);                     /* given - do not change */
    return 0;
}
