/* B3 (fill the blanks) - an electricity bill, charged by slab.
   GIVEN   : one integer, units consumed, 0..500
   ENSURES : final line ends with:  bill=<B>
   TARIFF  : up to 100 units          3 per unit
             101 to 300 units         5 per unit
             more than 300 units      8 per unit
             (the whole consumption is charged at the rate of its slab)
   EXAMPLE : "80" -> "bill=240"    "250" -> "bill=1250"    "400" -> "bill=3200"
   CHECK   : ./check.sh b3
   An else-if LADDER. Each rung is only reached when every rung above it has
   already failed - which is why the second test does not need to also say
   "and more than 100". Get the order wrong and every bill is wrong.        */
#include <stdio.h>

int main(void) {
    int units, bill;

    printf("Enter units: ");
    TODO_read_units;             /* TODO 1 */

    TODO_ladder;                 /* TODO 2: the three slabs */

    printf("bill=%d\n", bill);                       /* given - do not change */
    return 0;
}
