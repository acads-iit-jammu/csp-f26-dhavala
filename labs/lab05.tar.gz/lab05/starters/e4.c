/* E4 - skip some, stop at others.                                 [checked]
   GIVEN   : eight integers on one line, each 0..99.
             A 0 means STOP READING IMMEDIATELY - it is a signal, not data.
   ENSURES : final line ends with:  sum=<S> added=<N>
             S = the sum of the numbers read BEFORE any 0 that are
                 divisible by 3
             N = how many numbers you added
   EXAMPLE : "4 9 7 12 0 6 3 5"     -> "sum=21 added=2"   (9 and 12; the 0
                                        stops it, so 6 and 3 are never seen)
             "3 6 9 12 15 18 21 24" -> "sum=108 added=8"  (no 0, all divisible)
             "1 2 4 5 7 8 10 11"    -> "sum=0 added=0"    (none divisible)
   CHECK   : ./check.sh e4
   Both of this week's words, in one loop, doing different jobs:
     - a number that is not a multiple of 3 -> this ONE number is of no
       interest, but the rest still are.  That is continue.
     - a 0 -> there is nothing more to read at all.  That is break.
   Ask yourself before you write it: is 0 divisible by 3? And does that
   matter here? Read the GIVEN again.                                     */
#include <stdio.h>

int main(void) {
    int i, x, sum = 0, added = 0;

    printf("Enter 8 numbers (a 0 stops early): ");

    for (i = 1; i <= 8; i++) {
        TODO_read_x;             /* TODO 1: read the next number */
        TODO_sentinel;           /* TODO 2: nothing left to read? */
        TODO_skip;               /* TODO 3: not a multiple of 3? */
        TODO_accumulate;         /* TODO 4: count it in */
    }

    printf("sum=%d added=%d\n", sum, added);          /* given - do not change */
    return 0;
}
