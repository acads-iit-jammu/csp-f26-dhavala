/* E1 - classify a triangle from its three sides.                  [checked]
   GIVEN   : three integers a b c on one line, each 1..12
   ENSURES : final line ends with exactly one of:
                 type=equilateral    all three sides equal
                 type=isosceles      exactly two sides equal
                 type=scalene        no two sides equal
                 type=invalid        these lengths cannot form a triangle
   EXAMPLE : "3 3 3" -> "type=equilateral"
             "5 5 8" -> "type=isosceles"
             "2 3 9" -> "type=invalid"
   CHECK   : ./check.sh e1
   Validity FIRST: three lengths make a triangle only if every pair adds
   up to more than the third. Check that before you classify anything -
   "5 5 8" is a triangle, but "2 3 9" is three sticks that will not meet.
   Then ask of your ladder: do my cases cover every possibility?          */
#include <stdio.h>

int main(void) {
    int a, b, c;

    printf("Enter three sides: ");
    TODO_read_sides;             /* TODO 1 */

    TODO_classify;               /* TODO 2: validity, then the classification */

    return 0;
}
