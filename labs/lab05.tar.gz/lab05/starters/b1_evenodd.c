/* B1 (fill the blanks) - even or odd, with if-else.
   GIVEN   : one integer n, -100..100
   ENSURES : final line ends with:  even     or     odd
   EXAMPLE : input "7"  ->  "odd"   "-4" -> "even"   "-5" -> "odd"
   CHECK   : ./check.sh b1
   Careful with negatives: -4 IS even. Which test survives a minus sign,
   n % 2 == 0  or  n % 2 == 1 ?  (Lab 03, drill 02, is the evidence.)      */
#include <stdio.h>

int main(void) {
    int n;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1: read n */

    if (TODO_condition)          /* TODO 2: the test */
        printf("even\n");
    else
        printf("odd\n");

    return 0;
}
