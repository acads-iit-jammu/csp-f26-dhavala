/* B2 (fill the blanks) - how many days in that month?
   GIVEN   : one integer, the month number 1..12
   ENSURES : final line ends with:  days=<D>
   RULE    : April, June, September, November have 30.
             February has 28 (ignore leap years today).
             Everything else has 31.
   EXAMPLE : "4" -> "days=30"    "2" -> "days=28"    "12" -> "days=31"
   CHECK   : ./check.sh b2
   FALL-THROUGH IS THE POINT HERE, not a bug. Four months share one answer:
   stack their case labels with nothing between them and let them fall into
   a single body. Compare that with what a MISSING break did in drill d03.  */
#include <stdio.h>

int main(void) {
    int month, days;

    printf("Enter month (1-12): ");
    TODO_read_month;             /* TODO 1 */

    switch (month) {
        TODO_thirty;             /* TODO 2: the four 30-day months, sharing one body */
        case 2:
            days = 28;
            break;
        default:
            days = 31;
    }

    printf("days=%d\n", days);                       /* given - do not change */
    return 0;
}
