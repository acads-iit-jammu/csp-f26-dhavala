/* B5 (fill the blanks) - a temperature converter.
   GIVEN   : an integer value -50..150, then a code character, on one line:
                 c   the value is Celsius    -> print it in Fahrenheit
                 f   the value is Fahrenheit -> print it in Celsius
                 k   the value is Celsius    -> print it in Kelvin
   ENSURES : final line ends with:  result=<R>      (<R> to 2 decimals)
   FORMULAE: F = C * 9/5 + 32     C = (F - 32) * 5/9     K = C + 273.15
   EXAMPLE : "100 c" -> "result=212.00"
             "212 f" -> "result=100.00"
             "0 k"   -> "result=273.15"
   CHECK   : ./check.sh b5
   switch on a CHARACTER, and every case needs its OWN break - unlike B2,
   where sharing a body was the whole idea.
   One trap from Week 3 is waiting in those formulae. Which one?            */
#include <stdio.h>

int main(void) {
    int value;
    char code;
    double result = 0;

    printf("Enter value and code (e.g. 100 c): ");
    TODO_read_both;              /* TODO 1: mind the space before %c */

    switch (code) {
        TODO_cases;              /* TODO 2: one case each for c, f, k - each with its break */
        default:
            printf("unknown code '%c'\n", code);
            return 1;
    }

    printf("result=%.2f\n", result);                 /* given - do not change */
    return 0;
}
