/* B3 (fill the blanks) - ticket price by age bracket.
   GIVEN   : one integer age, 0..89
   ENSURES : final line ends with:  price=<P>
   PRICES  : under 5      free (0)
             5 to 17      60
             18 to 59     150
             60 and over  80
   EXAMPLE : input "3"  ->  "price=0"     input "70"  ->  "price=80"
   CHECK   : ./check.sh b3
   An else-if LADDER. The order of the rungs is the whole exercise: each
   test is only reached when every test above it has already failed.      */
#include <stdio.h>

int main(void) {
    int age, price;

    printf("Enter age: ");
    TODO_read_age;               /* TODO 1 */

    if (age < 5)
        price = 0;
    TODO_ladder;                 /* TODO 2: the remaining three rungs */

    printf("price=%d\n", price);                     /* given - do not change */
    return 0;
}
