/* E3 - a PIN, and three attempts.                                 [checked]
   GIVEN   : a sequence of integers, one per attempt. The correct PIN
             is 4242. You may read at most FOUR numbers, but the user
             gets only THREE attempts.
   ENSURES : final line ends with exactly one of:
                 access=granted tries=<N>   N is which attempt succeeded (1, 2 or 3)
                 access=denied              three attempts, all wrong
   EXAMPLE : "4242"        -> "access=granted tries=1"
             "1111 4242"   -> "access=granted tries=2"
             "1 2 3 4"     -> "access=denied"
   CHECK   : ./check.sh e3
   A loop that stops for TWO different reasons: the right PIN (break out
   early) or running out of attempts (the loop condition ends it). Make
   sure you can tell which one happened after the loop - that is what the
   two different output lines are asking you to prove.                    */
#include <stdio.h>

#define PIN 4242

int main(void) {
    int entered, attempt;

    TODO_loop;                   /* TODO 1: up to three attempts, breaking on success */

    TODO_verdict;                /* TODO 2: which of the two lines should print? */

    return 0;
}
