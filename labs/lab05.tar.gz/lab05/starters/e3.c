/* E3 - find the first multiple of 7, and stop looking.            [checked]
   GIVEN   : exactly five integers on one line, each 1..99
   ENSURES : final line ends with exactly one of:
                 found=<X> at=<N>   X is the first value divisible by 7,
                                    N is its position (1 to 5)
                 none in 5          not one of the five was divisible by 7
   EXAMPLE : "3 5 14 9 11" -> "found=14 at=3"
             "3 14 5 21 9" -> "found=14 at=2"   (the FIRST one, not 21)
             "1 2 3 4 5"   -> "none in 5"
             "70 1 2 3 4"  -> "found=70 at=1"
   CHECK   : ./check.sh e3
   Read them one at a time inside a loop, and BREAK out the moment you find
   one - a search that keeps searching after it has found the answer is
   doing work for nothing.
   The loop can end for TWO different reasons: you broke out early, or you
   ran out of numbers. After the loop your program still has to know WHICH
   happened - that is exactly what the two different output lines demand.
   Careful: you must read all five even if you stop early? Or must you?
   Read the ENSURES again and decide what the spec actually requires.       */
#include <stdio.h>

int main(void) {
    int i, x;

    TODO_loop;                   /* TODO 1: read up to five, break on the first hit */

    TODO_verdict;                /* TODO 2: which of the two lines prints? */

    return 0;
}
