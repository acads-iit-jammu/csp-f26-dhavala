/* B5 (fill the blanks) - a mini calculator.
   GIVEN   : an integer, an operator character (+ - *), an integer,
             all on one line.  Both integers are 1..100 for + and *,
             and either may be larger than the other for - .
   ENSURES : final line ends with:  result=<R>
   EXAMPLE : input "6 * 7"     ->  "result=42"
             input "10 - 25"   ->  "result=-15"
   CHECK   : ./check.sh b5
   switch on a CHARACTER. Every case needs its own break - unlike B2,
   where sharing a body was the whole idea.                              */
#include <stdio.h>

int main(void) {
    int a, b;
    char op;
    long result = 0;

    printf("Enter: a op b   (e.g. 6 * 7): ");
    TODO_read_three;             /* TODO 1: read a, op and b (mind the space before %c) */

    switch (op) {
        TODO_cases;              /* TODO 2: one case each for + - * , each with its break */
        default:
            printf("unknown operator\n");
            return 1;
    }

    printf("result=%ld\n", result);                  /* given - do not change */
    return 0;
}
