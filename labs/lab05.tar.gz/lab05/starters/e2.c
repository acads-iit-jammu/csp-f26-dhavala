/* E2 - do these two numbers share a factor?                       [checked]
   GIVEN   : two integers a and b on one line, each 2..99
   ENSURES : final line ends with exactly one of:
                 a=<A> b=<B> common=<D>   D is the SMALLEST divisor above 1
                                          that divides BOTH
                 a=<A> b=<B> coprime      they share no factor above 1
   EXAMPLE : "12 18" -> "a=12 b=18 common=2"
             "9 28"  -> "a=9 b=28 coprime"
             "49 91" -> "a=49 b=91 common=7"
   CHECK   : ./check.sh e2
   Search upward from 2 and BREAK the moment you find a number that divides
   both - the spec asks for the smallest, so there is no reason to look on.
   Two numbers with no common factor above 1 are called COPRIME. You met the
   GCD in Lab 04: what is the gcd of two coprime numbers? Predict what your
   program should say for "13 13".
   Then look at your loop's upper limit. How far must you really go?        */
#include <stdio.h>

int main(void) {
    int a, b;

    printf("Enter a and b: ");
    TODO_read_both;              /* TODO 1 */

    TODO_search;                 /* TODO 2: the search, the break, and the verdict */

    return 0;
}
