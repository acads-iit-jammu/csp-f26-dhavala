/* E2 - is it prime? find the first divisor.                       [checked]
   GIVEN   : one integer n, 2..99
   ENSURES : final line ends with exactly one of:
                 n=<N> prime            no divisor was found
                 n=<N> divisor=<D>      D is the SMALLEST divisor above 1
   EXAMPLE : "97" -> "n=97 prime"
             "91" -> "n=91 divisor=7"      (91 = 7 x 13, so 7, not 13)
             "2"  -> "n=2 prime"
   CHECK   : ./check.sh e2
   Search upward from 2 for the first thing that divides n, and BREAK the
   moment you find it - there is no reason to keep looking, and the spec
   asks for the smallest one.
   Then look at your loop's upper limit. Going all the way to n-1 works.
   Stopping at i*i <= n also works, and for n=97 costs 9 passes instead
   of 95. Add a counter and see for yourself.                             */
#include <stdio.h>

int main(void) {
    int n;

    printf("Enter n (2..99): ");
    TODO_read_n;                 /* TODO 1 */

    TODO_search;                 /* TODO 2: the search, the break, and the verdict */

    return 0;
}
