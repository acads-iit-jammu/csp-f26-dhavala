/* B2 (fill the blanks) - vowel or consonant, with switch.
   GIVEN   : one lowercase letter, a..z
   ENSURES : final line ends with:  vowel    or    consonant
   EXAMPLE : input "e"  ->  "vowel"      input "k"  ->  "consonant"
   CHECK   : ./check.sh b2
   HERE FALL-THROUGH IS THE POINT, not a bug: five cases, one body.
   A case with no statements simply falls into the next one.             */
#include <stdio.h>

int main(void) {
    char c;

    printf("Enter a lowercase letter: ");
    TODO_read_c;                 /* TODO 1: read c (mind the space before %c) */

    switch (c) {
        case 'a':
        case 'e':
        TODO_cases;              /* TODO 2: the other three vowels */
            printf("vowel\n");
            break;
        default:
            printf("consonant\n");
    }

    return 0;
}
