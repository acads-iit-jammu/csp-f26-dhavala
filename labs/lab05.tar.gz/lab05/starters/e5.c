/* E5 - a bank session, and the break that does not work.          [checked]
   GIVEN   : an opening balance 0..9999, then a sequence of commands on the
             same line. At most ten commands will be acted on.
                 D <amount>   deposit
                 W <amount>   withdraw - REFUSED, with no change to the
                              balance, if the amount exceeds the balance
                 B            show balance (counts as a command; changes nothing)
                 Q            quit the session
             There may be further commands written AFTER the Q. A correct
             program never reaches them.
   ENSURES : final line ends with:  balance=<B> ops=<N>
             N = how many commands were acted on, NOT counting the Q
   EXAMPLE : "1000 D 500 W 200 B Q D 999" -> "balance=1300 ops=3"
             "500 W 900 Q D 1"            -> "balance=500 ops=1"
             "100 B B B Q W 50"           -> "balance=100 ops=3"
   CHECK   : ./check.sh e5
   The loop header is given. Your job is the switch inside it - and the one
   thing this whole lab has been about:
       a break inside a switch leaves THE SWITCH.
   Write `case 'Q': break;' and the session will not end. It will read the
   command after the Q, act on it, and your balance will be wrong. The
   checker will notice, because that is exactly what the trailing command
   is there for.
   So: what can `Q' change that the FOR LOOP is watching?                 */
#include <stdio.h>

int main(void) {
    int balance, amount, i, ops = 0, running = 1;
    char cmd;

    printf("Opening balance: ");
    TODO_read_balance;           /* TODO 1 */

    for (i = 1; i <= 10 && running; i++) {
        if (scanf(" %c", &cmd) != 1) break;      /* the input ran out */

        TODO_switch;             /* TODO 2: D, W, B, Q - and a default */
    }

    printf("balance=%d ops=%d\n", balance, ops);      /* given - do not change */
    return 0;
}
