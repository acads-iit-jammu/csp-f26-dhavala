/* B1 (fill the blanks) - the sign of a number: three outcomes, not two.
   GIVEN   : one integer n, -100..100
   ENSURES : final line ends with:  sign=positive  |  sign=negative  |  sign=zero
   EXAMPLE : "7" -> "sign=positive"   "-4" -> "sign=negative"   "0" -> "sign=zero"
   CHECK   : ./check.sh b1
   if/else gives you two branches. Three outcomes need a LADDER - and the
   order matters, because "not positive" is not the same as "negative".     */
#include <stdio.h>

int main(void) {
    int n;

    printf("Enter n: ");
    TODO_read_n;                 /* TODO 1 */

    TODO_ladder;                 /* TODO 2: three outcomes, in an order that works */

    return 0;
}
